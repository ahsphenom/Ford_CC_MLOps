import argparse
from pathlib import Path

import bq_utils
import gcs_utils
import utils
from app_logger import CustomLogger

# LOGGING
logger = CustomLogger(__name__, "update_readiness_flag_log")


def update_readiness_flag(uuid,  expectedfiles, no_metadata):
    """
    This function checks and updates the readiness flag for every upload
    """

    # INITILIZE THE LIST WHERE EXPECTED AND PRESENT FILE DATA WILL BE ACCUMULATED
    present_files = []
    expectedfilelist = []
    # The files in which the expected files is stored by taking it from model_metadata
    expectedfilesjson = 'ExpectedFiles.json'
    # variable used to the last file which comes to the platform before the readiness is marked true  is not a metadata.json file

    # Query to get modelGUID and dl for notifications
    try:
        query_job = bq_utils.select_from_model_catalog(uuid)
        logger.debug(f"Query job id for select_from_model_catalog : {query_job.job_id}")

        notifications = query_job.result()
        for notification in notifications:
            guid = notification['modelGUID']
            dl = notification['modelOwnerDistributionList']
    except Exception as e:
        logger.error(
            f"Data could not be fetched from DB.")
        logger.error(e)

    # INITIALIZE THE STORAGE CLIENT
    bucket = gcs_utils.get_bucket()

    # BELOW IF-ELSE CONDITION DECIDES HOW TO GET THE PATH OF ExpectedFile.json which contains the list of file to consider the model complete
    if no_metadata:
        present_files, expectedfilelist = utils.get_expected_filepath_no_metadata(
            no_metadata, expectedfilesjson, present_files, logger)

    elif expectedfiles:
        present_files, expectedfilelist = utils.get_expected_filepath_metadata(
            expectedfiles, expectedfilesjson, present_files, bucket, logger)

    one_half = False
    logger.info(f"Present files : {present_files}")
    logger.info(f"Expectedfiles : {expectedfilelist}")

    logger.debug('Checking for expected files being present.')
    if set(expectedfilelist).issubset(present_files):
        one_half = True
        logger.info("Expected Files are present in the GCS bucket.")
    else:
        logger.info("Expected Files not present in the GCS bucket. Readiness flag won't be set to true.")

    # Query to get the status of validation stage

    try:
        logger.debug("Checking if validation of metadata file was successful.")
        query_job = bq_utils.old_validate_metadata_result(guid)
        logger.debug(f"Query job id for old_validate_metadata_result : {query_job.job_id}")

        row = query_job.result()
        if row.total_rows == 0:
            logger.info("Validation of metadata was never successful.")

            logger.info('Setting readiness flag to false.')
            logger.debug(
                'Setting readiness flag to false since validate metadata.json file was not successful.')

        elif row.total_rows != 0 and one_half:
            logger.info('Setting readiness flag as true.')
            readiness = "true"

            try:
                logger.info('Updating data into Model Catalog.')

                query_job = bq_utils.update_readiness_flag(readiness, uuid)
                logger.debug(f"Query job id for update_readiness_flag : {query_job.job_id}")

            except Exception as e:
                logger.error(
                    f"Query to update_readiness_flag failed.")

                # NOTIFICATION
                uploaduid = uuid
                dl_list = dl
                subject = f"Validation | Validation fail: modelGUID | {guid}"
                msg = f"""Hey, Validation pipeline has failed because of the following reasons: 
                Query to update readiness flag failed. Job_id of the query is {query_job.job_id}"""

                req_data = gcs_utils.send_notification(uploaduid, dl_list, subject, msg)
                logger.debug(req_data)
       
    except Exception as e:
        logger.error(
            f"Data could not be fetched from DB.")
        logger.error(e)

    # WRITE LOG FILE
    with open('update_readiness_flag_log', 'r') as f1, open(args.user_logs, 'w') as f2:
        for line in f1:
            f2.write(line)


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    # INPUT PARAMETERS
    parser.add_argument("--uuid", type=str)
    parser.add_argument("--expectedfiles", type=str)
    parser.add_argument("--no_metadata", type=str)
    parser.add_argument("--time", type=str)

    # OUTPUT PARAMETERS
    parser.add_argument("--user_logs", type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(f'uv-{args.time}')

    Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)

    logger.debug(args)
    update_readiness_flag(args.uuid, args.expectedfiles, args.no_metadata)
