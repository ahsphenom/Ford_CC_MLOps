import json

import config
import gcs_utils


def get_expected_filepath_no_metadata(no_metadata, expectedfilesjson, present_files, logger):

    # If single file is coming in
    if no_metadata.split('.')[-1] != 'zip':
        prefix = no_metadata.split('/')[:-1][0]

    # If zip file is coming in
    elif no_metadata.split('.')[-1] == 'zip':
        prefix = no_metadata.split('/')[:-2][0]

    try:
        storage_client = gcs_utils.get_storage_client()
        blobs = storage_client.list_blobs(config.INPUT_BUCKET_NAME, prefix=f"{prefix}/")
    except Exception as e:
        logger.error(f"{prefix}/ not found.")
        logger.erro(e)

    for blob in blobs:
        if blob.name.split('/')[-1] != expectedfilesjson:
            present_files.append(blob.name.split('/')[-1])

        elif blob.name.split('/')[-1] == expectedfilesjson:
            try:
                expectedfilelist = json.loads(blob.download_as_string(client=None))
            except FileNotFoundError:
                expectedfilelist='File Not Found'
                logger.error("Expected file list not present. Check if model metadata with expectedfilelist key was passed for this modelGUID.")
    
    # The below condition can occur if user passed the new usecase without model metadata file
    if not expectedfilelist:
        expectedfilelist='File Not Found'

    return present_files, expectedfilelist


def get_expected_filepath_metadata(expectedfiles, expectedfilesjson, present_files, bucket, logger):

    try:
        blob = bucket.get_blob(expectedfiles)
    except FileNotFoundError:
        logger.error(f"{expectedfiles} does not exsits.")

    try:
        expectedfilelist = json.loads(blob.download_as_string(client=None))
    except Exception as e:
        logger.error(f"Issue with loading the expectedlist file from gcs bucket.")
        logger.error(e)

    storage_client = gcs_utils.get_storage_client()
    blobs = storage_client.list_blobs(config.INPUT_BUCKET_NAME, prefix=f"{expectedfiles.split('/')[0:-1][0]}/")

    for blob in blobs:
        if blob.name.split('/')[-1] != expectedfilesjson:
            present_files.append(blob.name.split('/')[-1])

    return present_files, expectedfilelist
