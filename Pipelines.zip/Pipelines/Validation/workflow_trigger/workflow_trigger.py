import argparse
import sys
from pathlib import Path

import bq_utils
import config
import gcs_utils
import utils
from app_logger import CustomLogger

# LOGGING
logger = CustomLogger(__name__, "workflow_trigger_log")


def workflow_trigger(uuid, t2):
    # Get the modelGUID for notification
    try:
        query_job = bq_utils.select_from_model_catalog(uuid)

        logger.debug(f"Query job id for select_from_model_catalog : {query_job.job_id}")
        row = query_job.result()

    except Exception as e:
        logger.error(
            f"Couldn't get information form DB.")
        logger.error(e)

        # NOTIFICATION
        uploaduid = uuid
        dl_list = dl
        subject = f"Validation: Validation fail: modelGUID : {modelguid}"
        msg = f"""Hey, Validation has failed because of the following reasons: 
        Query to get model information from {config.MODEL_CATALOG_TABLE} was not successful. The job_id of the query was {query_job.job_id}"""
        req_data = gcs_utils.send_notification(uploaduid, dl_list, subject, msg)
        logger.debug(req_data)

        sys.exit()

    for notification in row:
        modelguid = notification['modelGUID']
        dl = notification['modelOwnerDistributionList']

    if row.total_rows == 0:
        logger.error(f"Check uuid id.")

    else:
        for row in query_job:
            workflow = ""
            if row['readiness']:

                testing, deploymenttocloud, deploymenttoedge, specificationsdeploymentwhentorun = utils.get_workflows(
                    row)

                logger.info('Determining which workflow to run.')

                deploy_dict, workflow = utils.decide_workflows(
                    row, workflow, testing, deploymenttocloud, deploymenttoedge, specificationsdeploymentwhentorun, logger)

                utils.trigger_workflow(uuid, deploy_dict, workflow, logger, t2, modelguid, dl)

            else:
                logger.debug('Readiness flag is not set to true. Cannot trigger testing and/or deployment workflows.')

                try:
                    logger.debug('Inserting log to indicate completion of validation pipeline.')
                    log_input = {
                        "uuid": uuid,
                        "actionjobuid": f"pipeline-{t2}",
                        "action": "NA",
                        "stage": "validation",
                        "status": "fail",
                        "desc": f"pipeline job with name uv-{t2} was completed",
                        "vaijobid": f"uv-{t2}",
                        "workflowitems": "v"
                    }
                    query_job = bq_utils.insert_to_pipeline_logs(
                        log_input)
                    logger.debug(f"Query job id: {query_job.job_id}")

                except Exception as e:
                    logger.error(
                        f"Query {query_job.query} to update pipeline logs table for completion for validation pipeline failed. Query job_id : {query_job.job_id}")

                # NOTIFICATION
                uploaduid = uuid
                dl_list = dl
                subject = f"Validation: Validation fail : modelGUID : {modelguid}"
                msg = f"""Hey, Validation has failed because of the following reasons: 
                No workflows has been triggered by the validation pipeline since readiness flag is not set to true yet. 
                To update readiness flag to true : check the files uploaded for the model and validation of the metadata.json file should pass """
                req_data = gcs_utils.send_notification(uploaduid, dl_list, subject, msg)
                logger.debug(req_data)

    # Writing the components of the log file
    logger.debug(f"Exporting log file for the component.")
    with open("workflow_trigger_log") as f:
        with open(args.user_logs, "w") as f1:
            for line in f:
                f1.write(line)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--uuid", type=str)
    parser.add_argument("--t2", type=str)
    parser.add_argument("--user_logs", type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(f'uv-{args.t2}')
    Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)

    logger.debug(f"{args.uuid},{args.t2}")
    workflow_trigger(args.uuid, args.t2)
