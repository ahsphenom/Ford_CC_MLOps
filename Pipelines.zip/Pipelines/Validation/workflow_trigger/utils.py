
import itertools
import json

import bq_utils
import config
import gcs_utils
from time import sleep
import google.cloud.aiplatform as aip
from google.api_core.exceptions import AlreadyExists


def get_workflows(row):
    testing = row.get('workflow', 'false').get('stagesTestingToTest', 'false')
    deploymenttoedge = row.get('workflow', 'false').get('stagesDeploymentToEdge', 'false')
    deploymenttocloud = row.get('workflow', 'false').get('stagesDeploymentToCloud', 'false')
    specificationsdeploymentwhentorun = row.get(
        'workflow', 'false').get('specificationsDeploymentWhenToRun')

    return testing, deploymenttocloud, deploymenttoedge, specificationsdeploymentwhentorun

def decide_deployment_to_cloud(workflow):
   
    if workflow:
        workflow += "-clouddeploy"
    else:
        workflow = "clouddeploy"
    
    return workflow


def decide_workflows(row, workflow, testing, deploymenttocloud, deploymenttoedge, specificationsdeploymentwhentorun, logger):
    if testing is None or testing:
        workflow = "test"

    if deploymenttocloud:
        workflow=decide_deployment_to_cloud(workflow)

    # IF the timestamp is not given in model_metadata and DeploymentToEdge is true add edgedeploy to workflow
    if str(specificationsdeploymentwhentorun) == "2099-12-31 00:00:00+00:00" and deploymenttoedge:
        if workflow:
            workflow += '-edgedeploy'
        else:
            workflow = 'edgedeploy'
        deploy_dict = {}

        query_job2 = bq_utils.edge_deployment(row)

        logger.debug(f"Query job id for edge_deployment : {query_job2.job_id}")

        row2 = query_job2.result()

        if row2.total_rows == 0:
            logger.error(
                "Couldn't get VIN list for the given modelGUID from DB. Check if VINs where added for this modelGUID.")

        else:

      
            for row2 in query_job2:
                deploy_dict[row2['uploadUID']] = list(set(row2['vin_list']))
                logger.debug(
                    f"length of vin_list for UUID : {row2['uploadUID']} is {len(list(set(row2['vin_list'])))}")

          

            deploy_dict = json.dumps(deploy_dict)
            logger.info(deploy_dict)

    else:
        deploy_dict = ""

    return deploy_dict, workflow


def trigger_workflow(uuid, deploy_dict, workflow, logger, t2, modelguid, dl):

    if workflow:
        logger.info(f"The workflow going to be run is : {workflow}")

        # Check to see if validation has passed .The below querys helps to display information on the UI

        # LOG ENTRY FOR VALIDATION PIPELINE STAGE  GETTING OVER
        try:
            logger.debug('Inserting log to indicate completion of validation pipeline')

            log_input = {
                "uuid": uuid,
                "actionjobuid": f"pipeline-{t2}",
                "action": "NA",
                "stage": "validation",
                "status": "completed",
                "desc": f"pipeline job with name uv-{t2} was completed",
                "vaijobid": f"uv-{t2}",
                "workflowitems": f'v{str(config.TEMPLATE_PATH[workflow]["prefix"])}'
            }

            query_job = bq_utils.insert_to_pipeline_logs(
                log_input
            )
            logger.debug(f"Query job id for insert_to_pipeline_logs : {query_job.job_id}")

        except Exception as e:
            logger.error(
                f"Query {query_job.query} to update pipeline logs table for completion for validation pipeline failed. Query job_id : {query_job.job_id}")

        
        try:

            PIPELINE_PARAMETERS = {
                'uploadUID': uuid,
                'uploadids': deploy_dict,
                'actionJobUID': f"{config.TEMPLATE_PATH[workflow]['prefix']}-{t2}"
            }

            job = aip.PipelineJob(
                display_name=f"{config.TEMPLATE_PATH[workflow]['prefix']}-{t2}",
                template_path=config.TEMPLATE_PATH[workflow]['path'],
                job_id=f"{config.TEMPLATE_PATH[workflow]['prefix']}-{t2}",
                pipeline_root=f"gs://{config.PIPELINE_BUCKET_NAME}",
                parameter_values=PIPELINE_PARAMETERS,
                enable_caching=True,
                project=config.PROJECT_ID,
                location=config.REGION
            )

            job.submit()
        

            # LOG ENTRY FOR WORFLOW RUN START
            if job.has_failed:
                logger.debug(
                    f"Vertex-AI pipeline for workflow was not triggered. The job could have failed because of workflow template path being changed.")
                logger.error(f"Vertex-AI pipeline for workflow was not triggered.")

            else:
                logger.debug(f"Vertex-AI pipeline for workflow was triggered with workflow : {workflow}")
                logger.info(f"Vertex-AI pipeline for workflow was triggered with workflow : {workflow}")

                # NOTIFICATION
                uploaduid = uuid
                dl_list = dl
                subject = f"Validation: Validation pass: modelGUID : {modelguid}"
                msg = f"""Hey, Validation pipeline completed successfully and triggered the {workflow} workflow"""
                req_data = gcs_utils.send_notification(uploaduid, dl_list, subject, msg)
                logger.debug(req_data)

        except Exception as e:
            logger.error(
                f"Workflow's pipeline run for {workflow} was not triggered. Check if input variables to the pipeline are present in config file.")
            logger.debug(e)

    else:
        logger.info('User has not selected any workflow to run.')
        try:
            log_input = {
                "uuid": uuid,
                "actionjobuid": f"pipeline-{t2}",
                "action": "NA",
                "stage": "validation",
                "status": "completed",
                "desc": f"pipeline job with name uv-{t2} was completed.",
                "vaijobid": f"uv-{t2}",
                "workflowitems": f"v"
            }

            query_job = bq_utils.insert_to_pipeline_logs(
                log_input
            )
            logger.debug(f"Query job id: {query_job.job_id}")

        except Exception as e:
            logger.error(
                f"Query {query_job.query} to update pipeline logs table for completion for validation pipeline failed. Query job_id : {query_job.job_id}")
