import config
from google.cloud import bigquery

bq_client = bigquery.Client()


def insert_to_pipeline_logs(input):
    bq_client = bigquery.Client()
    query = f"""
    INSERT {config.PIPELINE_LOGS_TABLE}
    (uploadUID,actionJobUID,action,stage,result,description,eventTime,VAIJobID,workflowItems) 
    VALUES 
    ('{input["uuid"]}','{input["actionjobuid"]}','{input["action"]}','{input["stage"]}','{input["status"]}','{input["desc"]}',CURRENT_TIMESTAMP(),'{input["vaijobid"]}','{input["workflowitems"]}')
    """
    query_job = bq_client.query(query, project=config.PROJECT_ID)
    return query_job


def insert_workflow_to_pipline_logs(uuid, time, stage, status, desc, vaijobid, workflowitems):
    query = f"""
        INSERT  {config.PIPELINE_LOGS_TABLE}
        (uploadUID,actionJobUID, action,stage,result,description, VAIJobID,eventTime,workflowItems)
        VALUES ('{uuid}','pipeline-{time}' ,'workflow-pipeline-trigger','{stage}','{status}',
        '{desc}' ,'{vaijobid}', CURRENT_TIMESTAMP(),'{workflowitems}') 
        """
    query_job = bq_client.query(query, project=config.PROJECT_ID)
    return query_job


def select_from_pipeline_logs(uuid):
    query = f"""
            SELECT *
            FROM {config.PIPELINE_LOGS_TABLE} 
            WHERE uploadUID=@uploadUID
            ORDER BY eventTime DESC
            LIMIT 1
            """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("uploadUID", "STRING", uuid)
        ]
    )
    query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)

    return query_job


def select_from_model_catalog(uuid):
    query = f"""
            SELECT *
            FROM {config.MODEL_CATALOG_TABLE} 
            WHERE uploadUID=@uploadUID
            ORDER BY uploadedTime DESC
            LIMIT 1 
            """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("uploadUID", "STRING", uuid)
        ]
    )
    query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)
    return query_job


def select_from_model_catalog_by_modelguid(modelguid):
    query = f"""
            SELECT *
            FROM {config.MODEL_CATALOG_TABLE} 
            WHERE TRIM(modelGUID)=@modelGUID
            ORDER BY uploadedTime DESC
            LIMIT 1 
            """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter(
                "modelGUID", "STRING", modelguid
            )
        ]
    )

    query_job = bq_client.query(
        query, job_config=job_config, project=config.PROJECT_ID)

    return query_job


def old_validate_metadata_result(modelguid):
    query = f"""
            SELECT uploadUID,action,result,eventTime FROM {config.PIPELINE_LOGS_TABLE} 
            WHERE DATE(eventTime) <= "2099-12-31" 
            AND TRIM(action) = "validate metadata file" AND LOWER(result) = "pass"
            AND uploadUID IN (SELECT uploadUID FROM {config.MODEL_CATALOG_TABLE} WHERE modelGUID = @modelGUID)
            ORDER BY eventTime DESC     
            """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("modelGUID", "STRING", modelguid),
        ]
    )
    query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)

    return query_job


def edge_deployment(row):
    query = f"""
            WITH deployed_vin AS (
            SELECT vin FROM {config.EDGE_DEPLOYMENT_TABLE}
            WHERE 
            uploadUID IN (SELECT uploadUID FROM mlopsplatform.ford_cc.Model_Catalog WHERE modelGUID = @modelGUID) 
            AND apiStatus is true
            GROUP BY 1)

            SELECT uploadUID, ARRAY_AGG(vin) AS vin_list FROM {config.VIN_LIST_TABLE}
            WHERE 
            uploadUID IN (SELECT uploadUID FROM {config.MODEL_CATALOG_TABLE} WHERE modelGUID = @modelGUID) 
            AND
            CONCAT(uploadUID,"-",vin) NOT IN 
            (SELECT CONCAT(uploadUID,"-",vin) FROM 
            (SELECT uploadUID, VIN FROM {config.EDGE_DEPLOYMENT_TABLE} WHERE apiStatus IS TRUE UNION DISTINCT SELECT uploadUID, VIN FROM {config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE})) 
            AND vin NOT IN (SELECT vin FROM deployed_vin)
            GROUP BY 1
            """

    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("modelGUID", "STRING", row['modelGUID'])
        ]
    )
    query_job2 = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)

    return query_job2


def update_readiness_flag(readiness, uuid):
    query = f"""
        UPDATE {config.MODEL_CATALOG_TABLE}  
        SET readiness={readiness} 
        WHERE uploadUID='{uuid}'
        """

    query_job = bq_client.query(query, project=config.PROJECT_ID)

    return query_job
