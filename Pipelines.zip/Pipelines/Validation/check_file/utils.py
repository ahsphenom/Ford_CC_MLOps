import io
from zipfile import ZipFile, is_zipfile

import bq_utils
import gcs_utils


def unzip_folder(blob, file_path, unzip_files, bucket, logger):
    zipbytes = io.BytesIO(blob.download_as_string())
    if is_zipfile(zipbytes):
        with ZipFile(zipbytes, 'r') as myzip:
            logger.debug(f"Contents of zip file: {myzip.namelist()}")
            for contentfilename in myzip.namelist():
                contentfile = myzip.read(contentfilename)
                blob = bucket.blob("/".join(file_path.split('.')[:-1][0].split('/')[:-2])+'/'+contentfilename)
                blob.upload_from_string(contentfile)

                if len(blob.name.split('/')) == 2:
                    unzip_files.append(blob.name)

    return unzip_files


def determine_file_type(bucket, unzip_files, args, logger, uuid, action, time):

    count = 0
    file_list = []
    common_file = 0

    for file_path in unzip_files:
        blob = bucket.get_blob(file_path)

        prefix = str(blob.name).split('/')[-1].split('__')[0].lower()
        extension = str(blob.name).split('.')[-1]

        if(prefix == 'targetassignmentlistfile' and extension == 'csv'):

            logger.info("targertassignmentfilelist found.")
            with open(args.targetfilepath, 'w') as f:
                f.write(str(blob.name)+'$'+str(blob.generation))

        if(extension == 'json' and prefix == 'model_metadata'):
            logger.info("Model metadata file found.")

            with open(args.model_metadata, 'w') as f:
                f.write(str(blob.name)+'$'+str(blob.generation))

            file_list.append(blob.name)

            common_file = 1
            count += 1

        elif ((extension == 'joblib' or extension == 'pkl' or extension == 'pb' or extension == 'bst') and (prefix == 'model_weight')):
            logger.info("Model_Weight file found.")

            with open(args.model_file, 'w') as f:
                f.write(str(blob.name)+'$'+str(blob.generation))

            file_list.append(blob.name)

            common_file = 1
            count += 4

        elif (extension == 'py' and prefix == 'inference_script'):
            logger.info("Inference_script.py file found.")

            with open(args.inference_script, 'w') as f:
                f.write(str(blob.name)+'$'+str(blob.generation))

            file_list.append(blob.name)

            common_file = 1
            count += 2

        else:
            file_list.append(blob.name)

            with open(args.other, 'w') as f:
                f.write(str(blob.name))

    log_input = {
        "uuid": uuid,
        "actionjobuid": f"pipeline-{time}",
        "action": action,
        "stage": "validation",
        "status": "pass",
        "desc": (", ").join(file_list),
        "vaijobid": f"uv-{time}",
        "workflowitems": "v"
    }
    query_job = bq_utils.insert_to_pipeline_logs(
        log_input
    )
    logger.debug(f"Query job id for insert_to_pipeline_logs : {query_job.job_id}")

    if common_file == 0:
        logger.debug(
            "A file who's path data is not committed to BigQuery is uploaded. Will just add a new row to bigquery to reflect an upload for this modelGUID.")
        with open(args.other_file, 'w') as f:
            f.write("True")

    # This file is used to divert flow in vertexAI
    with open(args.count, 'w') as f:
        f.write(str(count))


def determine_single_file_type(file_path, logger, args, uuid, action, time):

    # log entry
    # Update BigQuery pipeline-logs table
    log_input = {
        "uuid": uuid,
        "actionjobuid": f"pipeline-{time}",
        "action": action,
        "stage": "validation",
        "status": "pass",
        "desc": f"{file_path}",
        "vaijobid": f"uv-{time}",
        "workflowitems": "v"

    }
    bucket = gcs_utils.get_bucket()
    single_blob = bucket.get_blob(file_path)

    if (str(file_path).split('.')[-1] == 'json' and str(file_path).split('/')[-1].split('__')[0].lower() == 'model_metadata'):
        logger.info("Model Metadata.json found.")

        # Write logic for next component
        with open(args.validation, 'w') as f:
            f.write("True_single")

        with open(args.model_metadata, 'w') as f:
            f.write(str(single_blob.name)+'$'+str(single_blob.generation))

        # Update BigQuery pipeline-logs table

        query_job = bq_utils.insert_to_pipeline_logs(
            log_input
        )
        logger.debug(f"Query job id for insert_to_pipeline_logs : {query_job.job_id}")

    elif(str(file_path).split('.')[-1] == 'py' and str(file_path).split('/')[-1].split('__')[0].lower() == 'inference_script'):
        logger.info("Inference script found.")

        with open(args.inference, 'w') as f:
            f.write("True_single")

        with open(args.inference_script, 'w') as f:
            f.write(str(single_blob.name)+'$'+str(single_blob.generation))

        # Update BigQuery pipeline-logs table

        query_job = bq_utils.insert_to_pipeline_logs(
            log_input
        )
        logger.debug(f"Query job id for insert_to_pipeline_logs : {query_job.job_id}")

    elif((str(file_path).split('.')[-1] == 'pkl' or str(file_path).split('.')[-1] == 'pb' or str(file_path).split('.')[-1] == 'bst' or str(file_path).split('.')[-1] == 'joblib') and str(file_path).split('/')[-1].split('__')[0].lower() == 'model_weight'):
        logger.info("Model weight file found.")

        with open(args.model, 'w') as f:
            f.write("True_single")

        with open(args.model_file, 'w') as f:
            f.write(str(single_blob.name)+'$'+str(single_blob.generation))

        query_job = bq_utils.insert_to_pipeline_logs(
            log_input
        )
        logger.debug(f"Query job id for insert_to_pipeline_logs : {query_job.job_id}")

    elif(str(file_path).split('/')[-1].split('__')[0].lower() == 'targetassignmentlistfile' and str(file_path).split('.')[-1] == 'csv'):

        with open(args.targetfilepath, 'w') as f:
            f.write(str(single_blob.name)+'$'+str(single_blob.generation))

        # Update BigQuery pipeline-logs table

        query_job = bq_utils.insert_to_pipeline_logs(
            log_input
        )
        logger.debug(f"Query job id for insert_to_pipeline_logs : {query_job.job_id}")

    else:
        logger.info(f"{str(file_path).split('/')[-1]} file is not used for any workflow....")

        with open(args.other_file, 'w') as f:
            f.write("True")

        with open(args.other, 'w') as f:
            f.write(str(single_blob.name)+'$'+str(single_blob.generation))

        query_job = bq_utils.insert_to_pipeline_logs(
            log_input
        )

        logger.debug(f"Query job id of insert_to_pipeline_logs : {query_job.job_id}")
