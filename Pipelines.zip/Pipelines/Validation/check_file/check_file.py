import argparse
import io
from pathlib import Path
from zipfile import ZipFile
from google.cloud import storage
import config
from bq_utils import insert_to_pipeline_logs
from app_logger import CustomLogger

logger = CustomLogger(__name__, "check_file_log")


class CheckFile:
    """
    This class detects what kind of files have been uploaded to the platform
    and directs the flow accordingly.
    """

    def __init__(self, uuid, file_path: str, proces_time):
        """Object initialization."""
        self.uuid = uuid
        self.file_path = file_path
        self.proces_time = proces_time
        self.file_list = []  # file list which will contain extracted file names
        self.unzip_files = []
        self.action = 'check file type'
        self.count = 0  # Used to direct flow in the validation pipeline
        self.common_file = 0

    def _refresh_storage_instance(self) -> None:
        """Use to create a new storage client each time any function is called."""
        self.storage_client = storage.Client()

    def get_blob(self, gcs_uri_suffix):
        """get the blob from the gcs file uri suffix which excludes 'gs://' and bucket path"""
        self._refresh_storage_instance()
        bucket = self.storage_client.get_bucket(config.INPUT_BUCKET_NAME)

        return bucket.get_blob(gcs_uri_suffix)

    def upload_blob_from_str(self, content, blob_name):
        """Upload string contents into a blob object in GCS."""
        self._refresh_storage_instance()
        bucket = self.storage_client.get_bucket(config.INPUT_BUCKET_NAME)
        blob = bucket.blob(blob_name)
        blob.upload_from_string(content)

<<<<<<< HEAD
        if len(blob.name.split('/')) == 2:
            self.unzip_files.append(blob.name)
=======
        # NOTIFICATION
        dl_list = [uploadby]
        # Don't have ModelGUID at this moment.
        subject = f"Validation | Validation Failed"
        msg = f"""Hey, Validation has failed because of the following reasons:
        BUCKET {config.INPUT_BUCKET_NAME} NOT FOUND."""
        req_data=gcs_utils.send_notification(uuid, dl_list, subject, msg)
        logger.debug(req_data)
>>>>>>> origin/sumeet_code_optimize

    def _unzip_gcs_file(self, zip_file_path):
        """Below code unzips the file in the bucket."""
        zip_blob = self.get_blob(zip_file_path)
        zipbytes = io.BytesIO(zip_blob.download_as_string())

        with ZipFile(zipbytes, 'r') as myzip:
            logger.debug(f"Contents of zip file: {myzip.namelist()}")
            for contentfilename in myzip.namelist():
                contentfile = myzip.read(contentfilename)
                self.upload_blob_from_str(
                    content=contentfile,
                    blob_name="/".join(self.file_path.split('.')[0].split('/')[:-2]) + '/' + contentfilename,
                )
        logger.info(f"Files extracted successfully.")

    def log_input_to_bq(self):
        """Upload the pipeline_logs table in BigQuery for success."""
        log_input = {
            "uuid": self.uuid,
            "actionjobuid": f"pipeline-{self.proces_time}",
            "action": self.action,
            "stage": "validation",
            "status": "pass",
            "desc": ", ".join(self.file_list),
            "vaijobid": f"uv-{self.proces_time}",
            "workflowitems": "v"
        }
        query_job = insert_to_pipeline_logs(log_input)
        logger.debug(f"Query job id: {query_job.job_id}")

    def _json_file_handler(self, blob, from_zip):
        """Handling the metadata `.json` file."""
        logger.info(f"model metadata found!")
        self.file_list.append(blob.name)

        # Write logic for next component
        with open(args.model_metadata, 'w') as f:
            f.write(f"{blob.name}${blob.generation}")

        if from_zip:
            with open(args.validation, 'w') as f:
                f.write("True")
            self.common_file = 1
            self.count += 1
        else:
            with open(args.validation, 'w') as f:
                f.write("True_single")
            self.log_input_to_bq()

    def _py_file_handler(self, blob, from_zip):
        """Handling the Inference script `.py` file."""
        logger.info(f"Inference script found!")
        self.file_list.append(blob.name)

        with open(args.inference_script, 'w') as f:
            f.write(f"{blob.name}${blob.generation}")

        if from_zip:
            with open(args.inference, 'w') as f:
                f.write("True")
            self.common_file = 1
            self.count += 2
        else:
            with open(args.inference, 'w') as f:
                f.write("True_single")
            self.log_input_to_bq()

    def _weight_file_handler(self, blob, from_zip):
        """Handling the model weight files."""
        logger.info(f"Model weight file found!")
        self.file_list.append(blob.name)

        with open(args.model_file, 'w') as f:
            f.write(f"{blob.name}${blob.generation}")

        if from_zip:
            with open(args.model, 'w') as f:
                f.write("True")
            self.common_file = 1
            self.count += 4
        else:
            with open(args.model, 'w') as f:
                f.write("True_single")
            self.log_input_to_bq()

    def _csv_file_handler(self, blob, from_zip):
        """Handling the test `.csv` file."""
        logger.info(f"targetassignmentlistfile file found!")
        with open(args.targetfilepath, 'w') as f:
            f.write(f"{blob.name}${blob.generation}")

        if not from_zip:
            self.file_list.append(blob.name)
            self.log_input_to_bq()

    def _other_file_handler(self, blob, from_zip):
        """Handling other files which are not relevant to the workflow."""
        logger.info(f"{blob.name.split('/')[-1]} file is not used for any workflow...!")
        self.file_list.append(blob.name)

        with open(args.other, 'w') as f:
            f.write(f"{blob.name}${blob.generation}")

        if not from_zip:
            with open(args.other_file, 'w') as f:
                f.write("True")
            self.file_list.append(self.file_path)
            self.log_input_to_bq()

    def single_file_handler(self, file_path: str, from_zip: bool):
        """To handle each file by check the extension and logging
        the respective logs in BQ and log files.
        """
        blob = self.get_blob(file_path)
        prefix = str(blob.name).split('/')[-1].split('__')[0].lower()
        extension = str(blob.name).split('.')[-1].lower()

        if prefix == 'targetassignmentlistfile':
            if extension == "csv":
                self._csv_file_handler(blob, from_zip)
            else:
                with open(args.targetfilepath, 'w') as f:
                    f.write("NA")
        elif extension == 'json' and prefix == 'model_metadata':
            self._json_file_handler(blob, from_zip)
        elif extension in ('joblib', 'pkl', 'pb', 'bst') and prefix == 'model_weight':
            self._weight_file_handler(blob, from_zip)
        elif extension == 'py' and prefix == 'inference_script':
            self._py_file_handler(blob, from_zip)
        else:
            self._other_file_handler(blob, from_zip)

    def _zip_file_handler(self):
        """Handling the zip file received.
        Steps:
        - unzip the file
        - handle each component file based on the extension.
        """
        prefix = '/'.join(self.file_path.split('.')[0].split('/')[:-2])
        logger.debug(f"Checking the extracted files at location : {prefix}")

        # Check what files are inside the zip folder
        for each_file in self.unzip_files:
            self.single_file_handler(file_path=each_file, from_zip=True)

        self.log_input_to_bq()

        # If no files whoes information is stored gets uploaded
        if not self.common_file:
            logger.debug("A file is uploaded whose path data is not committed to BigQuery. \
                        Will just add a new row to bigquery to reflect an upload for this modelGUID.")
            logger.info("A new file is found which was not not being tracked before.")

            with open(args.other_file, 'w') as f:
                f.write("True")

        # This component is used to divert flow
        with open(args.count, 'w') as file_:
            file_.write(str(self.count))

    def process(self):
        """Main process to check if a zip file has been uploaded or single file
        and then perform the respective operations to validate and log them.
        """
        logger.info("Checking if a zip file has been uploaded.")
        if self.file_path.lower().endswith("zip"):
            self._unzip_gcs_file(self.file_path)
            self._zip_file_handler()
        else:
            # When Single files are uploaded
            self.single_file_handler(file_path=self.file_path, from_zip=False)

        # Writing the components of the log file
        logger.info("Writing the log file of the component.")
        with open("check_file_log") as f:
            with open(args.user_logs, "w") as f1:
                for line in f:
                    f1.write(line)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # Pipeline arguments
    parser.add_argument("--uuid", type=str)
    parser.add_argument("--time", type=str)
    parser.add_argument("--file_path", type=str)
    # Arguments for next component
    parser.add_argument("--model_metadata", type=str)
    parser.add_argument("--validation", type=str)
    parser.add_argument("--inference", type=str)
    parser.add_argument("--inference_script", type=str)
    parser.add_argument("--model", type=str)
    parser.add_argument("--model_file", type=str)
    parser.add_argument("--other_file", type=str)
    parser.add_argument("--other", type=str)
    parser.add_argument("--count", type=str)
    parser.add_argument("--targetfilepath", type=str)
    parser.add_argument("--uploadby", type=str)
    parser.add_argument("--user_logs", type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(f'uv-{args.time}')

    Path(args.model_metadata).parent.mkdir(parents=True, exist_ok=True)
    Path(args.inference).parent.mkdir(parents=True, exist_ok=True)
    Path(args.validation).parent.mkdir(parents=True, exist_ok=True)
    Path(args.inference_script).parent.mkdir(parents=True, exist_ok=True)
    Path(args.model).parent.mkdir(parents=True, exist_ok=True)
    Path(args.model_file).parent.mkdir(parents=True, exist_ok=True)
    Path(args.other_file).parent.mkdir(parents=True, exist_ok=True)
    Path(args.other).parent.mkdir(parents=True, exist_ok=True)
    Path(args.count).parent.mkdir(parents=True, exist_ok=True)
    Path(args.targetfilepath).parent.mkdir(parents=True, exist_ok=True)
    Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)

    logger.debug(f"Pipeline inputs: {args}")
    check_file = CheckFile(args.uuid, args.file_path, args.time)
    check_file.process()
