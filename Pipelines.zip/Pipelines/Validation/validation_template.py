import kfp.v2
from kfp.v2 import compiler,dsl

@dsl.pipeline(name=f"upload", description='Creating the upload component')
def first_pipeline(bucket_name :str,
                   file_path:str,
                   UUID:str,
                   modelGUID:str,
                   uploadedBy:str,
                   time:str,
                  ):
    
     # Loads the yaml manifest for each component
    
    check_file                  = kfp.components.load_component_from_file('Upload/new_upload/02_check_file/component.yaml')
    validate                    =kfp.components.load_component_from_file('Upload/new_upload/03_validate_metadata/component.yaml')
    insert                      =kfp.components.load_component_from_file('Upload/new_upload/04_insert/component.yaml')
    update_readiness            =kfp.components.load_component_from_file('Upload/new_upload/05_update_readiness/component.yaml')
    workflow_trigger            =kfp.components.load_component_from_file('Upload/new_upload/06_workflow/component.yaml')
    
    check_file_task = check_file(UUID,bucket_name,file_path,time,uploadedBy)
    
    #IF ONLY validation and inference script file is present 
    
    with dsl.Condition(check_file_task.outputs['count']=='7', name='Metadata-inference-Model-Present'):
        validate_task=validate(UUID,bucket_name,check_file_task.outputs['model_metadata'],time,uploadedBy).after(check_file_task)
        insert_task=insert(UUID,modelGUID,bucket_name,check_file_task.outputs['model_metadata'],
                           check_file_task.outputs['inference_script'],check_file_task.outputs['model_file'],check_file_task.outputs['targetfile'],
                          uploadedBy).after(validate_task)
        
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,validate_task.outputs['expectedfileList'],"").after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
        
   
    with dsl.Condition( check_file_task.outputs['count']=='5',name='Metadata-Model-Present'):
        validate_task=validate(UUID,bucket_name,check_file_task.outputs['model_metadata'],time,uploadedBy).after(check_file_task)
        insert_task=insert(UUID,modelGUID,bucket_name,check_file_task.outputs['model_metadata'],check_file_task.outputs['targetfile'],
                           "",check_file_task.outputs['model_file'],
                          uploadedBy).after(validate_task)
        
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,validate_task.outputs['expectedfileList'],"").after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
    
    with dsl.Condition( check_file_task.outputs['count']=='6', name='Inference-Model-Present'):
        insert_task=insert(UUID,modelGUID,bucket_name,"",
                          check_file_task.outputs['inference_script'],check_file_task.outputs['model_file'],check_file_task.outputs['targetfile'],
                          uploadedBy)
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,"",check_file_task.outputs['inference_script']).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
    
    with dsl.Condition(check_file_task.outputs['count']=='4', name='Model-Present'):
        insert_task=insert(UUID,modelGUID,bucket_name,"","",check_file_task.outputs['model_file'],check_file_task.outputs['targetfile'],uploadedBy)
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,"",check_file_task.outputs['model_file']).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
    
    with dsl.Condition((check_file_task.outputs['model']=='True_single'), name='Model-Present'):
        insert_task=insert(UUID,modelGUID,bucket_name,"","",check_file_task.outputs['model_file'],check_file_task.outputs['targetfile'],uploadedBy)
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,"",check_file_task.outputs['model_file']).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
        

    with dsl.Condition(check_file_task.outputs['count']=='3', name='Metadata-inference-Present'):
        validate_task=validate(UUID,bucket_name,check_file_task.outputs['model_metadata'],time,uploadedBy).after(check_file_task)
        insert_task=insert(UUID,modelGUID,bucket_name,check_file_task.outputs['model_metadata'],
                           check_file_task.outputs['inference_script'],"",check_file_task.outputs['targetfile'],
                          uploadedBy).after(validate_task)
        
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,validate_task.outputs['expectedfileList'],"").after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)

    
    with dsl.Condition(check_file_task.outputs['validation']=="True_single", name='Metadata-Present'):
        validate_task=validate(UUID,bucket_name,check_file_task.outputs['model_metadata'],time,uploadedBy).after(check_file_task)
        insert_task=insert(UUID,modelGUID,bucket_name,check_file_task.outputs['model_metadata'],"","",check_file_task.outputs['targetfile'],uploadedBy).after(validate_task)
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,validate_task.outputs['expectedfileList'],"").after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
        
    
    with dsl.Condition(check_file_task.outputs['count']=='1', name='Metadata-Present'):   
        validate_task=validate(UUID,bucket_name,check_file_task.outputs['model_metadata'],time,uploadedBy).after(check_file_task)
        insert_task=insert(UUID,modelGUID,bucket_name,check_file_task.outputs['model_metadata'],"","",check_file_task.outputs['targetfile'],uploadedBy).after(validate_task)
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,validate_task.outputs['expectedfileList'],"").after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
        
    
    
    with dsl.Condition(check_file_task.outputs['inference']=='True_single', name='Inference-Present'):
        insert_task=insert(UUID,modelGUID,bucket_name,"",check_file_task.outputs['inference_script'],"",check_file_task.outputs['targetfile'],uploadedBy)
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,"",check_file_task.outputs['inference_script']).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
        
    
    with dsl.Condition(check_file_task.outputs['count']=='2', name='Inference-Present'): 
        insert_task=insert(UUID,modelGUID,bucket_name,"",check_file_task.outputs['inference_script'],"",check_file_task.outputs['targetfile'],uploadedBy)
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,"",check_file_task.outputs['inference_script']).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
    
    
    
    with dsl.Condition(check_file_task.outputs['other_file']=='True', name='Standard-files-absent'):
        insert_task=insert(UUID,modelGUID,bucket_name,"","","",check_file_task.outputs['targetfile'],uploadedBy)
        update_readiness_task = update_readiness(UUID,modelGUID,bucket_name,"",check_file_task.outputs['other']).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID,time).after(update_readiness_task)
    

if __name__ == '__main__':
    compiler.Compiler().compile(pipeline_func=first_pipeline, package_path='validation_workflow.json')