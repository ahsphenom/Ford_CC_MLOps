from aifc import Error
import ast
import datetime
from errno import EROFS
from glob import glob
import re
import subprocess
import utils
import config
from app_logger import CustomLogger
from marshmallow import (
    Schema, fields, validate, validates,
    validates_schema
)

# Create logger object
logger = CustomLogger(__name__, 'validate_metadata_log')

error=0


def check_version(data, version_list):
    global error
    try:
        flag = True
        for item in data['version'].split('-'):
            if type(ast.literal_eval(item)) != int:
                flag = False
                logger.error(f"Framework-version provided for {data['frameworkName']} is not in expected format.")
                error+=1
                

        if flag:
            output_string = "-".join(data['version'].split('-')[:2])
            logger.debug("The framework-version syntax is valid.")
            # Check for VAI version
            if output_string in version_list:
                logger.debug(f"{output_string} in {version_list}")
            else:
                logger.error(
                    f"Framework-version provided for {data['frameworkName']} is not one of the  supported version on VertexAI.")
                error+=1

    except SyntaxError:
        logger.error("Invalid version: Syntax.")


class traindataset(Schema):
    fileName = fields.String(required=True)

    @validates_schema
    def validate_traindataset(self, data, **kwargs):
        global error
        if len(data["fileName"].split('.')) > 1:
            logger.debug("trainDataset-fileName key value is valid.")
            

        elif data["fileName"] == "":
            logger.debug(f"trainDataset filename has an empty string associated with it. User has not passed in a filename.")

        else:
            logger.error('Check the filename given to the trainDataset key. Accepted values are filename.extension or empty string. ')
            error+=1

class testdataset(Schema):
    
    fileName = fields.String()
    is_raw_data = fields.String()
    is_preproc_and_Y = fields.String()

    @validates_schema
    def validate_testdataset(self, data, **kwargs):
        global error

        if len(data["fileName"].split('.')) > 1:
            utils.validate_testdata_with_filename(data,logger)
            
        elif data["fileName"] == "":
            utils.validate_testdata_without_filename(data,logger)
            
        else:
            logger.error('Check the filename given to the testDataset key.Accepted values are filename.extension or empty string. ')
            error+=1

class framework(Schema):
    frameworkName = fields.String(required=True)
    version = fields.String(required=True)
    format = fields.String(required=True)

    @validates_schema
    def check_version_format(self, data, **kwargs):
        global error 

        framework = data['frameworkName'].lower()
        file_format = data['format']

        # Check version number of frameworkuse with what is present on vertexAI
        if framework == 'xgboost':
            p1 = subprocess.run(config.xgboost_image_path, shell=True, capture_output=True, text=True)
            version_list = [image.split('.')[-1] for image in str(p1.stdout).split('\n') if image.split('.')[-1] != '']
            check_version(data, version_list)
            logger.debug(f"Version list available for {data['frameworkName']} in vertexAI include {version_list}")

        elif framework == 'scikit-learn':
            p1 = subprocess.run(config.sklearn_image_path, shell=True, capture_output=True, text=True)
            version_list = [image.split('.')[-1] for image in str(p1.stdout).split('\n') if image.split('.')[-1] != '']

            check_version(data, version_list)
            logger.debug(f"Version list available for {data['frameworkName']} in vertexAI include {version_list}")

        elif framework == 'tensorflow':
            p1 = subprocess.run(config.tf_image_path, shell=True, capture_output=True, text=True)
            version_list = [image.split('.')[-1] for image in str(p1.stdout).split('\n') if image.split('.')[-1] != '']

            check_version(data, version_list)
            logger.debug(f"Version list available for {data['frameworkName']} in vertexAI include {version_list}")
        else:
            logger.error(f"Framework-version {data['version']} is not one of the  supported version on VertexAI")
            error+=1

        if(
            (framework == "xgboost" and (file_format == "pkl" or file_format == "bst" or file_format == "joblib"))
            or
            (framework == "scikit-learn" and (file_format == "pkl" or file_format == "joblib"))
            or
            (framework == "tensorflow" and file_format == "pb")
        ):

            logger.debug(f"{framework} and {file_format} combination valid.")
        else:
            logger.debug(f"{framework} does not support {file_format} as a valid file format.")


class deployment(Schema):
    toCloud = fields.String(validate=validate.OneOf(["", 'true', 'false']))
    toEdge = fields.String(validate=validate.OneOf(["", 'true', 'false']))


class testing(Schema):
    toTest = fields.String(validate=validate.OneOf(["", 'true', 'false']))


class stages(Schema):
    testing = fields.Nested(testing)
    deployment = fields.Nested(deployment)


class specifications(Schema):
    whenToRun = fields.String()

    @validates_schema
    def validate_whentorun(self, data, **kwargs):
        global error

        try:
            if datetime.datetime.strptime(data["whenToRun"], '%Y-%m-%d %H:%M:%S'):
                logger.debug("datetime provided is correct.")
        except Exception:
            if data['whenToRun'] == "":
                logger.debug("datetime provided is correct.")
            else:
                logger.error(
                    'Given timestamp format under workflows-specifications-whenToRun not correct. Expected input is 2022-02-02 08:06:45 or it should be a empty string.')
                error+=1

class stages_specifications(Schema):
    stages = fields.Nested(stages)
    specifications = fields.Nested(specifications)


class Thresholds(Schema):
    warningThreshold = fields.List(fields.Float, required=True)
    criticalThreshold = fields.List(fields.Float, required=True)

    @validates_schema
    def thresholds(self, value, **kwargs):
        global error

        if len(value["warningThreshold"]) == 4:
            for threshold in value['warningThreshold']:
                if re.match(config.THRESHOLDS, str(threshold)) is None:
                    logger.error(
                        f"warningThreshold value {threshold} should be a float between [0,1] or 0.0 for missing/not-provided threshold.")
                    error+=1
        else:
            logger.error(f'warningThreshold {value["warningThreshold"]} length is not 4.')
            error+=1

        if len(value["criticalThreshold"]) == 4:
            for threshold in value['criticalThreshold']:
                if re.match(config.THRESHOLDS, str(threshold)) is None:
                    logger.error(
                        f"criticalThreshold value {threshold} should be a float between [0,1] or 0.0 for missing/not-provided threshold.")
                    error+=1
        else:
            logger.error(f'criticalThreshold {value["criticalThreshold"]} length is not 4.')
            error+=1


class driverschema(Schema):
    vin = fields.String(validate=validate.Regexp(config.VIN_REGEX, error='vin given does not follow the given regex.'))
    driverID = fields.List(fields.String(validate=validate.Regexp(
        config.DRIVER_ID_REGEX, error='driverid does not follow the regex.')))


class targetschema(Schema):
    programCode = fields.String(
        validate=validate.Regexp(
            config.PROGRAM_CODE_REGEX,
            error='progamCode does not follow the given regex.'
        )
    )
    featureCode = fields.String(
        validate=validate.Regexp(
            config.FEATURE_CODE_REGEX,
            error='featureCode does not follow the given regex.'
        )
    )
    familyCode = fields.String(
        validate=validate.Regexp(
            config.FAMILY_CODE_REGEX,
            error='familyCode does not follow the given regex.'
        )
    )
    modelYear = fields.String(
        validate=validate.Regexp(
            config.MODEL_YEAR_REGEX,
            error='modelyear does not follow the given regex.'
        )
    )


class scoreschema(Schema):
    lt_value = fields.Float()
    gt_value = fields.Float()
    margin = fields.Float()
    filename = fields.String(required=True)
    lower_limit = fields.Float(required=True)
    upper_limit = fields.Float(required=True)

    @validates_schema
    def validate_scoreschema(self, data, **kwargs):
        global error

        if data.get("gt_value"):
            if data["lower_limit"] <= data['gt_value'] <= data['upper_limit']:
                logger.debug(
                    f"gt_value {data['gt_value']} lies between upper_limit and lower_limit values provided by the user.")
            else:
                logger.error(
                    f"gt_value {data['gt_value']} should lie between upper_limit and lower_limit values provided by the user.")
                error+=1

        if data.get("lt_value"):
            if data["lower_limit"] <= data['lt_value'] <= data['upper_limit']:
                logger.debug(
                    f"lt_value {data['gt_value']} lies between upper_limit and lower_limit values provided by the user.")
            else:
                logger.error(
                    f"lt_value {data['lt_value']} should lie between upper_limit and lower_limit values provided by the user.")
                error+=1
                

class MetaData(Schema):
    expectedListOfFile = fields.List(fields.String(), required=True)
    modelGUID = fields.String(validate=validate.Regexp(config.MODELGUID_REGEX,
                              error=f"modelGUID does not satify the given regex."), required=True)
    modelName = fields.String(required=True, error="modelName should be of type string.")
    modelDescription = fields.String(required=True, error="modelDescription should be of type string.")
    modelVersion = fields.String(validate=validate.Regexp(
        config.MODEL_VERSION, error=f"modelVersion does not satify the given regex."), required=True)
    modelUseCaseID = fields.String(required=True, error="modelUseCaseID should be of type string.")
    modelUseCase = fields.String(required=True, error="modelUseCase should be of type string.")
    modelType = fields.String(required=True)
    modelSubType = fields.String(required=True)
    frameworkInfo = fields.Nested(framework, required=True)
    trainingScores = fields.Dict(keys=fields.String(), values=fields.Float(), required=True)
    modelDependency = fields.List(fields.String(), required=True)
    trainDataset = fields.Nested(traindataset, required=True)
    testDataset = fields.Nested(testdataset, required=True)
    workflows = fields.Nested(stages_specifications, required=True)
    monitoringThresholds = fields.Nested(Thresholds, required=True)
    policyTarget = fields.String(required=True, validate=validate.OneOf(['Generalized', 'Personalized', 'None'],
                                                                        error='value given for policy type not one of recognized type.'))

    testingThresholdScores = fields.Dict(keys=fields.String(), values=fields.Nested(scoreschema))
    targetAssignmentListFile = fields.String()
    driverAssignment = fields.Nested(driverschema,
                                     validate=validate.Length(min=0,
                                                              error='Field is an empty list. Data not provided.'),
                                     many=True, required=True
                                     )
    targetAssignment = fields.Nested(targetschema,
                                     validate=validate.Length(min=0,
                                                              error='Field is an empty list. Data not provided.'),
                                     many=True, required=True
                                     )
    modelOwnerDistributionList = fields.List(fields.Email(), required=True)

    @validates("targetAssignmentListFile")
    def validate_targetAssignmentListFile(self, value):
        global error
        if value == "" or value == '' or (isinstance(value, str) and str(value).split('.')[-1] == 'csv'):
            logger.debug("targetAssignmentListFile field is valid.")
        else:
            logger.error("targetAssignmentListFile field entry is not valid.")
            error+=1

    @validates("modelType")
    def validate_quantity(self, value):
        global error
        if value.lower() not in config.MODELTYPE:
            logger.error("value can be one of Regression or Classification.")
            error+=1

    @validates("modelDependency")
    def validate_modeldependency(self, value):
        global error
        for guid in value:
            if re.match(config.MODELGUID_REGEX, guid) is None:
                logger.error(
                    f"model_dependency {value} does not match regex for modelGUID.")
                error+=1

    @validates("trainingScores")
    def traning_score(self, item):

        for key, score in item.items():
            global error
            if not isinstance(score, float):
                logger.error(
                    f"trainingScores for {key} {score} is not a float value.")
                error+=1

    @validates_schema
    def validate_policytarget(self, data, **kwargs):
        global error

        policyTarget = str(data['policyTarget'].lower())

        if(policyTarget == 'personalized' and isinstance(data.get('targetAssignmentListFile', False), str) and len(data.get('targetAssignmentListFile', "")) >= 1) \
                and len(data.get('driverAssignment', [])) == 0 and len(data.get('targetAssignment', [])) == 0 and data.get('targetAssignmentListFile', False).split('.')[-1] == 'csv':

            logger.debug("policyTarget conditions met for personalized with targetAssignmentListFile.")

        elif(policyTarget == 'personalized' and isinstance(data.get('driverAssignment', False), list) and len(data.get('driverAssignment', [])) >= 1 and data.get('targetAssignmentListFile', "") == "" and data.get('targetAssignment', False) == []):
            logger.debug("Policy target conditions met for personalized type with vin data passed in metadata.json file.")

        elif (policyTarget == 'generalized' and isinstance(data.get('targetAssignmentListFile', False), str) and len(data.get('targetAssignmentListFile', "")) >= 1) \
                and len(data.get('driverAssignment', [])) == 0 and len(data.get('targetAssignment', [])) == 0 and data.get('targetAssignmentListFile', False).split('.')[-1] == 'csv':

            logger.debug("policyTarget conditions met for generalized with targetAssignmentListFile.")

        elif(policyTarget == 'generalized' and isinstance(data.get('targetAssignment', False), list) and len(data.get('targetAssignment', [])) >= 1 and data.get('targetAssignmentListFile', "") == "" and data.get('driverAssignment', False) == []):
            logger.debug("Policy target conditions met for generalized type with vin data passed in metadata.json file.")

        elif (policyTarget == 'none'):
            logger.debug("Policy target information not provided by the user.")

        else:
            logger.error(f"Required fields for policyTarget not present according to the set rules.")
            error+=1

    @validates_schema
    def validate_testingThresholdScores(self, data, **kwargs):
        global error

        testing_keys = data["testingThresholdScores"].keys()
        for metric in testing_keys:

            logger.debug(f"Checking for metric: {metric}")

            if(set(data["testingThresholdScores"][metric].keys()) == set(['gt_value', 'margin', 'upper_limit', 'lower_limit', 'filename'])):
                logger.debug(f"testingThresholdScores schema for {metric} is valid")

            elif(set(data["testingThresholdScores"][metric].keys()) == set(['lt_value', 'margin', 'upper_limit', 'lower_limit', 'filename'])):
                logger.debug(f"testingThresholdScores schema for {metric} is valid")

            elif(set(data["testingThresholdScores"][metric].keys()) == set(['lt_value', 'gt_value', 'upper_limit', 'lower_limit', 'filename'])):
                logger.debug(f"testingThresholdScores schema for {metric} is valid")

            else:
                logger.error(
                    f"The keys for metric {metric} does not match the required field. Check the manual for the keys format.")
                error+=1
