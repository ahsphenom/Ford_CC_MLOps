import json
from marshmallow_validator import error
import gcs_utils
import config
import re
import pandas as pd 

def load_metadata(bucket,model_metadata):

    
    blob = bucket.get_blob(model_metadata.split('$')[0])
    data = json.loads(blob.download_as_string(client=None))
    

    return data

def validate_testdata_with_filename(data,logger):
    global error
    if data["is_raw_data"] == 'true' or data["is_raw_data"] == 'false':
        logger.debug("testDataset-is_raw_data key value provided is valid.")

    else:
        logger.error("is_raw_data key  value should be either true or false.")
        error+=1

    if data["is_preproc_and_Y"] == 'true' or data["is_preproc_and_Y"] == 'false':
        logger.debug("testDataset-is_preproc_and_Y key value is valid.")

    else:
        logger.error("is_preproc_and_Y key value should be either true or false.")
        error+=1

def validate_testdata_without_filename(data,logger):
    global error

    logger.debug(f"testDataset filename has an empty string associated with it. User has not passed in a filename.")

    if data["is_raw_data"] == 'false':
        logger.debug("testDataset-is_raw_data key value is valid.")

    else:
        logger.error("is_raw_data key value should be false since testDataset fileName is not passed.")
        error+=1

    if data["is_preproc_and_Y"] == 'false':
        logger.debug("testDataset-is_preproc_and_Y key value is valid.")

    else:
        logger.error("is_preproc_and_Y key value should be false since testDataset fileName is not passed.")
        error+=1

def validate_generalized_csv_file(modelYear,programCode,familyCode,featureCode,logger):
    global error

    for year in modelYear:
        if re.match(config.MODEL_YEAR_REGEX, year) is None:
            logger.error(f'modelYear {year} does not follow the given regex.')
            error+=1
    
    for program in programCode:
        if re.match(config.PROGRAM_CODE_REGEX, program) is None:
            logger.error(f'programCode {program} does not follow the given regex.')
            error+=1
    
    for family in familyCode:
        if re.match(config.FAMILY_CODE_REGEX, family) is None and family!="None":
            logger.error(f'familyCode {family} does not follow the given regex.User can skip this input by providing keyword None.')
            error+=1

    for feature in featureCode:
        if re.match(config.FEATURE_CODE_REGEX, feature) is None and feature!='None':
            logger.error(f'featureCode {feature} does not follow the given regex.User can skip this input by providing keyword None.')
            error+=1

def load_and_validate_generalized_policy_target(logger,targetfile,data,uploadedby,uuid):
    global error
    
    try:
                
        vinfile = pd.read_csv(
            f"gs://{config.INPUT_BUCKET_NAME}/{str(targetfile).split('$')[0]}", dtype={'modelYear': str, 'programCode': str, 'familyCode': str,
                                                                                        'featureCode': str}, skipinitialspace=True)
        vinfile.dropna(thresh=5, inplace=True, axis=0)

    except Exception as e:
        logger.error(
            'Issue while loading targetAssignmentListfile in pandas.')
        logger.error(e)
        error+=1

        # NOTIFICATION
        dl_list = data.get("modelOwnerDistributionList", [uploadedby])
        subject = f"Validation : Validation Fail: {data.get('modelGUID','NA')}"
        msg = f"""Hey, Validation has failed because of the following reasons: Failure to open targetAssignmentListFile.csv"""
        req_data = gcs_utils.send_notification(uuid, dl_list, subject, msg)
        logger.debug(req_data)


    if set(['modelYear','programCode', 'familyCode','featureCode']).issubset(set(vinfile.columns)):
        modelYear = vinfile['modelYear']
        programCode = vinfile['programCode']
        featureCode = vinfile['featureCode']
        familyCode = vinfile['familyCode']

        assert len(modelYear) == len(programCode) == len(familyCode) == len(featureCode)

    else:
        logger.error(
            "Required columns not in correct form targetassignmentlistfile for generalized policy target \
            All columns must be present and should be of equal length. Unable to extact vinlist from VSS service")
        error+=1

        # NOTIFICATION
        dl_list = data.get("modelOwnerDistributionList", [uploadedby])
        subject = f"Validation : Validation Fail: {data.get('modelGUID','NA')}"
        msg = f"""Hey, Validation has failed because of the following reasons: modelYear and programCode does not have the same length."""
        req_data = gcs_utils.send_notification(uuid, dl_list, subject, msg)
        logger.debug(req_data)
    
    #Validate each entry 

    validate_generalized_csv_file(modelYear,programCode,familyCode,featureCode,logger)

    
def validate_personalized_csv_file(vin,driverid,logger):
    global error
    for v in vin:
        if re.match(config.VIN_REGEX, v) is None:
            logger.error(f'vin {v} does not follow the given regex.')
            error+=1
    
    for id in driverid:
        if re.match(config.DRIVER_ID_REGEX, id) is None:
            logger.error(f'driverID {id} does not follow the given regex.')
            error+=1


def load_and_validate_personalized_policy_target(logger,targetfile,data,uploadedby,uuid):
    global error
    try:
        vinfile = pd.read_csv(
            f"gs://{config.INPUT_BUCKET_NAME}/{str(targetfile).split('$')[0]}",
            converters={'driverID': pd.eval},
            skipinitialspace=True
        )
    except Exception as e:
        logger.error(
            'Issue while load targetAssignmentListfile in pandas.')
        error+=1

        # NOTIFICATION
        dl_list = data.get("modelOwnerDistributionList", [uploadedby])
        subject = f"Validation : Validation Fail: {data.get('modelGUID','NA')}"
        msg = f"""Hey, Validation has failed because of the following reasons: Cannot open targetAssignmentListFile.csv"""
        req_data = gcs_utils.send_notification(uuid, dl_list, subject, msg)
        logger.debug(req_data)

    vinfile.dropna(thresh=3, inplace=True, axis=0)

    if 'vin' in vinfile.columns:
        vin = vinfile['vin']
    else:
        logger.error(f"vin column not in targerassignmentlistfile.")

    if 'driverID' in vinfile.columns:
        driverid = vinfile['driverID']
    else:
        logger.error(
            f"driverID column not in targerassignmentlistfile.")
        error+=1
    

    #Validate the contents of the file 

    validate_personalized_csv_file(vin,driverid,logger)

    



    



