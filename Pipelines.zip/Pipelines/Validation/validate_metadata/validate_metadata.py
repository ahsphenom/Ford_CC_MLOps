import argparse
import json
import sys
from pathlib import Path

import bq_utils
import config
import gcs_utils
import utils
from marshmallow import ValidationError
from marshmallow_validator import MetaData,error,logger


def validate_target_file(data, uuid, targetfile, uploadedby):
    
    # The below code is executed if policy target information is passed inside csv file
    if (data.get("targetAssignmentListFile", "") and data.get("policyTarget", "none").lower() == 'generalized' and targetfile != "NA" and data.get('driverAssignment', []) == [] and data.get('targetAssignment', []) == []):

        logger.info("Validationg targetAssignmentListFile info for generalized case.")
        
        utils.load_and_validate_generalized_policy_target(logger,targetfile,data,uploadedby,uuid)

    elif (data.get("targetAssignmentListFile", "") and data.get("policyTarget", "none").lower() == 'personalized' and targetfile != "NA" and data.get('driverAssignment', []) == [] and data.get('targetAssignment', []) == []):

        logger.info("Validation targetAssignmentListFile info for personalized case.")


        utils.load_and_validate_personalized_policy_target(logger,targetfile,data,uploadedby,uuid)
    
    else:
        logger.debug("No targetAssignmentListFile is provided.")

    
def validate_metadata_file(uuid, model_metadata,targetfile, time, uploadby):
    """
    This function validates metadata file as per the standard checks. Refer to the TDD for details.
    """
    action = "validate metadata file"
    error_list = []

    # Get the bucket
    try:
        bucket = gcs_utils.get_bucket()
    except Exception as e:
        logger.error(f"BUCKET {config.INPUT_BUCKET_NAME} NOT FOUND.")
        logger.error(e)

        # NOTIFICATION
        dl_list = [uploadby]
        # Don't have ModelGUID at this moment.
        subject = f"Validation | Validation Failed"
        msg = f"""Hey, Validation has failed because of the following reasons:
        BUCKET {config.INPUT_BUCKET_NAME} NOT FOUND."""
        gcs_utils.send_notification(uuid, dl_list, subject, msg)

        logger.debug(f"Notification sent to {uploadby}")

        log_input = {
            "uuid": uuid,
            "actionjobuid": f"pipeline-{time}",
            "action": action,
            "stage": "validation",
            "status": "fail",
            "desc": f"Bucket {config.INPUT_BUCKET_NAME} not found.",
            "vaijobid": f"uv-{time}",
            "workflowitems": "v"
        }

        # Insert to BiqQuery Pipeline log table if the bucket not found and stop execution
        bq_utils.insert_to_pipeline_logs(
            log_input
        )

        sys.exit()

    # Load the metadata file
    try:
        data = utils.load_metadata(bucket, model_metadata)
    except Exception as e:
        logger.error(f"Unable to load Model Metadata.json file")

        # NOTIFICATION
        dl_list = [uploadby]
        subject = f"Validation | Validation Fail"
        msg = f"""Hey, Validation has failed because of the following reasons:
        Unable to load Model Metadata.json file"""

        gcs_utils.send_notification(uuid, dl_list, subject, msg)
        logger.debug(f"Notification sent to {uploadby}")

        # Insert to BiqQuery Pipeline log table

        log_input = {
            "uuid": uuid,
            "actionjobuid": f"pipeline-{time}",
            "action": action,
            "stage": "validation",
            "status": "fail",
            "desc":  f"Unable to load Model Metadata.json file",
            "vaijobid": f"uv-{time}",
            "workflowitems": "v"
        }
        bq_utils.insert_to_pipeline_logs(
            log_input
        )
        sys.exit()

    # Validate Metadata.json file
    schema = MetaData()

    try:
        schema.load(data)
    except ValidationError as err:
        logger.error(err.messages)
        global error
        error+=1
    
    #Validated target file assignment file if present
    validate_target_file(data, uuid, targetfile, uploadby)


    # CREATING A EXPECTED LIST OF FILES

    try:
        blob = bucket.blob(model_metadata.split('/')[0]+'/'+'ExpectedFiles.json')
    except Exception as e:
        logger.error("Error while creating ExpectedFiles.json")
        error_list.append("Error while creating ExpectedFiles.json")

    blob.upload_from_string(
        data=json.dumps(data.get("expectedListOfFile", 'NAN')),
        content_type='application/json'
    )

    # Passing the filepath
    with open(args.expectedfileList, 'w') as f:
        f.write(model_metadata.split('/')[0]+'/'+'ExpectedFiles.json')

    # Check if the metadata validation is pass or fail
    
    if error!=0:  

        logger.info("Validate metadata check completed.")
        logger.info("Error present in the meta file")

        log_input = {
            "uuid": uuid,
            "actionjobuid": f"pipeline-{time}",
            "action": action,
            "stage": "validation",
            "status": "fail",
            "desc": "See log for details.",
            "vaijobid": f"uv-{time}",
            "workflowitems": "v"
        }

        query_job = bq_utils.insert_to_pipeline_logs(
            log_input
        )
        logger.debug(f"Query job id: {query_job.job_id}")

        # NOTIFICATION
        dl_list = data.get("modelOwnerDistributionList", [uploadby])
        subject = f"Validation | Validation Fail: modelGUID | {data.get('modelGUID')}"
        msg = f"""Hey, Validation has failed check logs for details"""

        req_data = gcs_utils.send_notification(uuid, dl_list, subject, msg)
        logger.debug(req_data)

    else:
        logger.info('Model Metadata File Check Completed successfully without any errors.')
        error_list.append("Model Metadata File Check Completed successfully without any errors.")

        # Update the logs in Big query pipeline logs
        log_input = {
            "uuid": uuid,
            "actionjobuid": f"pipeline-{time}",
            "action": action,
            "stage": "validation",
            "status": "pass",
            "desc": "Model Metadata File Check completed successfully without any errors.",
            "vaijobid": f"uv-{time}",
            "workflowitems": "v"
        }

        query_job = bq_utils.insert_to_pipeline_logs(
            log_input
        )
        logger.debug(f"Query job id: {query_job.job_id}")

        # NOTIFICATION
        dl_list = data.get("modelOwnerDistributionList", [uploadby])
        subject = f"Validation | Validation pass: modelGUID | {data.get('modelGUID')}"
        msg = f"""Hey, Validation has passed  for modelGUID {data.get('modelGUID')} """

        req_data = gcs_utils.send_notification(uuid, dl_list, subject, msg)
        logger.debug(req_data)

    # WRITE LOG FILE
    logger.debug(f"Writing log file for the component")
    with open('validate_metadata_log', 'r') as f1, open(args.user_logs, 'w') as f2:
        for line in f1:
            f2.write(line)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # Pipeline arguments
    parser.add_argument("--uuid", type=str)
    parser.add_argument("--model_metadata", type=str)
    parser.add_argument("--targetfile", type=str)
    parser.add_argument("--time", type=str)
    parser.add_argument("--uploadby", type=str)
    # Arguments for next component
    parser.add_argument("--expectedfileList", type=str)
    parser.add_argument("--user_logs", type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(f'uv-{args.time}')

    Path(args.expectedfileList).parent.mkdir(parents=True, exist_ok=True)
    Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)

    logger.debug(f"Pipeline inputs: {args}")
    validate_metadata_file(args.uuid, args.model_metadata,args.targetfile, args.time, args.uploadby)
