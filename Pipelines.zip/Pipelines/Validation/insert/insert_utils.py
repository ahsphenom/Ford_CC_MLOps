import json
from datetime import datetime
import config as config
from gcs_utils import notify_validn_fail
from google.cloud import bigquery, storage

bq_client = bigquery.Client()


def get_metadata_blob(model_metadata: str):
    """Download metadata blob to json object."""
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(config.INPUT_BUCKET_NAME)
    # Gets the required file_name in the blob variable
    blob = bucket.get_blob(model_metadata.split('$')[0])
    # Download the contents of the blob as a string and then parse it using json.loads() method
    data = json.loads(blob.download_as_string(client=None))

    return data


def get_model_catalog_bq_tbl(model_guid: str, logger):
    """get metadata from the previous version of the model."""
    query = f"""
    SELECT *
    FROM {config.MODEL_CATALOG_TABLE} 
    WHERE TRIM(modelGUID)=@modelGUID
    ORDER BY uploadedTime DESC
    LIMIT 1 
    """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter(
                "modelGUID", "STRING", model_guid
            )
        ]
    )
    query_job, row = None, None
    try:
        query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)
        logger.debug(f"Query job id: {query_job.job_id}")
        row = query_job.result()
    except Exception as _:
        logger.error(f"Query to retrive data from BigQuery failed. job_id : {query_job.job_id}")

    return query_job, row


def upload_to_model_catalog_bq(row_model_catalog: dict, data: dict, logger):
    """Inserting row to model catalog table in the BigQuery."""
    logger.debug("Running insert query.")
    query = f"""
    INSERT
    {config.MODEL_CATALOG_TABLE} 
    (uploadUID, modelGUID, modelVersion, modelDescription, uploadedTime, metadataFile,
    modelWeightsFile, inferenceFile, modelUseCase, modelUseCaseID, modelType, 
    modelSubType, uploadedBy, monitoringThresholds, frameworkInfo, expectedListofFile,
    modelDependency, policyTarget, targetAssignmentListFile, workflow, deploymentStatus,
    modelOwnerDistributionList, trainDataset, testDataset, readiness, testingThresholdScores,
    trainingScores, dataTable, modelName)
    VALUES 
    (@uuid, @modelGUID, @modelVersion, @modelDescription, @timestamp, @metadata_path,
    @modelWeightsFile, @inferenceFile, @modelUseCase, @modelUseCaseID, @mtyp, @mstyp,
    @uploadedBy,@monitoringThresholds, @frameworkInfo, @expectedListofFile, @modelDependency,
    @policyTarget, @targetAssignmentListFile, @workflow, @deploymentStatus,
    @modelOwnerDistributionList, @trainDataset, @testDataset, @readiness,
    {row_model_catalog['testing_threshold_scores']}, {row_model_catalog['training_scores']},
    @dataTable, @modelName)
    """
    try:
        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter(
                    "uuid", "STRING", row_model_catalog['uuid']),
                bigquery.ScalarQueryParameter(
                    "modelGUID", "STRING", row_model_catalog['modelGUID']),
                bigquery.ScalarQueryParameter(
                    "modelVersion", "STRING", row_model_catalog['modelVersion']),
                bigquery.ScalarQueryParameter(
                    "modelDescription", "STRING", row_model_catalog['modelDescription']),
                bigquery.ScalarQueryParameter(
                    "timestamp", "TIMESTAMP", datetime.now()),
                bigquery.ScalarQueryParameter(
                    "modelUseCase", "STRING", row_model_catalog['modelUseCase']),
                bigquery.ScalarQueryParameter(
                    "modelUseCaseID", "STRING", row_model_catalog['modelUseCaseID']),
                bigquery.ScalarQueryParameter(
                    "mtyp", "STRING", row_model_catalog['mtyp']),
                bigquery.ScalarQueryParameter(
                    "mstyp", "STRING", row_model_catalog['mstyp']),
                bigquery.ScalarQueryParameter(
                    "uploadedBy", "STRING", row_model_catalog['uploadedBy']),
                bigquery.ScalarQueryParameter(
                    "dataTable", "STRING", f"Data_Model_{row_model_catalog['modelGUID']}"),
                bigquery.ScalarQueryParameter(
                    "modelName", "STRING", row_model_catalog['modelName']),
                bigquery.StructQueryParameter(
                    "frameworkInfo",
                    bigquery.ScalarQueryParameter(
                        "frameworkName", 'STRING', row_model_catalog['frameworkName']),
                    bigquery.ScalarQueryParameter(
                        "version", "STRING", row_model_catalog['version']),
                    bigquery.ScalarQueryParameter(
                        "format", "STRING", row_model_catalog['format'])
                ),
                bigquery.StructQueryParameter(
                    "workflow",
                    bigquery.ScalarQueryParameter(
                        "stagesTestingToTest", "BOOL", row_model_catalog['to_test']),
                    bigquery.ScalarQueryParameter(
                        "stagesDeploymentToCloud", "BOOL", row_model_catalog['to_cloud']),
                    bigquery.ScalarQueryParameter(
                        "stagesDeploymentToEdge", "BOOL", row_model_catalog['to_edge']),
                    bigquery.ScalarQueryParameter(
                        "specificationsDeploymentWhenToRun", "TIMESTAMP", row_model_catalog['workflow_time'])
                ),
                bigquery.ScalarQueryParameter(
                    "deploymentStatus", "STRING", row_model_catalog['deploymentStatus']),
                bigquery.ArrayQueryParameter(
                    "expectedListofFile", "STRING", row_model_catalog['expectedListofFile']),
                bigquery.ArrayQueryParameter(
                    "modelDependency", "STRING", row_model_catalog['modelDependency']),
                bigquery.ScalarQueryParameter(
                    "policyTarget", "STRING", row_model_catalog['policyTarget']),
                bigquery.ScalarQueryParameter(
                    "targetAssignmentListFile", "STRING", row_model_catalog['targetAssignmentListFile']),
                bigquery.ArrayQueryParameter(
                    "modelOwnerDistributionList", "STRING", row_model_catalog['modelOwnerDistributionList']),
                bigquery.StructQueryParameter(
                    "monitoringThresholds",
                    bigquery.ArrayQueryParameter(
                        "criticalThreshold", "FLOAT64", row_model_catalog['criticalThreshold']),
                    bigquery.ArrayQueryParameter(
                        "warningThreshold", "FLOAT64", row_model_catalog['warningThreshold'])
                ),
                bigquery.StructQueryParameter(
                    "trainDataset",
                    bigquery.ScalarQueryParameter(
                        "fileName", 'STRING', row_model_catalog['trainDataset'])
                ),
                bigquery.StructQueryParameter(
                    "testDataset",
                    bigquery.ScalarQueryParameter(
                        "fileName", 'STRING', row_model_catalog['testDataset']),
                    bigquery.ScalarQueryParameter(
                        "isRawData", "BOOL", row_model_catalog['isRawData']),
                    bigquery.ScalarQueryParameter(
                        "isPreprocAndY", "BOOL", row_model_catalog['isPreprocAndY'])
                ),
                # HERE its not uploaded  because this clause will only get activated when metadata comes
                bigquery.ScalarQueryParameter(
                    "metadata_path", "STRING", row_model_catalog['metadata_path']),
                bigquery.ScalarQueryParameter(
                    "modelWeightsFile", "STRING", row_model_catalog['modelWeightsFile']),
                bigquery.ScalarQueryParameter(
                    "inferenceFile", "STRING", row_model_catalog['inferenceFile']),
                bigquery.ScalarQueryParameter(
                    "readiness", "BOOL", row_model_catalog['readiness']),
            ]
        )
        query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)
        logger.debug(f"Query job id: {query_job.job_id}")

        if query_job.errors:
            logger.error(f'Data could not be inserted into BigQuery.')
            notify_validn_fail(
                f"Insert query to load data into BigQuery failed job_id: {query_job.job_id}.",
                data, row_model_catalog['uuid'], row_model_catalog['uploaded_by'], logger
            )
        else:
            logger.debug(f"Data was inserted into Big Query.")

    except Exception as err:
        logger.error(f"{query} to Insert data into BigQuery failed. {err}")
        notify_validn_fail(
            f"Insert query to load data into BigQuery failed job_id: {row_model_catalog['query_job'].job_id}.",
            data, row_model_catalog['uuid'], row_model_catalog['uploaded_by'], logger
        )
