import argparse
import sys
from datetime import datetime
from pathlib import Path
import config
from app_logger import CustomLogger
from insert_utils import upload_to_model_catalog_bq, \
    get_model_catalog_bq_tbl, \
    get_metadata_blob
from load_vin_utils import load_vin_list

logger = CustomLogger(__name__, "insert_log")
DEFAULT_TIMESTAMP = "2099-12-31 00:00:00+00:00"


class MetadataHandler:
    """
    Handler class to create entities from the metadata.json file and make them
    schema-compatible to upload to the model catalog table in BigQuery.
    """

    def __init__(self, data: dict):
        self.data = data
        self.row_model_catalog = {}

    def test_thresh_score_handler(self):
        """update the test threshold scores from the metadata to the row."""
        testing_threshold_scores = []
        try:
            logger.info("Setting default value for testingThresholdScores key if no values are provided.")
            for metric in self.data.get('testingThresholdScores').keys():
                thresh_score_metric = self.data.get('testingThresholdScores').get(metric)
                testing_threshold_scores.append((
                    metric,
                    thresh_score_metric.get('gt_value', 0.0),
                    thresh_score_metric.get('lt_value', 0.0),
                    thresh_score_metric.get('margin', 0.0),
                    thresh_score_metric.get('upper_limit', 0.0),
                    thresh_score_metric.get('lower_limit', 0.0),
                    thresh_score_metric.get('filename', ""),
                ))
        except Exception as _:
            logger.warning("Missing testingThresholdScores key")

        self.row_model_catalog["testing_threshold_scores"] = testing_threshold_scores

    def training_scores_handler(self):
        """update the training evaluation scores from the metadata to the row."""
        training_scores = []
        try:
            for metric in self.data.get('trainingScores').keys():
                training_scores.append((
                    metric,
                    self.data.get('trainingScores').get(metric)
                ))
        except Exception as _:
            logger.warning("Missing trainingScores key")

        self.row_model_catalog["training_scores"] = training_scores

    def workflow_time_handler(self):
        """update the workflow timing from the metadata to the row."""
        try:
            self.row_model_catalog["workflow_time"] = datetime.fromisoformat(
                self.data.get("workflows").get("specifications").get("whenToRun")
            )
        except Exception as _:
            logger.warning("Missing whenToRun key or the value provided is not readable")
            self.row_model_catalog["workflow_time"] = datetime.fromisoformat(DEFAULT_TIMESTAMP)

    def train_test_set_handler(self):
        """update the train & test dataset location from the metadata to the row."""
        try:
            self.row_model_catalog["trainDataset"] = self.data.get("trainDataset").get("fileName", 'NA')
        except Exception as _:
            logger.warning("Missing trainDataset key or the value provided is not readable")
            self.row_model_catalog["trainDataset"] = 'NA'

        try:
            self.row_model_catalog["testDataset"] = self.data.get("testDataset").get("fileName", 'NA')
        except Exception as _:
            logger.warning("Missing testDataset key or the value provided is not readable")
            self.row_model_catalog["testDataset"] = 'NA'

    def data_prep_handler(self):
        """update whether data is raw or preprocessed from the metadata to the row."""
        try:
            self.row_model_catalog["isRawData"] = self.data.get("testDataset").get("is_raw_data", 'false')
        except Exception as _:
            self.row_model_catalog["isRawData"] = 'false'

        try:
            self.row_model_catalog["isPreprocAndY"] = self.data.get("testDataset").get("is_preproc_and_Y", 'false')
        except Exception as _:
            self.row_model_catalog["isPreprocAndY"] = 'false'

    def experiment_type_handler(self):
        """update the type of experiment viz. `test/cloud/edge` from the metadata to the row."""
        try:
            self.row_model_catalog["to_test"] = self.data.get("workflows").get("stages").get("testing") \
                .get("toTest", 'false')
        except Exception as _:
            self.row_model_catalog["to_test"] = 'false'

        try:
            self.row_model_catalog["to_cloud"] = self.data.get("workflows").get("stages").get("deployment") \
                .get("toCloud", 'false')
            if self.row_model_catalog["to_cloud"] == 'true':
                logger.debug("User wants to deploy model to cloud")
        except Exception as _:
            self.row_model_catalog["to_cloud"] = 'false'

        try:
            self.row_model_catalog["to_edge"] = self.data.get("workflows").get("stages").get("deployment") \
                .get("toEdge", 'false')
            if self.row_model_catalog["to_edge"] == 'true':
                logger.debug("User wants to deploy model to edge")
        except Exception as _:
            self.row_model_catalog["to_edge"] = 'false'

    def critical_and_warn_thresh_handler(self):
        """update the critical & warning threshold scores from the metadata to the row."""
        try:
            self.row_model_catalog["criticalThreshold"] = self.data.get("monitoringThresholds").get(
                "criticalThreshold", [0.0, 0.0, 0.0, 0.0]
            )
        except Exception as _:
            self.row_model_catalog["criticalThreshold"] = [0, 0, 0, 0]

        try:
            self.row_model_catalog["warningThreshold"] = self.data.get("monitoringThresholds").get(
                "warningThreshold", [0.0, 0.0, 0.0, 0.0]
            )
        except Exception as _:
            self.row_model_catalog["warningThreshold"] = [0, 0, 0, 0]

    def process(self) -> dict:
        """
        main method to create entities from the metadata.json file
        and make them schema-compatible to upload to the model catalog table in BQ.
        """
        self.data_prep_handler()
        self.train_test_set_handler()
        self.experiment_type_handler()
        self.workflow_time_handler()
        self.training_scores_handler()
        self.test_thresh_score_handler()
        self.critical_and_warn_thresh_handler()

        return self.row_model_catalog


class InsertHandler:

    def __init__(self,
                 uuid: str,
                 model_guid: str,
                 model_metadata: str,
                 inference_file: str,
                 model_weight_file: str,
                 targetfile: str,
                 uploaded_by: str):
        self.uuid = uuid
        self.model_guid = model_guid
        self.model_metadata = model_metadata
        self.inference_file = inference_file
        self.model_weight_file = model_weight_file
        self.targetfile = targetfile
        self.uploaded_by = uploaded_by

        if model_metadata:
            try:
                self.data = get_metadata_blob(model_metadata)
            except Exception as _:
                logger.error("Please check the model metadata.json file for formatting errors." +
                             "Some errors like missing values for keys will cause json load to fail.")
                sys.exit(0)
        else:
            self.data = {}

    def update_uploaded_files(self, input_bucket: str):
        """update the user-uploaded files in the `data` object."""
        if self.inference_file:
            self.data["inference"] = f"gs://{input_bucket}/{self.inference_file}"
            logger.debug(f"inference_file path: {self.data['inference']}")

        if self.model_weight_file:
            self.data["model_weight"] = f"gs://{input_bucket}/{self.model_weight_file}"
            logger.debug(f"model_weight path: {self.data['model_weight']}")

        if self.model_metadata:
            self.data["model_metadata"] = f"gs://{input_bucket}/{self.model_metadata}"
            logger.debug(f"model_metadata path: {self.data['model_metadata']}")

        if self.targetfile:
            self.data["targetfile"] = f"gs://{input_bucket}/{self.targetfile}"
            logger.debug(f"targetfile path: {self.data['targetfile']}")

    def reupload_with_metadata(self, query_job):
        """
        When user is reuploading new files to the portal & sends a `model_metadata.json` file.
        Previous version's data is retrieved and commited to a new row in the BQ table.
        """
        training_scores = []
        for item in self.data['trainingScores']:
            training_scores.append((item['metric'], item['value']))

        testing_threshold_scores = []
        for item in self.data['testingThresholdScores']:
            testing_threshold_scores.append((
                item['metric'], item['gtValue'], item['ltValue'], item['margin'],
                item['upperLimit'], item['lowerLimit'], item['fileName']
            ))

        for row in query_job:
            self.update_uploaded_files(config.INPUT_BUCKET_NAME)
            row_model_catalog = {
                "uuid": str(self.uuid),
                "modelGUID": str(self.model_guid),
                "modelVersion": str(self.data.get('modelVersion', 'NA')),
                "modelDescription": str(self.data.get('modelDescription', 'NA')),
                "modelUseCase": str(self.data.get('modelUseCase', 'NA')),
                "modelUseCaseID": str(self.data.get('modelUseCaseID', 'NA')),
                "mtyp": str(self.data.get('modelType', 'NA')),
                "mstyp": str(self.data.get('modelSubType', 'NA')),
                "uploadedBy": str(self.uploaded_by),
                "dataTable": f"Data_Model_{self.model_guid}",
                "modelName": self.data.get('modelName', 'Not Provided'),
                "frameworkName": str(self.data.get("frameworkInfo").get("frameworkName", 'NA')),
                "version": str(self.data.get("frameworkInfo").get("version", 'NA')),
                "format": str(self.data.get("frameworkInfo").get("format", 'NA')),
                "deploymentStatus": "Undeployed",
                "expectedListofFile": self.data.get("expectedListOfFile", ['NA']),
                "modelDependency": self.data.get("modelDependency", ['NA']),
                "policyTarget": self.data.get('policyTarget', 'None'),
                "targetAssignmentListFile": self.data.get('targetfile', 'Not_uploaded'),
                "modelOwnerDistributionList": self.data.get("modelOwnerDistributionList", []),
                "metadata_path": self.data.get('model_metadata', 'Not_uploaded'),
                "modelWeightsFile": self.data.get('model_weight', row['modelWeightsFile']),
                "inferenceFile": self.data.get('inference', row['inferenceFile']),
                "readiness": False,
                "training_scores": training_scores,
                "testing_threshold_scores": testing_threshold_scores,
            }

            metadata_handler = MetadataHandler(self.data)
            row_model_catalog.update(metadata_handler.process())
            upload_to_model_catalog_bq(row_model_catalog, self.data, logger)

            # Load the VIN list using VSS service if required
            try:
                if self.data.get("policyTarget").lower() != 'none':
                    load_vin_list(self.data, self.uuid, self.targetfile, self.uploaded_by, logger)
            except Exception as err:
                logger.error(f"Issue connecting with VSS. Could not commit VIN data to BigQuery. {err}")

    def reupload_without_metadata(self, query_job):
        """
        When user is reuploading new files to the portal but doesn't submit the `model_metadata.json` file.
        Previous version's data is recommited and paths of added files are added to the row in the BQ table.
        """
        for row in query_job:
            self.update_uploaded_files(config.INPUT_BUCKET_NAME)
            # Create entities of Struct-Array which can then be inserted in the below query
            training_scores = []
            for item in row['trainingScores']:
                training_scores.append((item['metric'], item['value']))

            testing_threshold_scores = []
            for item in row['testingThresholdScores']:
                testing_threshold_scores.append((
                    item['metric'], item['gtValue'], item['ltValue'], item['margin'],
                    item['upperLimit'], item['lowerLimit'], item['fileName']
                ))

            row_model_catalog = {
                "uuid": str(self.uuid),
                "modelGUID": str(self.model_guid),
                "modelVersion": str(row.get('modelVersion', 'NA')),
                "modelDescription": str(row.get('modelDescription', 'NA')),
                "modelUseCase": str(row.get('modelUseCase', 'NA')),
                "modelUseCaseID": str(row.get('modelUseCaseID', 'NA')),
                "mtyp": str(row.get('modelType', 'NA')),
                "mstyp": str(row.get('modelSubType', 'NA')),
                "uploadedBy": str(self.uploaded_by),
                "dataTable": row.get("dataTable", 'NA'),
                "modelName": row.get("modelName", 'NA'),
                "frameworkName": str(row.get("frameworkInfo").get("frameworkName", 'NA')),
                "version": str(row.get("frameworkInfo").get("version", 'NA')),
                "format": str(row.get("frameworkInfo").get("format", 'NA')),
                "deploymentStatus": row.get("deploymentStatus"),
                "expectedListofFile": row.get("expectedListOfFile", ['NA']),
                "modelDependency": row.get("modelDependency", ['NA']),
                "policyTarget": row.get('policyTarget', 'None'),
                "targetAssignmentListFile": row.get('targetfile', 'Not_uploaded'),
                "modelOwnerDistributionList": row.get("modelOwnerDistributionList", ['NA']),
                "metadata_path": row.get('metadataFile'),
                "modelWeightsFile": self.data.get('model_file', row['modelWeightsFile']),
                "inferenceFile": self.data.get('inference_file', row['inferenceFile']),
                "readiness": row['readiness'],
                "to_test": row.get("workflow").get("stagesTestingToTest", 'false'),
                "to_cloud": row.get("workflow").get("stagesDeploymentToCloud", 'false'),
                "to_edge": row.get("workflow").get("stagesDeploymentToEdge", 'false'),
                "workflow_time": row.get("workflow").get("specificationsDeploymentWhenToRun"),
                "criticalThreshold": row.get("monitoringThresholds").get("criticalThreshold", [0.0, 0.0, 0.0, 0.0]),
                "warningThreshold": row.get("monitoringThresholds").get("warningThreshold", [0.0, 0.0, 0.0, 0.0]),
                "trainDataset": row.get("trainDataset").get("fileName", 'NA'),
                "testDataset": row.get("testDataset").get("fileName", 'NA'),
                "isRawData": row.get("testDataset").get("isRawData", 'false'),
                "isPreprocAndY": row.get("testDataset").get("isPreprocAndY", 'false'),
                "training_scores": training_scores,
                "testing_threshold_scores": testing_threshold_scores,
            }
            upload_to_model_catalog_bq(row_model_catalog, self.data, logger)

    def new_upload_with_metadata(self):
        """When there is fresh upload & the `model_metadata.json` file is provided."""
        self.update_uploaded_files(config.INPUT_BUCKET_NAME)

        training_scores = []
        for item in self.data['trainingScores']:
            training_scores.append((item['metric'], item['value']))

        testing_threshold_scores = []
        for item in self.data['testingThresholdScores']:
            testing_threshold_scores.append((
                item['metric'], item['gtValue'], item['ltValue'], item['margin'],
                item['upperLimit'], item['lowerLimit'], item['fileName']
            ))

        row_model_catalog = {
            "uuid": str(self.uuid),
            "modelGUID": str(self.data.get("modelGUID", 'NA')),
            "modelVersion": str(self.data.get('modelVersion', 'NA')),
            "modelDescription": str(self.data.get('modelDescription', 'NA')),
            "modelUseCase": str(self.data.get('modelUseCase', 'NA')),
            "modelUseCaseID": str(self.data.get('modelUseCaseID', 'NA')),
            "mtyp": str(self.data.get('modelType', 'NA')),
            "mstyp": str(self.data.get('modelSubType', 'NA')),
            "uploadedBy": str(self.uploaded_by),
            "dataTable": f"Data_Model_{self.data.get('modelGUID', 'NA')}",
            "modelName": self.data.get('modelName', 'Not Provided'),
            "frameworkName": str(self.data.get("frameworkInfo").get("frameworkName", 'NA')),
            "version": str(self.data.get("frameworkInfo").get("version", 'NA')),
            "format": str(self.data.get("frameworkInfo").get("format", 'NA')),
            "deploymentStatus": "Undeployed",
            "expectedListofFile": self.data.get("expectedListOfFile", ['NA']),
            "modelDependency": self.data.get("modelDependency", ['NA']),
            "policyTarget": self.data.get('policyTarget', 'None'),
            "targetAssignmentListFile": self.data.get('targetfile', 'Not_uploaded'),
            "modelOwnerDistributionList": self.data.get("modelOwnerDistributionList", []),
            "metadata_path": self.data.get('model_metadata', 'Not_uploaded'),
            "modelWeightsFile": self.data.get('model_weight', 'Not_uploaded'),
            "inferenceFile": self.data.get('inference', 'Not_uploaded'),
            "readiness": False,
            "training_scores": training_scores,
            "testing_threshold_scores": testing_threshold_scores,
        }
        metadata_handler = MetadataHandler(self.data)
        row_model_catalog.update(metadata_handler.process())
        upload_to_model_catalog_bq(row_model_catalog, self.data, logger)

        try:
            if self.data.get("policyTarget").lower() != 'none':
                load_vin_list(self.data, self.uuid, self.targetfile, self.uploaded_by, logger)
        except Exception as _:
            logger.error("Issue connecting with VSS service. Could not commit VIN data to Big Query.")

    def new_upload_without_metadata(self):
        """
        When there is fresh upload but the `model_metadata.json` file is not provided.
        This is an edge case and should be avoided.
        """
        if self.model_weight_file:
            model = f"gs://{config.INPUT_BUCKET_NAME}/{self.model_weight_file}"
        else:
            model = 'Not_uploaded'

        if self.inference_file:
            inference = f"gs://{config.INPUT_BUCKET_NAME}/{self.inference_file}"
        else:
            inference = 'Not_uploaded'

        row_model_catalog = {
            "uuid": str(self.uuid),
            "modelGUID": "NA",
            "modelVersion": "NA",
            "modelDescription": "NA",
            "modelUseCase": "NA",
            "modelUseCaseID": "NA",
            "mtyp": "NA",
            "mstyp": "NA",
            "uploadedBy": str(self.uploaded_by),
            "dataTable": "NA",
            "modelName": "Not Provided",
            "frameworkName": "NA",
            "version": "NA",
            "format": "NA",
            "deploymentStatus": "Undeployed",
            "expectedListofFile": ["NA"],
            "modelDependency": ["NA"],
            "policyTarget": "None",
            "targetAssignmentListFile": "NA",
            "modelOwnerDistributionList": ["NA"],
            "metadata_path": "Not_uploaded",
            "modelWeightsFile": model,
            "inferenceFile": inference,
            "readiness": False,
            "to_test": "false",
            "to_cloud": "false",
            "to_edge": "false",
            "workflow_time": datetime.now(),
            "criticalThreshold": [0.0, 0.0, 0.0, 0.0],
            "warningThreshold": [0.0, 0.0, 0.0, 0.0],
            "trainDataset": "",
            "testDataset": "NA",
            "isRawData": "false",
            "isPreprocAndY": "false",
        }
        upload_to_model_catalog_bq(row_model_catalog, self.data, logger)

    def process(self):
        """main method to prepare and insert the rows into the `model_catalog` table in BQ."""
        if self.model_guid:
            query_job, row_ = get_model_catalog_bq_tbl(self.model_guid, logger)
            try:
                assert row_.total_rows > 0
            except AssertionError:
                logger.error(f"modelGUID {self.model_guid} does not exist. Please check the modelGUID provided.")

            if self.model_metadata:
                self.reupload_with_metadata(query_job)
            else:
                self.reupload_without_metadata(query_job)

        else:
            if self.model_metadata:
                self.new_upload_with_metadata()
            else:
                self.new_upload_without_metadata()

        # write the logs file
        with open("insert_log") as f:
            with open(args.user_logs, "w") as f1:
                for line in f:
                    f1.write(line)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # INPUT ARGUMENTS
    parser.add_argument("--uuid", type=str)
    parser.add_argument("--modelGUID", type=str)
    parser.add_argument("--model_metadata", type=str)
    parser.add_argument("--inference_file", type=str)
    parser.add_argument("--model_weight_file", type=str)
    parser.add_argument("--targetfile", type=str)
    parser.add_argument("--uploadedBy", type=str)
    parser.add_argument("--log_time", type=str)
    # OUTPUT ARGUMENTS
    parser.add_argument("--user_logs", type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(f'uv-{args.log_time}')

    Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)

    logger.debug(args)
    insert_op = InsertHandler(
        args.uuid, args.modelGUID, args.model_metadata, args.inference_file,
        args.model_weight_file, args.targetfile, args.uploadedBy
    )
    insert_op.process()
