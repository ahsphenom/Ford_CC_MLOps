import decimal
from datetime import datetime
import config as config
import numpy as np
import pandas as pd
from gcs_utils import notify_validn_fail
from google.cloud import bigquery
from get_vin_utils import get_vin_data

DEFAULT_TIMESTAMP = "2099-12-31 00:00:00+00:00"


def assert_df_cols(input_df, col1, col2, data, uuid, uploaded_by, logger):
    try:
        assert len(input_df[col1]) == len(input_df[col2])
    except AssertionError:
        logger.error(f"Length of columns {col1} and {col2}  in targetAssignmentListFile is not equal." +
                     "Unable to extact vinlist from VSS service")
        notify_validn_fail(
            f"{col1} and {col2} does not have the same length.",
            data, uuid, uploaded_by, logger
        )


def upload_edge_deploy_healthcheck_tbl(df, data, uuid, uploaded_by, logger):
    bq_client = bigquery.Client()
    job_config = bigquery.LoadJobConfig(
        schema=[
            bigquery.SchemaField("uploadUID", bigquery.enums.SqlTypeNames.STRING),
            bigquery.SchemaField("vin", bigquery.enums.SqlTypeNames.STRING),
            bigquery.SchemaField("expectedDeploymentTime", bigquery.enums.SqlTypeNames.TIMESTAMP),
            bigquery.SchemaField("scheduledDeploymentTime", bigquery.enums.SqlTypeNames.TIMESTAMP),
            bigquery.SchemaField("repetitionNumber", bigquery.enums.SqlTypeNames.INTEGER),
            bigquery.SchemaField("isDeployable", bigquery.enums.SqlTypeNames.BOOLEAN),
        ],
    )
    try:
        bq_client.load_table_from_dataframe(
            df, config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE,
            job_config=job_config, project=config.PROJECT_ID
        )
        logger.info("The VIN data is loaded into Edge deployment healthcheck")
    except Exception as err:
        logger.error(f"Failed load VIN data in Edge_Deployment_Healthcheck -- {err}")
        notify_validn_fail(
            "Failure to load VIN data into Edge_Deployment_HealthCheck table",
            data, uuid, uploaded_by, logger
        )


def upload_vin_list_tbl(df, data, uuid, uploaded_by, logger):
    bq_client = bigquery.Client()
    job_config = bigquery.LoadJobConfig(
        schema=[
            bigquery.SchemaField("uploadUID", bigquery.enums.SqlTypeNames.STRING, mode="REQUIRED"),
            bigquery.SchemaField("eventTime", bigquery.enums.SqlTypeNames.TIMESTAMP, mode="REQUIRED"),
            bigquery.SchemaField("vin", bigquery.enums.SqlTypeNames.STRING, mode="REQUIRED"),
            bigquery.SchemaField("driverID", bigquery.enums.SqlTypeNames.STRING),
            bigquery.SchemaField("expectedDeploymentDate", bigquery.enums.SqlTypeNames.TIMESTAMP),
            bigquery.SchemaField("policyTarget", bigquery.enums.SqlTypeNames.NUMERIC),
            bigquery.SchemaField("source", bigquery.enums.SqlTypeNames.NUMERIC),
        ],
    )
    try:
        bq_client.load_table_from_dataframe(
            df, config.VIN_LIST_TABLE,
            job_config=job_config, project=config.PROJECT_ID
        )
    except Exception as _:
        logger.error('Failure to load VIN data into VIN_List table.')
        notify_validn_fail(
            "Failed to load VIN data into VIN_List table.",
            data, uuid, uploaded_by, logger
        )


def edge_deployment_healthcheck(uuid, data, vinlist, uploaded_by, logger):
    """Check thorough readiness before edge deployment."""
    logger.info("Uploading Vin information to Edge_Deployment_Heathcheck_Table for scheduling.")

    expecteddeploymenttime = data.get("workflows").get("specifications").get("whenToRun")
    try:
        expecteddeploymenttime = datetime.fromisoformat(expecteddeploymenttime)
    except Exception as _:
        expecteddeploymenttime = datetime.fromisoformat(DEFAULT_TIMESTAMP)

    if expecteddeploymenttime != datetime.fromisoformat(DEFAULT_TIMESTAMP) and \
            datetime.fromisoformat(str(expecteddeploymenttime)) > datetime.now():
        df = pd.DataFrame(
            columns=[
                'uploadUID', 'vin', 'expectedDeploymentTime', 'scheduledDeploymentTime',
                'eventTime', 'repetitionNumber', 'isDeployable'
            ]
        )
        for vin in vinlist:
            df_one = {
                'uploadUID': uuid,
                'vin': vin,
                'expectedDeploymentTime': expecteddeploymenttime,
                'scheduledDeploymentTime': expecteddeploymenttime,
                'eventTime': datetime.now(),
                'repetitionNumber': 0,
            }
            df = df.append(df_one, ignore_index=True)

        upload_edge_deploy_healthcheck_tbl(df, data, uuid, uploaded_by, logger)

    else:
        logger.info("User wants edge deployment to be scheduled immediately or the given datetime is from the past.")


def load_generalized_vin_listfile(data, uuid, targetfile, uploaded_by, logger):
    """Get the generalized policy target list."""
    logger.info("Extracting targetAssignmentListFile info for generalized case into VIN_List table.")
    try:
        logger.debug("Opening the given targertAssignmentListFile.csv")
        vinfile = pd.read_csv(
            f"gs://{config.INPUT_BUCKET_NAME}/{str(targetfile).split('$')[0]}",
            dtype={'modelYear': str, 'programCode': str, 'familyCode': str, 'featureCode': str},
            skipinitialspace=True,
        )

    except Exception as _:
        logger.error('Issue while load targetAssignmentListfile in pandas.')
        notify_validn_fail(
            "Failure to open targetAssignmentListFile.csv",
            data, uuid, uploaded_by, logger
        )
        return

    vinfile.dropna(thresh=5, inplace=True, axis=0)
    model_year = vinfile['modelYear']
    program_code = vinfile['programCode']
    family_code = vinfile['familyCode']
    feature_code = vinfile['featureCode']

    try:
        expected_deployment_date = data.get('workflows').get('specifications').get('whenToRun')
        expected_deployment_date = str(expected_deployment_date) if expected_deployment_date else DEFAULT_TIMESTAMP
    except Exception as _:
        expected_deployment_date = DEFAULT_TIMESTAMP

    source = 3
    policytarget = 1
    upload_date = datetime.now()
    upload_uid = uuid

    assert_df_cols(vinfile, "modelYear", "programCode", data, uuid, uploaded_by, logger)
    assert_df_cols(vinfile, "modelYear", "familyCode", data, uuid, uploaded_by, logger)
    assert_df_cols(vinfile, "modelYear", "featureCode", data, uuid, uploaded_by, logger)

    # Pass the above 4 data columns to the VSS service
    df = pd.DataFrame(
        columns=[
            'uploadUID', 'eventTime', 'vin', 'driverID',
            'expectedDeploymentDate', 'policyTarget', 'source',
        ]
    )

    for i in range(len(model_year)):
        feature_code_value = [feature_code[i]] if feature_code[i] != 'None' else []
        family_code_value = family_code[i] if family_code[i] != 'None' else ""

        logger.debug(f"Extracting vin_list")
        listofvins = get_vin_data(program_code[i], model_year[i], feature_code_value, family_code_value, logger)
        logger.info(f"Retrieved list of VIN numbers.")
        logger.debug(f"{listofvins}")

        if listofvins:
            # LOAD DATA TO EDGE DEPLOYMENT HEALTHCHECK
            edge_deployment_healthcheck(uuid, data, listofvins, uploaded_by, logger)
            for vin in listofvins:
                df_one = {
                    'uploadUID': upload_uid,
                    'eventTime': upload_date,
                    'vin': vin,
                    'driverID': 'NA',
                    'expectedDeploymentDate': datetime.fromisoformat(expected_deployment_date),
                    'policyTarget': policytarget,
                    'source': source
                }
                df = df.append(df_one, ignore_index=True)
        else:
            logger.error(f"Combination of modelYear: {model_year}, programCode: {program_code}," +
                         f"featureCode: {feature_code_value},familyCode: {family_code_value}" +
                         "returned an empty list.")

    df['policyTarget'] = df['policyTarget'].astype(str).map(decimal.Decimal)
    df['source'] = df['source'].astype(str).map(decimal.Decimal)

    upload_vin_list_tbl(df, data, uuid, uploaded_by, logger)


def load_personalized_vin_listfile(data, uuid, targetfile, uploaded_by, logger):
    logger.info("Extracting targetAssignmentListFile info for personalized case into VIN_List table.")
    try:
        vinfile = pd.read_csv(
            f"gs://{config.INPUT_BUCKET_NAME}/{str(targetfile).split('$')[0]}",
            converters={'driverID': pd.eval},
            skipinitialspace=True
        )
    except Exception as _:
        logger.error("Issue while load targetAssignmentListfile in pandas.")
        notify_validn_fail(
            "Cannot open targetAssignmentListFile.csv.",
            data, uuid, uploaded_by, logger
        )
        return

    vinfile.dropna(thresh=3, inplace=True, axis=0)
    vin = None
    if 'vin' in vinfile.columns:
        vin = vinfile['vin']
    else:
        logger.error("vin column not in targerassignmentlistfile.")

    driverid = None
    if 'driverID' in vinfile.columns:
        driverid = vinfile['driverID']
    else:
        logger.error("driverID column not in targerassignmentlistfile.")

    try:
        expected_deployment_date = data.get('workflows').get('specifications').get('whenToRun')
        if expected_deployment_date:
            expected_deployment_date = np.repeat(str(expected_deployment_date), len(vin))
        else:
            expected_deployment_date = np.repeat(DEFAULT_TIMESTAMP, len(vin))
    except Exception as _:
        expected_deployment_date = np.repeat(DEFAULT_TIMESTAMP, len(vin))

    source = 3
    policytarget = 2
    upload_date = datetime.now()
    upload_uid = uuid

    try:
        assert len(vin) == len(driverid) == len(expected_deployment_date)
    except Exception as err:
        logger.exception("Length of columns in targetAssignmentListFile is not equal.")
        logger.error(err)
        notify_validn_fail(
            "length of columns in targetAssignmentFileList is not equal",
            data, uuid, uploaded_by, logger
        )

    df = pd.DataFrame(
        columns=[
            'uploadUID', 'eventTime', 'vin', 'driverID',
            'expectedDeploymentDate', 'policyTarget', 'source',
        ]
    )
    for c, v in enumerate(vin):
        for i in range(len(driverid[c])):
            df_one = {
                'uploadUID': upload_uid,
                'eventTime': upload_date,
                'vin': v,
                'driverID': driverid[c][i],
                'expectedDeploymentDate': datetime.fromisoformat(expected_deployment_date[c]),
                'policyTarget': policytarget,
                'source': source,
            }
            df = df.append(df_one, ignore_index=True)

    df['policyTarget'] = df['policyTarget'].astype(str).map(decimal.Decimal)
    df['source'] = df['source'].astype(str).map(decimal.Decimal)

    upload_vin_list_tbl(df, data, uuid, uploaded_by, logger)
    # LOAD DATA TO EDGE DEPLOYMENT HEALTHCHECK
    edge_deployment_healthcheck(uuid, data, vin, uploaded_by, logger)


def load_generalized_vin_assgnfile(data, uuid, uploaded_by, logger):
    vinfile = data.get('targetAssignment')
    df = pd.DataFrame(
        columns=[
            'uploadUID', 'eventTime', 'vin', 'driverID',
            'expectedDeploymentDate', 'policyTarget', 'source'
        ]
    )

    for item in vinfile:
        model_year = str(item.get('modelYear'))
        family_code_value = item.get('familyCode', "")
        feature_code = item.get('featureCode', [])
        program_code = str(item.get('programCode'))
        try:
            expected_deployment_date = str(data.get("workflows").get("specifications")
                                           .get("whenToRun", DEFAULT_TIMESTAMP))
        except Exception as _:
            expected_deployment_date = DEFAULT_TIMESTAMP

        source = 2
        policytarget = 1
        upload_date = datetime.now()
        upload_uid = uuid

        if feature_code:
            feature_code_value = [feature_code]
        else:
            feature_code_value = feature_code

        listofvins = None
        try:
            listofvins = get_vin_data(program_code, model_year, feature_code_value, family_code_value, logger)
        except Exception as err:
            logger.error(f'Check the inputs given to VSS app to generate vinlist -- {err}')
            notify_validn_fail(
                "Fail to upload Vin_List generated by VSS to VIN_List table.",
                data, uuid, uploaded_by, logger
            )

        logger.debug(f"list of vins for modelYear: {model_year}, programCode: {program_code}, " +
                     f"featureCode: {feature_code_value}  and familyCode: {family_code_value} are ")
        logger.debug(listofvins)

        if listofvins:
            # LOAD DATA TO EDGE DEPLOYMENT HEALTHCHECK
            edge_deployment_healthcheck(uuid, data, listofvins, uploaded_by, logger)
            for vin in listofvins:
                df_one = {
                    'uploadUID': upload_uid,
                    'eventTime': upload_date,
                    'vin': vin,
                    'driverID': 'NA',
                    'expectedDeploymentDate': datetime.fromisoformat(expected_deployment_date),
                    'policyTarget': policytarget,
                    'source': source
                }
                df = df.append(df_one, ignore_index=True)
        else:
            logger.error(f"Combination of modelYear: {model_year}, programCode: {program_code}," +
                         f"featureCode: {feature_code}, familyCode: {family_code_value} returned an empty list.")

    df['policyTarget'] = df['policyTarget'].astype(str).map(decimal.Decimal)
    df['source'] = df['source'].astype(str).map(decimal.Decimal)

    upload_vin_list_tbl(df, data, uuid, uploaded_by, logger)


def load_personalized_vin_assgnfile(data, uuid, uploaded_by, logger):
    vinlist = []
    vinfile = data.get('driverAssignment', '')

    for item in vinfile:
        vin = item['vin']
        # CREATING A VINLIST. This list is used to insert data to edge deployment healthcheck table
        vinlist.append(vin)
        driverid = item['driverID']
        try:
            expected_deployment_date = str(
                data.get("workflows").get("specifications").get("whenToRun"))
            if expected_deployment_date:
                logger.debug(f"expectedDeploymentDate provided is {expected_deployment_date}")
            else:
                expected_deployment_date = DEFAULT_TIMESTAMP
        except Exception as _:
            expected_deployment_date = DEFAULT_TIMESTAMP
        source = 2
        policytarget = 2
        upload_date = datetime.now()
        upload_uid = uuid

        df = pd.DataFrame(
            columns=[
                'uploadUID', 'eventTime', 'vin', 'driverID',
                'expectedDeploymentDate', 'policyTarget', 'source'
            ]
        )

        for i in range(len(driverid)):
            df_one = {
                'uploadUID': upload_uid,
                'eventTime': upload_date,
                'vin': str(vin),
                'driverID': str(driverid[i]),
                'expectedDeploymentDate': datetime.fromisoformat(expected_deployment_date),
                'policyTarget': policytarget,
                'source': source,
            }
            df = df.append(df_one, ignore_index=True)

        df['policyTarget'] = df['policyTarget'].astype(str).map(decimal.Decimal)
        df['source'] = df['source'].astype(str).map(decimal.Decimal)
        upload_vin_list_tbl(df, data, uuid, uploaded_by, logger)

    # LOAD DATA TO EDGE DEPLOYMENT HEALTHCHECK
    edge_deployment_healthcheck(uuid, data, vinlist, uploaded_by, logger)


def load_vin_list(data, uuid, targetfile, uploaded_by, logger):
    """Load VIN data."""
    logger.info("Uploading Vin information to VIN_LIST table")
    if data.get("targetAssignmentListFile") \
            and targetfile != "NA" \
            and not data.get('driverAssignment') \
            and not data.get('targetAssignment'):

        if data.get("policyTarget", "none").lower() == 'generalized':
            load_generalized_vin_listfile(data, uuid, targetfile, uploaded_by, logger)

        elif data.get("policyTarget", "none").lower() == 'personalized':
            load_personalized_vin_listfile(data, uuid, targetfile, uploaded_by, logger)

        elif data.get("policyTarget", "").lower() == 'none':
            logger.error("policyTarget is of none type. No vin list is loaded to the VIN_List table.")

        else:
            logger.error("policyTarget fields are not populated according the given standards")

    elif (data.get("targetAssignment") or data.get("driverAssignment")) \
            and targetfile == 'NA' \
            and data.get('targetAssignmentListFile', "") == "":

        if data.get("policyTarget", "none").lower() == 'generalized':
            load_generalized_vin_assgnfile(data, uuid, uploaded_by, logger)

        elif data.get("policyTarget", "none").lower() == 'personalized':
            load_personalized_vin_assgnfile(data, uuid, uploaded_by, logger)

        else:
            logger.error("policyTarget fields are not populated according the given standards.")

    else:
        logger.error("Either targetAssignmentListFile or driverAssignment/targetAssignmentListFile should be present.")
