"""
This script contains the utility functions
to get the relavnt information using the VIN number.
"""
import json
import time
import zipfile
import config as config
import requests

json_request_type = 'application/json'


def get_auth_token():
    """Get VSS service authentication."""
    url = f"{config.VSS_SERVICE_URL}/oauthqa1/oauth2/token"
    payload = f"grant_type=client_credentials&client_id={config.VSS_SERVICE_CLIENT_ID}&client_secret={config.VSS_SERVICE_CLIENT_SECRET}&scope=uaa.resource"
    headers = {
        'content-type': 'application/x-www-form-urlencoded',
        'accept': json_request_type
    }
    response = requests.request("POST", url, headers=headers, data=payload)

    return response.json()['access_token']


def get_vin_list(auth, program_code, model_year, feature_code, family_code):
    """Get the list of VIN numbers."""
    url = f"{config.VSS_SERVICE_URL}/getvinlistqa1/api/v1/getVINList?client-id={config.VSS_SERVICE_CLIENT_ID}"
    payload = json.dumps(
        {
            "vinListRequest": {
                "requestingApp": "MLOPSVTS",
                "programCode": program_code,
                "modelYear": model_year,
                "includeMfalData": family_code,
                "featureCodeInfo": {
                    "featureList": {
                        "featureCodeAny": feature_code
                    }
                }
            }
        }
    )
    headers = {
        'client-id': f"{config.VSS_SERVICE_CLIENT_ID}",
        'Accept': json_request_type,
        'Content-Type': json_request_type,
        'Authorization': f'Bearer {auth}'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    req_app = response.json()['vinListResponse']['requestingApp']
    req_id = response.json()['vinListResponse']['requestId']

    return req_app, req_id


def get_vin_data(program_code, model_year, feature_code, family_code, logger):
    """Get all the data related to the VIN number."""
    auth = get_auth_token()
    req_app, req_id = get_vin_list(auth, program_code, model_year, feature_code, family_code)
    try:
        url = f"{config.VSS_SERVICE_URL}/getvinlistdownloadqa1/api/v1/getVINListDownload?requesting-app={req_app}&request-id={req_id}"
        payload = {}
        headers = {
            'client-Id': f"{config.VSS_SERVICE_CLIENT_ID}",
            'Accept': 'application/octet-stream',
            'Authorization': f'Bearer {auth}'
        }

        retry = True
        tries = 0
        max_tries = 5
        while retry and tries <= max_tries:
            tries += 1
            response = None
            try:
                logger.debug(f'VINs Download URL: {url}')
                time.sleep(20)
                response = requests.request("GET", url, headers=headers, data=payload)
                time.sleep(60)

                if response.status_code == 200:
                    logger.debug(f'Response code: {str(response.status_code)}')
                    retry = False

                zip_name = f"{req_id}.zip"
                file_name = f"{req_id}-{req_app}-Results.json"

                with open(zip_name, 'wb') as file_:
                    file_.write(response.content)

                with zipfile.ZipFile(zip_name, 'r') as archive:
                    json_data = json.loads(archive.read(file_name))

            except Exception as _:
                if response.status_code > 200:
                    logger.debug('Retrying -- code will try again')
                    time.sleep(5)
                    if tries == max_tries:
                        logger.debug(f'VSS did not respond after maximum retries. Status {response.status_code}')
                        return []

    except(json.decoder.JSONDecodeError, ValueError):
        logger.error('ERROR: Bad file received from VSS, decode JSON has failed')

    # This gives me error since I am not getting anything json data
    vin_list = json_data['vinListAsyncResponse']['vinList']

    return vin_list
