import json
import config
import requests
from google.cloud import bigquery, storage

bq_client = bigquery.Client()


def send_notification(uploaduid, dl_list, subject, msg):
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json"
    }
    data = json.dumps(locals())
    resp = requests.post(config.NOTIF_URL, headers=headers, data=data)
    # TODO_: check resp status code and add logic to handle failures
    # Temporarily logging request body as we are not getting email notifications

    return data


def notify_validn_fail(msg, data, uuid, uploaded_by, logger):
    """Send the notification msg in case of validation fail."""
    dl_list = data.get("modelOwnerDistributionList", [uploaded_by])
    subject = f"Validation : Validation Fail : {data.get('modelGUID', 'NA')}"
    msg = f"Hey, Validation has failed because of the following reasons: {msg}"
    req_data = send_notification(uuid, dl_list, subject, msg)
    logger.debug(req_data)
    logger.info(msg)


def get_storage_client():
    storage_client = storage.Client()
    return storage_client


def get_bucket():

    storage_client = get_storage_client()
    bucket = storage_client.get_bucket(config.INPUT_BUCKET_NAME)

    return bucket
