import setuptools

setuptools.setup(
    name='Drift Pipeline',
    version='0.1',
    install_requires=[
        "apache_beam[gcp]",
        "numpy",
        "pandas",
        "pandas_gbq",
        "requests",
        "setuptools"
    ],
    packages=setuptools.find_packages()
)
