from datetime import datetime

PROJECT_ID = "mlopsplatform"
DATASET = "ford_cc"
AGGREGATED_VIEW_NAME = f"{PROJECT_ID}.{DATASET}.last_used_model"
MODEL_CATALOG_TABLE = f"{PROJECT_ID}.{DATASET}.Model_Catalog"
DRIFT_TABLE = f"{PROJECT_ID}.{DATASET}.Drift"
VIN_LIST_TABLE = f"{PROJECT_ID}.{DATASET}.VIN_List"
EDGE_DEPLOYMENT_HEALTHCHECK_TABLE = f"{PROJECT_ID}.{DATASET}.Edge_Deployment_Healthcheck"
PIPELINE_LOGS_TABLE = f"{PROJECT_ID}.{DATASET}.Pipeline_Log"
REGION = "us-central1"
PIPELINE_BUCKET_NAME = 'mlopsplatform-dev-mlpipelines'
INPUT_BUCKET_NAME = 'mlopsplatform-dev-modelartifacts'
NOTIF_URL = "https://proxy-notifications-api-xbp35kfhma-uc.a.run.app/notifications-api"
CURRENT_DATE = datetime.now().strftime("%Y-%m-%d")
DATAFLOW_JOB_NAME = "driftpipeline-" + datetime.now().strftime('%Y%m%d-%H%M%S')
DATAFLOW_BUCKET = "mlopsplatform-dev-dataflow"

TIMEFRAMES = ['1', '7', '30', 'All']
