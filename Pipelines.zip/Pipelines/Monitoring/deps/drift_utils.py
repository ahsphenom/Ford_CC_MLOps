
import numpy as np
import pandas as pd


def compute_edge_bins(
    dist1,
    dist2,
    bins='scott'
):
    """
    Function to get bin edges from two input datasets
    Args:
        dist1: First disribution input
        dist2: Second distribution input
        bins: histogram bins for computing probabilities. Available options-
            'auto','fd','doane','scott','stone','rice','sturges','sqrt'.
            For more details, see the documentation for np.histogram_bin_edges.
    Returns:
        combiined histogram bins for the two input distributions
    """
    hist_bin_edges = np.histogram_bin_edges(
        np.concatenate((dist1, dist2)), bins=bins)
    return hist_bin_edges


def compute_probs(
    data,
    hist_bin_edges,
    alpha=1e-10
):
    """
    Function to compute probabilities for the input distribution
    Args:
        data: input distribution
        hist_bin_edges: histogram bin edges for computing probabilities
        alpha: value to be added for smoothening of probabilities in each bin
                defult value is '1e-10'
    Returns:
        probabilities of the input data in each bin
    """

    h, e = np.histogram(data, hist_bin_edges)
    """Applying histogram function to get the bin edges """

    p = h/data.shape[0] + alpha

    return p


def kl_divergence(p, q):
    """
    Function to calculate Kullback–Leibler divergence
    """

    p = np.array(p)
    '''converting column to numpy array'''

    q = np.array(q)
    '''converting column to numpy array'''

    return np.sum(p*np.log(p/q))
    '''calculating kl_divergence'''


def js_divergence(p, q):
    """
    Function to calculate Jensen–Shannon divergence

    Js_divergence is mean of KL_divergence(p,q) and KL_divergence(p,q)
    """
    m = (1./2.)*(p + q)

    return (1./2.)*kl_divergence(p, m) + (1./2.)*kl_divergence(q, m)


def compute_kl_divergence(
    dist1,
    dist2,
    bins='scott',
    alpha=1e-10
):
    """
    Function to calculate Kullback–Leibler divergence
    Args:
        dist1: probabilities of distribution 1
        dist2: probailities of distribution 2
        bins: histogram bins for computing probabilities. Available options-
            'auto','fd','doane','scott','stone','rice','sturges','sqrt'.
            For more details, see the documentation for np.histogram_bin_edges.
        alpha: value to be added for smoothening of probabilities in each bin.
                defult value is '1e-10'
    Returns:
        Kullback–Leibler divergence of the two probabilities
    """
    hist_bin_edges = compute_edge_bins(dist1, dist2, bins=bins)
    '''calling helper function to compute edge bins '''

    p = compute_probs(dist1, hist_bin_edges, alpha=alpha)
    '''calling helper function compute_probs '''

    q = compute_probs(dist2, hist_bin_edges, alpha=alpha)
    '''calling helper function to get probabilities'''

    return kl_divergence(p, q)


def compute_js_divergence(
    dist1,
    dist2,
    bins='scott',
    alpha=1e-10
):
    """
    Function to calculate Jensen–Shannon divergence
    Args:
        dist1: probabilities of distribution 1
        dist2: probailities of distribution 2
        bins: histogram bins for computing probabilities. Available options-
            'auto','fd','doane','scott','stone','rice','sturges','sqrt'.
            For more details, see the documentation for np.histogram_bin_edges.
        alpha: value to be added for smoothening of probabilities in each bin.
                defult value is '1e-10'
    Returns:
        Kullback–Leibler divergence of the two probabilities
    """
    hist_bin_edges = compute_edge_bins(dist1, dist2, bins=bins)
    '''calling helper function to compute edge bins '''

    p = compute_probs(dist1, hist_bin_edges, alpha=alpha)
    '''calling helper function to compute feature probabilities '''

    q = compute_probs(dist2, hist_bin_edges, alpha=alpha)
    '''calling helper function to compute feature probabilities'''

    drift = js_divergence(p, q)

    return drift


def get_numerical_categorical_features(train_df):
    ''' Input: DataFrmame
        Output: returns two seperate lists one for categorical features and one for numerical features '''

    cat_features = train_df.select_dtypes(
        include=['category', 'object']).columns.tolist()
    '''selecting category and objects as categorical features as most of the times categorical features datatypes are as object so included object datatype also here'''

    num_features = train_df.select_dtypes(
        include=['float64', 'float32', 'int32', 'int64']).columns.tolist()
    '''selecting float64,float32,int32,int64 numerical features '''

    return num_features, cat_features


def convert_feature_to_prob(
    data_df,
    key,
    class_ids
):
    """
    Function to convert the categorical columns to a probability dict
    Args:
        data_df: the dataframe
        class_ids: list of class ids in the data
    Returns:
        dictionary with keys as class_ids and values as their probability
    """

    data_freq_dict = data_df[key].value_counts().to_dict()
    '''coverting categorical features to dictionary with labels as keys, frequency as value '''

    n = data_df.shape[0]
    for i in class_ids:
        if i in data_freq_dict.keys():
            data_freq_dict[i] = data_freq_dict[i]/n
            '''dividing frequency of particuler label to total to get probability'''
        else:
            data_freq_dict[i] = 0
    return data_freq_dict


def cal_l_infinity_dist(
    train_prob_dict,
    prod_prob_dict,
    class_ids
):
    """
    Function to calculate L-Infinity distance between the probability dictionary
    Args:
        train_prob_dict: a dictionary that contains the proability of class_ids in first dataset
        simulated_prob_dict:a dictionary that contains the proability of class_ids in second dataset
        class_ids: list of class ids in the data
    Returns:
        returns the L-Infinity distance
    """

    dist = []

    for i in class_ids:
        '''for every class type that means category we are calculating distance/difference between 
        training data and production data  '''
        dist.append(train_prob_dict[i] - prod_prob_dict[i])

    l_inf_dist = abs(max(dist))
    '''Retuning maximum value as highest difference /l Infinity distance 
    between these two features'''

    return abs(max(dist))


def calculate_drift_js_l_infinity(train_df, prod_df):
    ''' INPUTS :This function takes two datasets ,

        Functionality: it divide data into numerical features and categorical features 
        then applies js divergence method for numerical features and l_infintity method for categorical values , 
        inside js divergence function we are converting numerical values to equal bin values and applying js divergence,
        for categorical values we are converting it to probabilities and applying l_infinftiy to it

        OUTPUT :Returns drift vavlues for individual features as key value pairs '''

    if len(train_df.columns) != len(prod_df.columns):

        print("No of coulmns in Training data and Production data are not same")

        return numerical_features_drift, categorical_features_drift

    '''Creating empty dictionaries to store drift values '''
    numerical_features_drift = {}
    categorical_features_drift = {}
    anomalies = ""

    '''classifying columns to categorical and numerical '''
    numerical_features, categorical_features = get_numerical_categorical_features(
        train_df)

    for key in numerical_features:
        numerical_features_drift[key] = compute_js_divergence(
            train_df[key], prod_df[key])
        '''for numerical values we divide the range of possible feature values into equal intervals,
        and compute the number or percentage of feature values that fall in each interval, then apply JS_divergence test'''

    for key in categorical_features:
        ''' For categorical features, the computed distribution is the number or
            percentage of instances of each possible value of the feature, then applying L-infinty test '''

        class_ids = (train_df[key].unique())
        '''getting unique labels in each column'''

        train_df_prob_dict = convert_feature_to_prob(train_df, key, class_ids)
        '''converting feature to probability values'''
        prod_df_prob_dict = convert_feature_to_prob(prod_df, key, class_ids)
        '''converting feature to probability values'''

        categorical_features_drift[key] = cal_l_infinity_dist(
            train_df_prob_dict, prod_df_prob_dict, class_ids)
        '''caluculating l_infinty test on both features probability values'''

    # returning marged dictionary
    combined_drift = {**numerical_features_drift, **categorical_features_drift}

    # returning feature name with max drift score and the drift score
    feature, score = max(combined_drift.items(), key=lambda x: x[1])
    return feature, score


def calculate_drift(df_train, prod_df):
    train_df = df_train.drop(columns=[
        "modelGUID", "modelVersion", "inferenceTime", "inferenceType", "dataType", "vin", "uploadUID"
    ], axis=1)

    vin_df = prod_df.drop(columns=[
        "modelGUID", "modelVersion", "inferenceTime", "inferenceType", "dataType", "vin", "uploadUID"
    ], axis=1)

    vin_df_1 = vin_df[vin_df['within_1_day']].drop(
        columns=['within_1_day', 'within_7_day', 'within_30_day'], axis=1).reset_index(drop=True)
    vin_df_7 = vin_df[vin_df['within_7_day']].drop(
        columns=['within_1_day', 'within_7_day', 'within_30_day'], axis=1).reset_index(drop=True)
    vin_df_30 = vin_df[vin_df['within_30_day']].drop(
        columns=['within_1_day', 'within_7_day', 'within_30_day'], axis=1).reset_index(drop=True)
    vin_df_all = vin_df.drop(
        columns=['within_1_day', 'within_7_day', 'within_30_day'], axis=1).reset_index(drop=True)

    drift_tuple_1 = calculate_drift_js_l_infinity(
        train_df, vin_df_1)
    drift_tuple_7 = calculate_drift_js_l_infinity(
        train_df, vin_df_7)
    drift_tuple_30 = calculate_drift_js_l_infinity(
        train_df, vin_df_30)
    drift_tuple_all = calculate_drift_js_l_infinity(
        train_df, vin_df_all)

    return (drift_tuple_1, drift_tuple_7, drift_tuple_30, drift_tuple_all)
