import json

import pandas as pd
import pandas_gbq as pb
import requests
from deps import config

DRIFT_TABLE_SCHEMA = [
    {"name": "uploadUID", "type": "STRING"},
    {"name": "vin", "type": "STRING"},
    {"name": "eventTime", "type": "TIMESTAMP"},
    {"name": "DFJobID", "type": "STRING"},
    {"name": "value_1", "type": "FLOAT"},
    {"name": "valueWarningThreshold_1", "type": "FLOAT"},
    {"name": "valueCriticalThreshold_1", "type": "FLOAT"},
    {"name": "value_7", "type": "FLOAT"},
    {"name": "valueWarningThreshold_7", "type": "FLOAT"},
    {"name": "valueCriticalThreshold_7", "type": "FLOAT"},
    {"name": "value_30", "type": "FLOAT"},
    {"name": "valueWarningThreshold_30", "type": "FLOAT"},
    {"name": "valueCriticalThreshold_30", "type": "FLOAT"},
    {"name": "value_All", "type": "FLOAT"},
    {"name": "valueWarningThreshold_All", "type": "FLOAT"},
    {"name": "valueCriticalThreshold_All", "type": "FLOAT"}
]


def extract_thresholds(row):
    row_dict = row.to_dict()
    features, scores = zip(*row_dict['drift_scores'])
    critical_thresholds = row_dict['monitoringThresholds']['criticalThreshold']
    warning_thresholds = row_dict['monitoringThresholds']['warningThreshold']
    for i, timeframe in enumerate(config.TIMEFRAMES):
        row_dict[f'value_{timeframe}'] = scores[i] if not pd.isna(
            scores[i]) else 9
        row_dict[f'valueCriticalThreshold_{timeframe}'] = critical_thresholds[i]
        row_dict[f'valueWarningThreshold_{timeframe}'] = warning_thresholds[i]
    del row_dict['drift_scores']
    del row_dict['monitoringThresholds']
    return pd.DataFrame(row_dict, index=[0])


def send_notification(uploadUID, dl_list, subject, msg):
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json"
    }

    data = json.dumps(locals())
    print(data)
    resp = requests.post(config.NOTIF_URL, headers=headers, data=data)

    return


def add_dl_list_column(df):
    get_dl_list_query = f"""
    SELECT uploadUID, modelOwnerDistributionList, uploadedTime FROM {config.MODEL_CATALOG_TABLE} WHERE uploadUID IN ("{'","'.join(set(df['uploadUID']))}") ORDER BY uploadedTime DESC
    """

    dl_list_df = pb.read_gbq(get_dl_list_query)

    dl_list_df = dl_list_df.sort_values('uploadedTime').groupby('uploadUID').tail(1).drop(columns=['uploadedTime'])

    merged_df = pd.merge(df, dl_list_df, how="left", on=["uploadUID"])
    return merged_df


def compare_against_thresholds(row):
    to_notify = False
    criticality_level = 'normal'
    metadata = []
    for i, timeframe in enumerate(config.TIMEFRAMES):
        if row[f'value_{timeframe}'] == 9.0:
            continue
        if row[f'valueWarningThreshold_{timeframe}'] <= row[f'value_{timeframe}'] <= row[f'valueCriticalThreshold_{timeframe}']:
            if criticality_level != 'Critical':
                criticality_level = 'Warning'
            to_notify = True
            criticality_dict = {
                "criticality level": "warning",
                "timeframe": f"{timeframe} days",
                "drift score": str(row[f'value_{timeframe}']),
                "critical threshold": str(row[f'valueCriticalThreshold_{timeframe}']),
                "warning threshold": str(row[f'valueWarningThreshold_{timeframe}'])
            }
            metadata.append(json.dumps(criticality_dict))
        elif row[f'valueCriticalThreshold_{timeframe}'] <= row[f'value_{timeframe}']:
            criticality_level = 'Critical'
            to_notify = True
            criticality_dict = {
                "criticality level": "critical",
                "timeframe": f"{timeframe} days",
                "drift score": str(row[f'value_{timeframe}']),
                "critical threshold": str(row[f'valueCriticalThreshold_{timeframe}']),
                "warning threshold": str(row[f'valueWarningThreshold_{timeframe}'])
            }
            metadata.append(json.dumps(criticality_dict))
    if to_notify:
        subject = f"{criticality_level} : {row['modelGUID']} : Notification from Drift Pipeline"
        msg = str("\n".join(metadata))
        dl_list = list(row['modelOwnerDistributionList'])
        send_notification(row['uploadUID'], dl_list, subject, msg)
