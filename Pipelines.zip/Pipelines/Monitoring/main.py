import argparse
import datetime
import logging
import sys
import warnings

import apache_beam as beam
import pandas as pd
import pandas_gbq as pb
from apache_beam.options.pipeline_options import PipelineOptions
from deps import config, drift_utils, utils

warnings.filterwarnings('ignore')

TODAY = datetime.date.today()
WINDOW_DAY_1 = TODAY - datetime.timedelta(days=1)
WINDOW_DAY_7 = TODAY - datetime.timedelta(days=7)
WINDOW_DAY_30 = TODAY - datetime.timedelta(days=30)


def filtermodelsusedin30days(tablename):

    model_last_used_on_query = f"""SELECT * FROM {tablename} WHERE DATE( last_inference_time ) between DATE_SUB(DATE("{config.CURRENT_DATE}"), INTERVAL 30 DAY) AND DATE("{config.CURRENT_DATE}")"""

    df_model_last_inf_time = pb.read_gbq(
        model_last_used_on_query, project_id=config.PROJECT_ID)

    df_model_last_inf_time['used_within_30_days'] = df_model_last_inf_time.apply(
        lambda x: WINDOW_DAY_30 <= x['last_inference_time'] <= TODAY, axis=1)

    df_model_used_within_30_days = df_model_last_inf_time[df_model_last_inf_time['used_within_30_days']].reset_index(
        drop=True)

    return df_model_used_within_30_days


class ReadDatasets(beam.DoFn):

    def process(self, element):

        metadata_df = element
        data_dict = {}
        for index, row in metadata_df.iterrows():
            if row['modelGUID'] not in data_dict.keys():
                data_table_query = f"""SELECT * FROM {config.PROJECT_ID}.{config.DATASET}.{row['dataTable']}"""
                data_dict[row['modelGUID']] = pb.read_gbq(
                    data_table_query)
            metadata_df.loc[index, 'data_df_name'] = row['dataTable']

        for key in data_dict.keys():
            yield (key, metadata_df, data_dict[key])


class SplitTrainProd(beam.DoFn):

    def apply_date_window_filters(self, df):

        df_prod = df[df['dataType'] == 'prod'].reset_index(drop=True)
        df_train = df[df['dataType'] == 'train'].reset_index(drop=True)
        df_prod['within_1_day'] = df_prod.apply(
            lambda x: WINDOW_DAY_1 <= x['inferenceTime'] <= TODAY, axis=1)
        df_prod['within_7_day'] = df_prod.apply(
            lambda x: WINDOW_DAY_7 <= x['inferenceTime'] <= TODAY, axis=1)
        df_prod['within_30_day'] = df_prod.apply(
            lambda x: WINDOW_DAY_30 <= x['inferenceTime'] <= TODAY, axis=1)
        return df_train, df_prod

    def process(self, element):

        key, metadata_df, df_data = element
        df_train, df_prod = self.apply_date_window_filters(df_data)
        yield (key, metadata_df, df_train, df_prod)


class ApplyVinFilter(beam.DoFn):

    def process(self, element):
        key, metadata_df, df_train, df_prod = element
        # TODO: Apply VIN level filtering on train set too
        # TODO: Blank VIN should be considered cloud inference
        vin_gb = df_prod.groupby('vin')
        vin_list_df_tuple = [(x, vin_gb.get_group(x)) for x in vin_gb.groups]
        for vin_tuple in vin_list_df_tuple:
            yield (key, metadata_df, vin_tuple[0], df_train, vin_tuple[1])


class CalculateDrift(beam.DoFn):

    def process(self, element):
        key, metadata_df, vin, df_train, vin_df = element

        drift_dict = drift_utils.calculate_drift(df_train, vin_df)
        return [(key, vin, drift_dict)]


def getthresholdvalues(element):

    drift_df = pd.DataFrame(
        element, columns=['modelGUID', 'vin', 'drift_scores']
    )

    model_guid_list = set(drift_df['modelGUID'])
    get_threshold_query = """
    SELECT uploadUID,modelGUID,uploadedTime,monitoringThresholds FROM {model_catalog_table} WHERE modelGUID IN ("{model_guid_list}") ORDER BY uploadedTime DESC
    """.format(
        model_catalog_table=config.MODEL_CATALOG_TABLE,
        model_guid_list='","'.join(model_guid_list)
    )

    threshold_df = pb.read_gbq(get_threshold_query)
    threshold_df = threshold_df.sort_values('uploadedTime').groupby('modelGUID').tail(1)

    drift_with_raw_threshold_df = pd.merge(drift_df, threshold_df, on='modelGUID', how='left')

    drift_with_threshold_df = pd.concat(
        [utils.extract_thresholds(row) for _, row in drift_with_raw_threshold_df.iterrows()], axis=0, ignore_index=True
    )

    drift_with_threshold_df["eventTime"] = datetime.datetime.now()
    drift_with_threshold_df["DFJobID"] = config.DATAFLOW_JOB_NAME
    drift_with_threshold_df.drop(columns=['uploadedTime'], inplace=True)
    drift_with_threshold_df.drop(columns=['modelGUID']).to_gbq(
        config.DRIFT_TABLE, config.PROJECT_ID, if_exists='append',
        table_schema=utils.DRIFT_TABLE_SCHEMA
    )

    return drift_with_threshold_df


def sendnotifications(element):
    df = utils.add_dl_list_column(element)
    df.apply(lambda x: utils.compare_against_thresholds(x), axis=1)
    return


def configure_pipeline(p, opt):
    """Specify PCollection and transformations in pipeline."""
    logging.info(str(opt))
    _ = (
        p
        | 'Table Name' >> beam.Create([config.AGGREGATED_VIEW_NAME])
        | 'Filter Models based on last inference usage' >> beam.Map(filtermodelsusedin30days)
        | 'Read datasets' >> beam.ParDo(ReadDatasets())
        | 'Split into train and prod' >> beam.ParDo(SplitTrainProd())
        | 'Apply VIN Filter' >> beam.ParDo(ApplyVinFilter())
        | 'Calculate Drift Scores' >> beam.ParDo(CalculateDrift())
        | "Combine" >> beam.combiners.ToList()
        | "Get Threshold values and write to BQ" >> beam.Map(getthresholdvalues)
        | "Compare against Thresholds and Send Notifications" >> beam.Map(sendnotifications)
    )


def run(in_args=None):
    """Runs the pre-processing pipeline."""
    pipeline_options = PipelineOptions.from_dictionary(vars(in_args))
    logging.info(pipeline_options.get_all_options())
    with beam.Pipeline(options=pipeline_options) as p:
        configure_pipeline(p, in_args)


def default_args(argv):
    """Provides default values for Workflow flags."""
    parser = argparse.ArgumentParser()

    parser.add_argument(
        '--project',
        type=str,
        default=config.PROJECT_ID,
        help='The cloud project name to be used for running this pipeline')
    parser.add_argument(
        '--job_name',
        type=str,
        default=config.DATAFLOW_JOB_NAME,
        help='A unique job identifier.')
    parser.add_argument(
        '--num_workers',
        default=20,
        type=int,
        help='The number of workers.')
    parser.add_argument('--cloud', default=False, action='store_true')
    parser.add_argument(
        '--runner',
        help='See Dataflow runners, may be blocking or not, on cloud or not, etc.')
    parser.add_argument(
        '--setup_file',
        default='./setup.py',
        help='Path to setup.py file.'),
    parser.add_argument(
        '--template_location',
        help='Filepath to template location')

    parsed_args, _ = parser.parse_known_args(argv)

    if parsed_args.cloud:
        # Flags which need to be set for cloud runs.
        default_values = {
            'project':
                config.PROJECT_ID,
            'region':
                'us-central1',
            'temp_location':
                f"gs://{config.DATAFLOW_BUCKET}/temp",
            'staging_location':
                f"gs://{config.DATAFLOW_BUCKET}/staging",
            'runner':
                'DataflowRunner',
            'save_main_session':
                True,
        }
    else:
        # Flags which need to be set for local runs.
        default_values = {
            'runner': 'DirectRunner',
        }

    for kk, vv in default_values.items():
        if kk not in parsed_args or not vars(parsed_args)[kk]:
            vars(parsed_args)[kk] = vv

    return parsed_args


def main(argv):
    arg_dict = default_args(argv)
    run(arg_dict)


if __name__ == '__main__':
    logger = logging.getLogger().setLevel(logging.INFO)
    main(sys.argv)
