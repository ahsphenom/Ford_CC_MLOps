import json
import os
from typing import List

import requests
from fastapi import FastAPI
from pydantic import BaseModel

URL = os.environ["URL"]

app = FastAPI()


class notificationReq(BaseModel):
    uploadUID: str
    dl_list: List = []
    subject: str
    msg: str


@app.post("/notifications-api")
def send_notification(notificationReq: notificationReq):

    payload = json.dumps({
        "to": notificationReq.dl_list,
        "subject": notificationReq.subject,
        "message": notificationReq.msg
    })
    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", URL, headers=headers, data=payload)

    # TODO: add try-except block and return response accordingly
    return {
        "success": True
    }
