import json
from fastapi.testclient import TestClient
from ..api.main import app

client = TestClient(app)

payload = {
    "uploadUID": "01ecc147-8991-1912-9bce-de1a276e2e90",
    "dl_list":  ['ssawant4@ford.com'],
    "subject": "Test notification-api app.",
    "msg": "send notification endpoint working."
}


def test_send_notification():
    response = client.post("/notifications-api", json.dumps(payload))
    assert response.status_code == 200
    assert response.json()['success']
