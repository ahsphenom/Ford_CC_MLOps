import json

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

upload = {
    "uploadUID": "01ecc147-8991-1912-9bce-de1a276e2e90",
    "modelGUID":  "",
    "filePath": "01ecc147-8991-1912-9bce-de1a276e2e90/model_metadata__errors_lower_half.json",
    "uploadBy": "ssawant4@ford.com"
}


def test_orchestrator():
    response = client.post("/orchestrator", json.dumps(upload))
    assert response.status_code == 201
    assert response.json()['uploadUID'] == '01ecc147-8991-1912-9bce-de1a276e2e90'
    assert response.json()['uploadBy'] == 'ssawant4@ford.com'


def test_delete():
    response = client.post("/delete")
    assert response.status_code == 200
    assert response.json() == "All pipeline jobs in succeeded, failed and cancelled state are deleted successfully."


def test_logs():
    response = client.post("/logs")
    assert response.status_code == 200
