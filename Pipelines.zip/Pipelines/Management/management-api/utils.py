import datetime
import json
import random
from datetime import datetime, timezone
from time import sleep

import config
import pandas as pd
import requests
from app_logger import CustomLogger
from fastapi import HTTPException, status
from google.api_core.exceptions import AlreadyExists
from google.cloud import aiplatform as aip
from google.cloud import bigquery

logger = CustomLogger(__name__)

bq_client = bigquery.Client()


def insert_to_pipeline_logs(uuid, actionjobuid, action, stage, status, desc, VAIJobID):
    bq_client = bigquery.Client()
    query = f"""
    INSERT {config.PIPELINE_LOGS_TABLE}
    (uploadUID,actionJobUID,action,stage,result,description,eventTime,VAIJobID,workflowItems) 
    VALUES 
    ('{uuid}','{actionjobuid}','{action}','{stage}','{status}','{desc}',CURRENT_TIMESTAMP(),'{VAIJobID}','v')
    """
    query_job = bq_client.query(query, project=config.PROJECT_ID)
    return query_job


def send_notification(uploaduid, dl_list, subject, msg):
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json"
    }
    data = json.dumps(locals())
    resp = requests.post(config.NOTIF_URL, headers=headers, data=data)
    # TODO: check resp status code and add logic to handle failures
    # Temporarily logging request body as we are not getting email notifications

    return data


def edge_deployment_healthcheck(uuid, data, vinlist, client, current_time):

    logger.info("Uploading Vin information to Edge_Deployment_Heathcheck_Table for scheduling.")

    time_now = "2099-12-31 00:00:00+00:00"

    expecteddeploymenttime = data

    # and datetime.fromisoformat(str(expecteddeploymenttime)) > datetime.now(tz=timezone.utc)

    if expecteddeploymenttime != datetime.fromisoformat(time_now):
        df = pd.DataFrame(
            columns=[
                'uploadUID', 'vin', 'expectedDeploymentTime', 'scheduledDeploymentTime', 'eventTime', 'repetitionNumber', 'isDeployable'
            ]
        )

        for vin in vinlist:
            df_one = {
                'uploadUID': uuid,
                'vin': vin,
                'expectedDeploymentTime': expecteddeploymenttime,
                'scheduledDeploymentTime': expecteddeploymenttime,
                'eventTime': current_time,
                'repetitionNumber': 0

            }
            df = df.append(df_one, ignore_index=True)

        job_config = bigquery.LoadJobConfig(
            schema=[
                bigquery.SchemaField(
                    "uploadUID", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField(
                    "vin", bigquery.enums.SqlTypeNames.STRING
                ),
                bigquery.SchemaField(
                    "expectedDeploymentTime", bigquery.enums.SqlTypeNames.TIMESTAMP
                ),
                bigquery.SchemaField(
                    "scheduledDeploymentTime", bigquery.enums.SqlTypeNames.TIMESTAMP
                ),
                bigquery.SchemaField(
                    "repetitionNumber", bigquery.enums.SqlTypeNames.INTEGER
                ),
                bigquery.SchemaField(
                    "isDeployable", bigquery.enums.SqlTypeNames.BOOLEAN
                ),
            ],
        )
        try:
            client.load_table_from_dataframe(
                df, config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE,
                job_config=job_config, project=config.PROJECT_ID
            )

            logger.info(
                "The VIN data is loaded into Edge deployment healthcheck")
        except Exception as e:
            logger.error(
                f"Failed load VIN data in Edge_Deployment_Healthcheck.")
            logger.error(e)

    else:
        logger.info(
            "User wants Edge deployment is to be scheduled immediately")


def edge_deployment_reschedule_query(uploaduid):
    query = f"""
            WITH vals AS
            (
                Select * from {config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE} 
                where uploadUID IN(Select distinct uploadUID from {config.MODEL_CATALOG_TABLE} 
                where modelGUID=(SELECT modelGUID FROM {config.MODEL_CATALOG_TABLE} where uploadUID=@uploaduid))
                AND scheduledDeploymentTime >= CURRENT_TIMESTAMP()

            )
            SELECT uploadUID, ARRAY_AGG(vin) as vin_list
            FROM vals
            GROUP BY uploadUID;
            """

    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("uploaduid", "STRING", uploaduid)
        ]
    )
    query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)

    return query_job


def delete_edge_deployment_healthcheck(row, current_time):
    query = f"""
            DELETE 
            FROM {config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE}
            WHERE uploadUID = '{row['uploadUID']}' and eventTime != '{current_time}'         
            """
    query_job = bq_client.query(query, project=config.PROJECT_ID)

    return query_job


def edge_deployment_reschedule_now(row, current_time, uploaduid, workflow=""):
    if workflow:
        workflow += '-edgedeploy'
    else:
        workflow = 'edgedeploy'

    deploy_dict = {}

    query_job2 = edge_deployment_reschedule_query(uploaduid)

    logger.debug(f"Query job id: {query_job2.job_id}")
    row2 = query_job2.result()

    if row2.total_rows == 0:
        logger.error(
            "Couldn't get VIN list for the modelGUID from DB. Check if VINs where added for this modelGUID or the vins would have been previously deployed.")

    else:
        for row2 in query_job2:
            
            query_job = delete_edge_deployment_healthcheck(row2, current_time)

            logger.debug(f"Query job id: {query_job.job_id}")

            deploy_dict[row2['uploadUID']] = list(set(row2['vin_list']))
            logger.debug(
                f"length of vin_list for UUID : {row2['uploadUID']} is {len(list(set(row2['vin_list'])))}")

        deploy_dict = json.dumps(deploy_dict)
        logger.info(deploy_dict)

    return deploy_dict, workflow


def edge_deployment_reschedule_future(row, uploaduid, current_time):

    query_job2 = edge_deployment_reschedule_query(uploaduid)

    logger.debug(f"Query job id: {query_job2.job_id}")
    row2 = query_job2.result()

    if row2.total_rows == 0:
        logger.error("No vins returned for rescheduling")

    else:
        for row2 in query_job2:
            edge_deployment_healthcheck(
                row2['uploadUID'], row['workflow']['specificationsDeploymentWhenToRun'], row2['vin_list'], bq_client, current_time)

            query_job = delete_edge_deployment_healthcheck(row2, current_time)

            logger.debug(f"Query job id: {query_job.job_id}")


def workflow_trigger(workflow, uploaduid, deploy_dict):

    

    for i in range(10):

        time = datetime.now(tz=timezone.utc).strftime("%Y%m%d%H%M%S%f")

        PIPELINE_PARAMETERS = {
        'uploadUID': uploaduid,
        'uploadids': deploy_dict,
        'actionJobUID': f"{config.TEMPLATE_PATH[workflow]['prefix']}-{time}"
        }
        
        try:
            job = aip.PipelineJob(
                display_name=f"{config.TEMPLATE_PATH[workflow]['prefix']}-{time}",
                template_path=config.TEMPLATE_PATH[workflow]['path'],
                job_id=f"{config.TEMPLATE_PATH[workflow]['prefix']}-{time}",
                pipeline_root=f"gs://{config.PIPELINE_BUCKET_NAME}",
                parameter_values=PIPELINE_PARAMETERS,
                enable_caching=False,
                project=config.PROJECT_ID,
                location=config.REGION
            )

            job.submit()

        except AlreadyExists:
            sleep(random.random())
            logger.debug(
                f"Can't create job with same job id. Retrying."
            )
            continue

        except Exception as e:
            logger.exception(
                f'Pipeline run has failed. Reason: ({str(e)})'
            )

        if job.has_failed:
            logger.debug(
                f"Vertex-AI pipeline for workflow was not triggered. The job could have failed because of workflow template path being changed.")
            logger.error(f"Vertex-AI pipeline for workflow was not triggered")

            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail=f"VertexAI pipeline job not submitted"
            )

        else:
            logger.debug(f"Vertex-AI pipeline for workflow was triggered with workflow: {workflow}")
            logger.info(f"Vertex-AI pipeline for workflow was triggered with workflow: {workflow}")

            
            # INSERT Rollback MESSAGE INTO BIG QUERY
            query_job = insert_to_pipeline_logs(
                uploaduid, f'pipeline-{time}', 'rollback-pipeline-trigger',
                'rollback', 'pass', f'pipeline job with name pipeline-{time} was submitted', f'pipeline-{time}'
            )
            logger.debug(f"Query id: {query_job.job_id}")

            raise HTTPException(
                status_code=status.HTTP_201_CREATED,
                detail=f"VertexAI job for rollback trigged. Job_ID : pipeline-{time}"
            )


def reschedule_decide_workflow(row, workflow, current_time, uploaduid, deploy_dict):

    if row['workflow']['stagesTestingToTest']:
        workflow = "test"

    if row['workflow']['stagesDeploymentToCloud']:
        if workflow:
            workflow += "-clouddeploy"
        else:
            workflow = "clouddeploy"
    if row['workflow']['stagesDeploymentToEdge'] and row['workflow']['specificationsDeploymentWhenToRun'] <= datetime.now(tz=timezone.utc):

        deploy_dict, workflow = edge_deployment_reschedule_now(row, current_time, uploaduid, workflow)

    elif row['workflow']['stagesDeploymentToEdge'] and row['workflow']['specificationsDeploymentWhenToRun'] > datetime.now(tz=timezone.utc):
        # IN this case user wants to reschedule

        edge_deployment_reschedule_future(row, uploaduid, current_time)

    return workflow, deploy_dict


def rollback_query(uploaduid):
    query = f"""
            SELECT * FROM {config.MODEL_CATALOG_TABLE} 
            WHERE modelGUID = (SELECT modelGUID FROM {config.MODEL_CATALOG_TABLE} WHERE uploadUID = @uploadUID GROUP BY 1)
            AND readiness = TRUE
            AND TRIM(uploadUID) != @uploadUID
            AND (workflow.stagesDeploymentToEdge = TRUE OR workflow.stagesDeploymentToCloud = TRUE)
            ORDER BY uploadedTime DESC
            LIMIT 1
            """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("uploadUID", "STRING", uploaduid),
        ]
    )

    query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)

    return query_job


def rollback_decide_workflow(deploymenttocloud, deploymenttoedge, testing):
    if deploymenttocloud:
        if deploymenttoedge:
            workflow = 'clouddeploy-edgedeploy'
        else:
            workflow = 'clouddeploy'

    elif deploymenttoedge:
        workflow = 'edgedeploy'

    if testing:
        workflow = "test-" + workflow

    return workflow


def rollback_deploy_dict(deploymenttoedge, row):
    if deploymenttoedge:
        query = f"""
            SELECT uploadUID,ARRAY_AGG(vin) AS vin_list FROM {config.EDGE_DEPLOYMENT_TABLE}
            WHERE uploadUID =@uploadUID AND apiStatus=TRUE
            GROUP BY  1
            """
        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("uploadUID", "STRING", row["uploadUID"])
            ]
        )

        query_job2 = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)
        logger.debug(f"Query id: {query_job2.job_id}")
        row2 = query_job2.result()

        deploy_dict = {}

        if row2.total_rows == 0:
            logger.error(
                f"Couldn't get VIN list for the given modelGUID. Check if VINs where added for this modelGUID. Rollback will fail")

            deploy_dict = ""

            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"VertexAI pipeline job for rollback not submitted"
            )

        else:
            for row2 in query_job2:
                deploy_dict[row2['uploadUID']] = list(set(row2['vin_list']))

            deploy_dict = json.dumps(deploy_dict)
            logger.info(deploy_dict)
    else:
        deploy_dict = ""

    return deploy_dict
