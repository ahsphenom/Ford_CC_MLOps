from datetime import datetime, timezone

PROJECT_ID = "mlopsplatform"
DATASET = "ford_cc"
MODEL_CATALOG_TABLE = f"{PROJECT_ID}.{DATASET}.Model_Catalog"
VIN_LIST_TABLE = f"{PROJECT_ID}.{DATASET}.VIN_List"
EDGE_DEPLOYMENT_HEALTHCHECK_TABLE = f"{PROJECT_ID}.{DATASET}.Edge_Deployment_Healthcheck"
EDGE_DEPLOYMENT_TABLE = f"{PROJECT_ID}.{DATASET}.Edge_Deployment"
PIPELINE_LOGS_TABLE = f"{PROJECT_ID}.{DATASET}.Pipeline_Log"
REGION = "us-central1"
PIPELINE_BUCKET_NAME = 'mlopsplatform-dev-mlpipelines'
INPUT_BUCKET_NAME = 'mlopsplatform-dev-modelartifacts'
NOTIF_URL = "https://proxy-notifications-api-xbp35kfhma-uc.a.run.app/notifications-api"

time = datetime.now(tz=timezone.utc).strftime("%Y%m%d%H%M%S")


TEMPLATE_PATH = {
    "valid": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/validation-workflow.json",
        "prefix": f"uv",
        "workflow": "validation"
    },
    "test": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/test-workflow.json",
        "prefix": f"t",
        "workflow": "test"
    },

    "test-clouddeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/test-clouddeploy-workflow.json",
        "prefix": f"tcd",
        "workflow": "test"
    },

    "test-edgedeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/test-edgedeploy-workflow.json",
        "prefix": f"ted",
        "workflow": "test"
    },

    "test-clouddeploy-edgedeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/test-clouddeploy-edgedeploy-workflow.json",
        "prefix": f"tcded",
        "workflow": "test"
    },

    "clouddeploy-edgedeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/clouddeploy-edgedeploy-workflow.json",
        "prefix": f"cded",
        "workflow": "cloud deployment"
    },

    "clouddeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/clouddeploy-workflow.json",
        "prefix": f"cd",
        "workflow": "cloud deployment"
    },

    "edgedeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/edgedeploy-workflow.json",
        "prefix": f"ed",
        "workflow": "edge deployment"
    }
}
