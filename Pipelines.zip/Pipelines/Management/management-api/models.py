from pydantic import BaseModel


class UploadAPI(BaseModel):
    uploadUID: str
    modelGUID: str = ""
    filePath: str
    uploadBy: str


class CancelAPI(BaseModel):
    uploadUID: str
    actionjobuid: str


class GetLogs(BaseModel):
    uploadUID: str
    actionjobuid: str


class Rollback(BaseModel):
    uploadUID: str


class Delete(BaseModel):
    uploadUID: str
    actionjobuid: str


class workflowreschedule(BaseModel):
    uploaduid: str
