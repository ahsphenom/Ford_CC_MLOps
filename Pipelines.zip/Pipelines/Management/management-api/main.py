import json
import random
from datetime import datetime, timezone
from time import sleep

import config
import models
import utils
from app_logger import CustomLogger
from fastapi import FastAPI, HTTPException, status
from google.api_core.exceptions import AlreadyExists
from google.cloud import aiplatform as aip
from google.cloud import bigquery, storage

logger = CustomLogger(__name__)

app = FastAPI()


@app.post('/orchestrator')
def orchestrator(uploadapi: models.UploadAPI):
    logger.debug(uploadapi)
    # wait and retry with new job_id for AIP if multiple files come at same the time
    for i in range(10):
        try:
            time = datetime.now(tz=timezone.utc).strftime("%Y%m%d%H%M%S%f")
            actionjobuid = f"uv-{time}"
            logger.debug(uploadapi)

            job = aip.PipelineJob(
                display_name=actionjobuid,
                job_id=actionjobuid,
                enable_caching=False,
                template_path=config.TEMPLATE_PATH['valid']['path'],
                pipeline_root=f"gs://{config.PIPELINE_BUCKET_NAME}",

                parameter_values={
                    'UUID': uploadapi.uploadUID,
                    'modelGUID': uploadapi.modelGUID,
                    'file_path': uploadapi.filePath,
                    'uploadedBy': uploadapi.uploadBy,
                    'time': time,
                }
            )
            logger.info(f"Triggering VertexAI validation pipeline : {actionjobuid}")
            job.submit()

        except AlreadyExists:
            sleep(random.random())
            logger.debug(
                f"Can't create job with same job id. Retrying."
            )
            continue

        except Exception as e:
            logger.exception(
                f'Pipeline run has failed. Reason: ({str(e)})'
            )

            # INSERT FAIL MESSAGE INTO BIG QUERY
            query_job = utils.insert_to_pipeline_logs(
                uploadapi.uploadUID, f'pipeline-{time}', 'NA',
                'validation', 'fail', 'pipeline job was not submitted', 'NA'
            )
            logger.debug(f"Query id: {query_job.job_id}")
            logger.info(f"Vertex-AI pipeline job could not be submitted.")

            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"VertexAI job not triggered.")

        if job.has_failed:

            logger.debug(
                'Pipeline run has failed due to some technical reasons.'
            )

            query_job = utils.insert_to_pipeline_logs(
                uploadapi.uploadUID, f'pipeline-{time}', 'NA',
                'validation', 'fail', 'pipeline job was not submitted', 'NA'
            )
            logger.debug(f"Query id: {query_job.job_id}")
            logger.info(f"Vertex-AI pipeline job could not be submitted.")

            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail=f"VertexAI pipeline job not submitted."
            )
        else:
            logger.debug('Pipeline run has been triggered.')

            # INSERT QUERY FOR VALIDATION STAGE IN PROGRESS
            query_job = utils.insert_to_pipeline_logs(
                uploadapi.uploadUID, f'pipeline-{time}', 'NA',
                'validation', 'in-progress', f'pipeline job with name {actionjobuid} was submitted', 'NA'
            )
            logger.debug(f"Query id: {query_job.job_id}")

            # INSERT PASS MESSAGE INTO BIG QUERY
            query_job = utils.insert_to_pipeline_logs(
                uploadapi.uploadUID, f'pipeline-{time}', 'pipeline-trigger',
                'validation', 'pass', f'pipeline job with name {actionjobuid} was submitted', f'{actionjobuid}'
            )
            logger.debug(f"Query id: {query_job.job_id}")

            raise HTTPException(
                status_code=status.HTTP_201_CREATED,
                detail=f"VertexAI job trigged. Job_ID : {actionjobuid}"
            )


@app.post('/stop')
def cancel(cancelapi: models.CancelAPI):
    logger.debug(cancelapi)
    bq_client = bigquery.Client()
    try:
        query = f"""
            SELECT *
            FROM {config.PIPELINE_LOGS_TABLE}
            WHERE actionJobUID=@actionjobuid
            ORDER BY eventTime DESC
            LIMIT 1
            """
        job_config = bigquery.QueryJobConfig(
            query_parameters=[
                bigquery.ScalarQueryParameter("actionjobuid", "STRING", cancelapi.actionjobuid),
            ]
        )

        query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)
        logger.debug(f"Query id: {query_job.job_id}")

        for row in query_job:
            r_name = row['VAIJobID']

        # Cancellation is not guaranteed from Vertex AI.
        # TODO: To look for an option to state of specified job after some time.
        name = aip.PipelineJob.get(resource_name=str(r_name))
        logger.info(f"Trying to cancel Pipeline run: {r_name}")
        name.cancel()

        query_job = utils.insert_to_pipeline_logs(
            cancelapi.uploadUID, cancelapi.actionjobuid, 'pipeline-stop',
            'NA', 'stopped', 'pipeline job was stopped', cancelapi.actionjobuid
        )
        logger.debug(f"Query id: {query_job.job_id}")

        return {
        "message": f"VetexAI job cancelled."
    }

    except Exception:

        logger.exception("Unable to cancel the pipeline run.")

        query_job = utils.insert_to_pipeline_logs(
            cancelapi.uploadUID, cancelapi.actionjobuid, 'validation',
            'pipeline-stop', 'fail', 'failed to stop', cancelapi.actionjobuid
        )
        logger.debug(f"Query id: {query_job.job_id}")

        return {
        "message": f"Cannot cancel VertexAI pipeline {r_name} job."
    }



@app.post('/rollback')
def rollback(rollback: models.Rollback):
    logger.debug(rollback)

    query_job = utils.rollback_query(rollback.uploadUID)

    logger.debug(f"Query id : {query_job.job_id}")

    row = query_job.result()
    if row.total_rows == 0:
        return {"Message": "Cannot rollback current model."}
    else:
        for row in query_job:

            logger.debug(f"the UUID to the rollback model will be {row['uploadUID']}")

            deploymenttoedge = row.get('workflow', 'false').get('stagesDeploymentToEdge', 'false')
            deploymenttocloud = row.get('workflow', 'false').get('stagesDeploymentToCloud', 'false')
            testing = row.get('workflow', 'false').get('stagesTestingToTest', 'false')

            workflow = ""

            workflow = utils.rollback_decide_workflow(deploymenttocloud, deploymenttoedge, testing)

            deploy_dict = utils.rollback_deploy_dict(deploymenttoedge, row)

            logger.info(f"The workflow going to be run is: {workflow}")

            utils.workflow_trigger(workflow, rollback.uploadUID, deploy_dict)


@app.post('/delete')
def delete_pipeline():
    pipeline_jobs = aip.PipelineJob.list()

    logger.info('Deleting all stale pipeline runs.')

    # pipeline state is enum with following values:
    # PIPELINE_STATE_UNSPECIFIED, PIPELINE_STATE_QUEUED, PIPELINE_STATE_PENDING, PIPELINE_STATE_RUNNING, PIPELINE_STATE_SUCCEEDED, PIPELINE_STATE_FAILED, PIPELINE_STATE_CANCELLING, PIPELINE_STATE_CANCELLED, PIPELINE_STATE_PAUSED
    for job in pipeline_jobs:
        if int(job.state) in [4, 5, 7]:
            job.delete()
        else:
            logger.debug(f"{job}'s state not one of cancelled, failed or succeeded.")

    return {
        "message": "All pipeline jobs in succeeded, failed and cancelled state are deleted successfully."
    }


@app.post('/logs')
def logs(logs: models.GetLogs):
    logger.debug(logs)
    bq_client = bigquery.Client()

    query = f"""
            SELECT ARRAY_AGG(distinct VAIJobID) AS listvaijobid 
            FROM {config.PIPELINE_LOGS_TABLE}
            WHERE actionJobUID = @actionjobuid
            """
    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("actionjobuid", "STRING", logs.actionjobuid),
        ]
    )

    query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)
    logger.debug(f"Query id: {query_job.job_id}")
    listvaijobid = query_job.result()

    for jobid in listvaijobid:
        vaijobid = jobid
    
    ts_wise_logs = {}

    for vai in vaijobid['listvaijobid']:

        logger.debug(f"pipelineName : {vai}")

        storage_client = storage.Client()
        bucket = storage_client.get_bucket(config.PIPELINE_BUCKET_NAME)
        blobs = storage_client.list_blobs(bucket, prefix=f"316595948851/{vai}/")

        logger.debug(bucket)

        try:
            for blob in blobs:
                finalvai = vai
                # Variable above will be used for final consolidated log file
                if blob.name.split('/')[-1] == 'user_logs':
                    logger.debug(blob.name)
                    blob2 = bucket.blob(blob.name)
                    blob2.download_to_filename('log_file')
                    with open('./log_file') as log_file:
                        for line in log_file:
                            ts_val = line.split(" ::")[0]
                            ts_wise_logs[ts_val] = line
        except RuntimeError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Consolidated logs for run: {vai} not created."
            )
            
    with open(f"{logs.actionjobuid}_consolidated_log.txt", "a") as consolidated_log:
        for _, log_val in sorted(list(ts_wise_logs.items())):
            consolidated_log.write(log_val)
    
    logger.debug(f"316595948851/{finalvai}/{logs.actionjobuid}_consolidated_log.txt")

    blob = bucket.blob(f"316595948851/{finalvai}/{logs.actionjobuid}_consolidated_log.txt")
    blob.upload_from_filename(f"{logs.actionjobuid}_consolidated_log.txt")
    logs_file_path = f"gs://{config.PIPELINE_BUCKET_NAME}/316595948851/{finalvai}/{logs.actionjobuid}_consolidated_log.txt"
    return {
        "log_file_path": logs_file_path
    }


@app.post('/edge_deploy_scheduler')
def edge_deploy_scheduler():

    bq_client = bigquery.Client()
    deploy_dict = {}
    query = f"""
    SELECT uploadUID, ARRAY_AGG(vin) as vin_list
    FROM {config.EDGE_DEPLOYMENT_HEALTHCHECK}
    WHERE scheduledDeploymentTime BETWEEN CURRENT_TIMESTAMP() AND TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 3 HOUR) AND isDeployable IS TRUE
    GROUP BY 1
    """

    query_job = bq_client.query(query, project=config.PROJECT_ID)
    row = query_job.result()
    if row.total_rows > 0:
        for row in query_job:
            deploy_dict[row['uploadUID']] = list(set(row['vin_list']))

    logger.debug(f"Edge deployment job running for : {deploy_dict}")
    return json.dumps(deploy_dict)


@app.post('/workflowrescheduler')
def workflow_reschedule(workflows: models.workflowreschedule):

    bq_client = bigquery.Client()
   
    current_time = datetime.now(tz=timezone.utc)

    # Check if readiness flag is true

    query = f"""
        SELECT * 
        FROM {config.MODEL_CATALOG_TABLE}
        where uploadUID=@uploadUID    
        """

    job_config = bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("uploadUID", "STRING", workflows.uploaduid)
        ]
    )

    query_job = bq_client.query(query, job_config=job_config, project=config.PROJECT_ID)
    logger.debug(f"Query id: {query_job.job_id}")

    deploy_dict = ""
    workflow = ""

    for data in query_job:
        row = data

    if row['readiness']:

        values = utils.reschedule_decide_workflow(row, workflow, current_time, workflows.uploaduid, deploy_dict)

        if(isinstance(values, tuple)):
            workflow, deploy_dict = values[0], values[1]
        else:
            workflow = values

        if workflow:
            logger.info(f"The workflow going to be run is : {workflow}")

            utils.workflow_trigger(workflow, workflows.uploaduid, deploy_dict)

        else:
            logger.info('No workflow was triggered.')
            raise HTTPException(
                status_code=status.HTTP_201_CREATED,
                detail=f"Edge deployment rescheduling was successful."
            )

    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=f"Readiness flag is not set to true."
        )
