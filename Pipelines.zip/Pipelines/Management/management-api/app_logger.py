import logging

from google.cloud import logging as cloudlogging
from google.cloud.logging.handlers import CloudLoggingHandler


class CustomLogger(object):
    def __init__(self, name):
        # Initial construct.
        self.name = name

        # Define Formatters.
        self.platform_log_format = "%(levelname)-8s :: %(name)-8s :: (%(filename)s).%(funcName)s(%(lineno)d) :: %(message)s"

        # Complete logging config.
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        self.logger.addHandler(
            self.__get_platform_log_handler(self.platform_log_format)
        )

    def __get_platform_log_handler(self, format):
        # Get platform log handler.
        log_client = cloudlogging.Client()
        platform_log_handler = CloudLoggingHandler(log_client)
        platform_log_handler.setLevel(logging.DEBUG)
        platform_log_handler.setFormatter(logging.Formatter(format))
        return platform_log_handler

    def info(self, msg):
        self.logger.info(msg, stacklevel=2)

    def error(self, msg):
        self.logger.error(msg, stacklevel=2)

    def debug(self, msg):
        self.logger.debug(msg, stacklevel=2)

    def warning(self, msg):
        self.logger.warn(msg, stacklevel=3)

    def exception(self, msg):
        self.logger.exception(msg, stacklevel=3, exc_info=1)
