from datetime import datetime, timezone

# VertexAI Template path for workflow components
bq_load_path='Workflows/bq_load_data/component.yaml'
preproc_load_path='Workflows/decide_preprocess/component.yaml'
preprocess_path='Workflows/preprocess/component.yaml'
inference_path='Workflows/inference/component.yaml'
cloud_deploy_path='Workflows/cloud_deploy/component.yaml'
master_list_creation_path='Workflows/master_list_creation/component.yaml'
package_creation_path='Workflows/package_creation/component.yaml'

Run_Preprocess="Run Preprocess"
Skip_Preprocess="Skip Preprocess"


PROJECT_ID = "mlopsplatform"
DATASET = "ford_cc"
REGION = "us-central1"
CLOUD_MACHINE_TYPE = "n1-standard-2"

TIMEFRAMES = ['1', '7', '30', 'All']
time = datetime.now(tz=timezone.utc).strftime("%Y%m%d%H%M%S")
CURRENT_DATE = datetime.now().strftime("%Y-%m-%d")

MODEL_CATALOG_TABLE = f"{PROJECT_ID}.{DATASET}.Model_Catalog"
VIN_LIST_TABLE = f"{PROJECT_ID}.{DATASET}.VIN_List"
EDGE_DEPLOYMENT_HEALTHCHECK_TABLE = f"{PROJECT_ID}.{DATASET}.Edge_Deployment_Healthcheck"
EDGE_DEPLOYMENT_TABLE = f"{PROJECT_ID}.{DATASET}.Edge_Deployment"
PIPELINE_LOGS_TABLE = f"{PROJECT_ID}.{DATASET}.Pipeline_Log"
CLOUD_DEPLOYMENT_TABLE = f"{PROJECT_ID}.{DATASET}.Cloud_Deployment"
DRIFT_TABLE = f"{PROJECT_ID}.{DATASET}.Drift"

PIPELINE_BUCKET_NAME = 'mlopsplatform-dev-mlpipelines'
INPUT_BUCKET_NAME = 'mlopsplatform-dev-modelartifacts'
INPUT_BUCKET_URI = f"gs://{INPUT_BUCKET_NAME}/"

DATAFLOW_JOB_NAME = "driftpipeline-" + datetime.now().strftime('%Y%m%d-%H%M%S')
DATAFLOW_BUCKET = "mlopsplatform-dev-dataflow"

NOTIF_URL = "https://proxy-notifications-api-xbp35kfhma-uc.a.run.app/notifications-api"
VSS_SERVICE_URL = "https://apigtwqa.ford.com/oneford/api"
VSS_SERVICE_CLIENT_ID = "447050d7-a2ea-475e-bb70-942965852ff7"
VSS_SERVICE_CLIENT_SECRET = "P0tF3lI7tF2yT6vO5kX8rN6wJ2rR1vA8hS7hN0sE4iH0aY2jK1"

xgboost_image_path = "gcloud container images list --repository gcr.io/cloud-aiplatform/prediction | grep xgboost-cpu"
tf_image_path = "gcloud container images list --repository gcr.io/cloud-aiplatform/prediction | grep tf2-cpu"
sklearn_image_path = "gcloud container images list --repository gcr.io/cloud-aiplatform/prediction | grep sklearn-cpu"
MODELTYPE = ["regression", "classification"]
FRAMEWORK = ["xgboost", "scikit-learn", "tensorflow"]

MODELGUID_REGEX = r'[A-Za-z0-9]{10}$'
VIN_REGEX = r'(?P<wmi>[1-5]{1}[A-HJ-NPR-Z\d]{2})(?P<vds>[A-HJ-NPR-Z\d]{5})(?P<check>[\dX])(?P<vis>(?P<year>[A-HJ-NPR-Z\d])(?P<plant>[A-HJ-NPR-Z\d])(?P<seq>[A-HJ-NPR-Z\d]{6}))$'
PROGRAM_CODE_REGEX = r'[A-Za-z0-9]{3,6}'
FEATURE_CODE_REGEX = r'[A-Z0-9]{5}|None'
FAMILY_CODE_REGEX = r'[A-Za-z0-9]{3,6}|None'
MODEL_YEAR_REGEX = r'[2][0-9]{3}'
DRIVER_ID_REGEX = r'[A-Za-z0-9]{3,6}'
MODEL_OWNERS_LIST_REGEX = r'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}'
THRESHOLDS = r'0(\.\d+)?|1\.0'
MODEL_VERSION = r'^(\d+\.)?(\d+\.)?(\*|\d+)$'
WHEN_TO_RUN_REGEX = r'[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1]) (2[0-3]|[01][0-9]):[0-5][0-9]:[0-6][0-9]'

TMC_SERVICE_URL = "fnv3-deployment-service-xbp35kfhma-ue.a.run.app"
EDGE_DEPLOYMENT_TABLE_SCHEMA = [
    {'name': 'uploadUID', 'type': 'STRING'},
    {'name': 'eventTime', 'type': 'TIMESTAMP'},
    {'name': 'resourceID', 'type': 'STRING'},
    {'name': 'apiStatus', 'type': 'BOOLEAN'},
    {'name': 'deploymentID', 'type': 'STRING'},
    {'name': 'vin', 'type': 'STRING'},
    {'name': 'repetitionNumber', 'type': 'INTEGER'}
]
AGGREGATED_VIEW_NAME = f"{PROJECT_ID}.{DATASET}.last_used_model"

TEMPLATE_PATH = {
    "valid": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/validation-workflow.json",
        "prefix": f"uv",
        "workflow": "validation"
    },
    "test": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/test-workflow.json",
        "prefix": f"t",
        "workflow": "test"
    },

    "test-clouddeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/test-clouddeploy-workflow.json",
        "prefix": f"tcd",
        "workflow": "test"
    },

    "test-edgedeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/test-edgedeploy-workflow.json",
        "prefix": f"ted",
        "workflow": "test"
    },

    "test-clouddeploy-edgedeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/test-clouddeploy-edgedeploy-workflow.json",
        "prefix": f"tcded",
        "workflow": "test"
    },

    "clouddeploy-edgedeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/clouddeploy-edgedeploy-workflow.json",
        "prefix": f"cded",
        "workflow": "cloud deployment"
    },

    "clouddeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/clouddeploy-workflow.json",
        "prefix": f"cd",
        "workflow": "cloud deployment"
    },

    "edgedeploy": {
        "path": "gs://mlopsplatform-dev-mlpipelines-templates/edgedeploy-workflow.json",
        "prefix": f"ed",
        "workflow": "edge deployment"
    }
}
