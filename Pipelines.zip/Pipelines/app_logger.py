import logging

from google.cloud import logging as cloudlogging
from google.cloud.logging.handlers import CloudLoggingHandler


class CustomLogger(object):
    def __init__(self, name, user_logs_file):
        # Initial construct.
        self.name = name
        self.user_logs_file = user_logs_file
        # Define Formatters.
        self.user_log_format = "%(asctime)s :: %(levelname)-8s :: %(filename)-20s :: %(message)s"
        self.platform_log_format = "%(actiobjobuid)-20s :: %(levelname)-8s :: %(name)-8s :: (%(filename)s).%(funcName)s(%(lineno)d) :: %(message)s"

        # Complete logging config.
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        self.logger.addHandler(
            self.__get_user_log_handler(self.user_log_format)
        )
        self.logger.addHandler(
            self.__get_platform_log_handler(self.platform_log_format)
        )

    def __get_user_log_handler(self, format):
        # Get user log handler.
        user_log_handler = logging.FileHandler(self.user_logs_file)
        user_log_handler.setLevel(logging.INFO)
        user_log_handler.setFormatter(logging.Formatter(format))
        return user_log_handler

    def __get_platform_log_handler(self, format):
        # Get platform log handler.
        log_client = cloudlogging.Client()
        platform_log_handler = log_client.get_default_handler()
        platform_log_handler.setLevel(logging.DEBUG)
        platform_log_handler.setFormatter(logging.Formatter(format))
        return platform_log_handler

    def set_actionJobUID(self, actionJobUID):
        # Set action job uid
        self.actionJobUID = actionJobUID

    def info(self, msg):
        self.logger.info(msg, stacklevel=2, extra={'actiobjobuid': self.actionJobUID})

    def error(self, msg):
        self.logger.error(msg, stacklevel=2, extra={'actiobjobuid': self.actionJobUID})

    def debug(self, msg):
        self.logger.debug(msg, stacklevel=2, extra={'actiobjobuid': self.actionJobUID})

    def warning(self, msg):
        self.logger.warn(msg, stacklevel=3, extra={'actiobjobuid': self.actionJobUID})

    def exception(self, msg):
        self.logger.exception(msg, stacklevel=3, exc_info=1, extra={'actiobjobuid': self.actionJobUID})
