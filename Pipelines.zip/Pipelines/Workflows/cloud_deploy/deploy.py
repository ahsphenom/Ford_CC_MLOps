import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

import config
import pandas_gbq as pb
from app_logger import CustomLogger
from google.cloud import aiplatform, bigquery, storage
import utils
import bq_utils

# Create logger object
logger = CustomLogger(__name__, 'cloud_dep_log')

storage_client = storage.Client()
output_bucket = storage_client.get_bucket(config.PIPELINE_BUCKET_NAME)


def deploy_model(args):
    """
    This function is used to check deployment status of model and deploy it.

    """
    action='cloud deployment'
    aiplatform.init(project=config.PROJECT_ID, location=config.REGION)

    # BQ table fields
    uploadUID = metadata['uploadUID']
    
    # WRITE TO BQ PIPELINE_LOG TABLE
    log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'NA',
            "stage": action,
            "status": 'in-progress',
            "desc": 'NA',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

    bq_utils.insert_to_pipeline_logs(
        log_input
    )

    # Endpoint creation . Pipeline job should be deleted after any run.
    try:
        endpoint = aiplatform.Endpoint.create(
            display_name=f'endpoint-{current_datetime}', project=config.PROJECT_ID, location=config.REGION
        )
    except Exception as e:
        logger.exception("Endpoint creation failed.")
    
    result,description=utils.endpoint_creation(endpoint,logger)

    # Construct a BigQuery client object.
    client = bigquery.Client()

    log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'endpoint creation',
            "stage": action,
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

    # WRITE TO BQ PIPELINE_LOG TABLE
    bq_utils.insert_to_pipeline_logs(
        log_input
    )

    if result == 'fail':
        uploadUID = metadata['uploadUID']
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Cloud deployment Failed | {metadata['modelGUID']}"
        msg = f"""Hey, Your model could not be deployed to cloud. Reason - Endpoint could not be created!"""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)

    # Fetch framework name compatible to VAI.
    if metadata['frameworkInfo']['frameworkName'].lower() == 'xgboost':
        frameworkname = 'xgboost'
    elif metadata['frameworkInfo']['frameworkName'].lower() == 'tensorflow':
        frameworkname = 'tf2'
    elif metadata['frameworkInfo']['frameworkName'].lower() == 'sklearn':
        frameworkname = 'sklearn'

    # CHECK IF DEPENDENCIES ARE PRESENT AND DEPLOYED.
    model_dependency_list = metadata['modelDependency']
    if model_dependency_list:
        logger.info(f"Model dependencies: {model_dependency_list}")
        model_dependency_list.append('')
        logger.debug(model_dependency_list)
        dependency_tup = tuple(model_dependency_list)
        logger.debug(dependency_tup)
        
        df=bq_utils.check_model_dependency(dependency_tup)
        dependency_status_list = df['status'].tolist()
    else:
        dependency_status_list = [True]
        logger.info('No dependencies. Model ready to be deployed.')

    if all(dependency_status_list):
        # Create model container
        model = aiplatform.Model.upload(
            display_name=f"{frameworkname}-{current_datetime}",
            artifact_uri=f'gs://{config.PIPELINE_BUCKET_NAME}/{args.actionJobUID}/model/',
            serving_container_image_uri=f"gcr.io/cloud-aiplatform/prediction/{frameworkname}-cpu.{version}:latest")

        # deploy the model
        try:
            model.deploy(
                endpoint=endpoint,
                deployed_model_display_name=f"{frameworkname}_{current_datetime}",
                machine_type=config.CLOUD_MACHINE_TYPE,
                min_replica_count=1,
                max_replica_count=1,
            )

            model.wait()

            # Delete curent model from new folder to add new model file in it, since only one model can reside in that folder.
            blobs = output_bucket.list_blobs(prefix=f'{args.actionJobUID}/model/')
            for blob in blobs:
                blob.delete()

            # Save data to the output params
            vertex_endpoint = '"'+endpoint.resource_name+'"'
            vertex_model = '"'+model.resource_name+'"'
            status = "True"
            deploy_status = "Deployed"
            result = "pass"
            description = "Model deployed successfully. It is Deployable since dependencies are met or there are no dependencies."
        except Exception as e:
            logger.exception("Error during model deployment.")
            error_msg = e.message
            # CALL TO NOTIFICATIONS API
            uploadUID = metadata['uploadUID']
            dl_list = utils.get_dl_list(uploadUID)
            subject = f"Cloud Deployment: Fail: {metadata['modelGUID']}"
            msg = f"""Hey, Model could not be deployed:{error_msg}."""
            req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
            logger.info(req_data)
            
            status = "False"
            deploy_status = "Undeployed"
            result = "fail"
            description = "Model did not get deployed. Check for detailed errors in logs."

        # CLOUD DEPLOYMENT TABLE INSERT
        bq_utils.insert_to_cloud_deployment(uploadUID,vertex_endpoint,status,vertex_model)
        

        # WRITE TO BQ PIPELINE_LOG TABLE
        log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'model deploy',
            "stage": action,
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

        bq_utils.insert_to_pipeline_logs(
            log_input
        )

        # STATUS TRACKER UPDATE
        status_query2 = f"""
            UPDATE {config.MODEL_CATALOG_TABLE}
            SET deploymentStatus='{deploy_status}'  WHERE uploadUID='{uploadUID}'
            """
        client.query(status_query2, project=config.PROJECT_ID, location='US')
        
        
        # WRITE TO BQ PIPELINE_LOG TABLE

        log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'NA',
            "stage": action,
            "status": "completed",
            "desc": "NA",
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }


        bq_utils.insert_to_pipeline_logs(
           log_input
        )

        # CALL TO NOTIFICATIONS API
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Cloud Deployment: {result}: {metadata['modelGUID']}"
        msg = f"""Hey, Cloud Deployment resulted in {result} because of the following reasons:
        {description}."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
    else:
        logger.exception("Model is undeployable since dependencies are not met.")

        # CALL TO NOTIFICATIONS API
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Cloud Deployment: Fail: {metadata['modelGUID']}"
        msg = """Hey, Cloud Deployment has failed because of the following reasons:
        Model is undeployable since dependencies are not met."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)

    with open("cloud_dep_log") as f:
        with open(args.user_logs, "w") as f1:
            for line in f:
                f1.write(line)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # Pipeline input arguments
    parser.add_argument("--actionJobUID", type=str)
    # Pipeline output arguments
    parser.add_argument('--user_logs', type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(args.actionJobUID)
    
    try:
        Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        pass

    # Declare and Initialize Env Variables
    current_datetime = datetime.now().strftime("%Y%m%d%H%M%S")

    # Fetch Metadata file from GCS.
    try:
        meta_blob = output_bucket.blob(f"{args.actionJobUID}/updatedMetadata.json")
        meta_blob.download_to_filename('metadata.json')
        
        # Load METADATA file.
        metadata = json.load(open('metadata.json'))
    except Exception as e:
        logger.exception("Metadata file did not get imported. Please check the path of file.")


    # Fetch Model details from Metadata
    uploadUID = metadata['uploadUID']
    framework_format = metadata['frameworkInfo']['format']
    version = metadata['frameworkInfo']['version']
    frameworkname = metadata['frameworkInfo']['frameworkName']

    # Create empty folder
    new_folder = output_bucket.blob(f'{args.actionJobUID}/model/')
    new_folder.upload_from_string('')

    # Fetch Model_file path.
    artifact_bucket = storage_client.get_bucket(config.INPUT_BUCKET_NAME)
    try:
        model_file_rel_path = '/'.join(metadata['modelWeightsFile'].split('$')[0].split('/')[3:])
        logger.debug(model_file_rel_path)
        model_blob = artifact_bucket.blob(model_file_rel_path)
        model_blob.download_to_filename(f"model.{framework_format}")
    except Exception as e:
        logger.exception("Model file did not get imported. Please check the path of file.")

        # WRITE TO BQ PIPELINE_LOG TABLE
        log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'model file import',
            "stage": 'cloud deployment',
            "status": "fail",
            "desc": 'Model file did not get imported. Please check the path of file.',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }
        bq_utils.insert_to_pipeline_logs(
        log_input )
        
        # CALL TO NOTIFICATIONS API    
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Cloud deployment failed | {metadata['modelGUID']}"
        msg = f"""Hey, Model file did not get imported. Please check the path of file."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)

    # Upload the model in new folder with new name.
    
    model='model.'

    if framework_format == 'pb':
        model_folder2 = output_bucket.blob(f'{args.actionJobUID}/model/'+'saved_model.'+framework_format)
        model_folder2.upload_from_filename(model+framework_format)
    else:
        model_folder2 = output_bucket.blob(f'{args.actionJobUID}/model/'+model+framework_format)
        model_folder2.upload_from_filename(model+framework_format)

    logger.debug(f"Pipeline inputs: {args}")
    
    deploy_model(args)
