import argparse
import importlib
import json
import os
from pathlib import Path
import sys

import config
import utils
import bq_utils
import gsutil_utils
from app_logger import CustomLogger
from google.cloud import storage

# Create logger object
logger = CustomLogger(__name__, 'preprocess_log')

storage_client = storage.Client()
output_bucket = storage_client.get_bucket(config.PIPELINE_BUCKET_NAME)


def get_processed_data_and_ground_truths(args):

    # Fetch details from validated metadata.
    UUID = metadata['uploadUID']
    

    try:
        model_artificats_uri = f"gs://{config.INPUT_BUCKET_NAME}/{UUID}"
        logger.info(os.listdir('.'))
        logger.info(os.listdir(f'{metadata["modelGUID"]}'))
        
        inference_script_name = metadata['inferenceFile'].split('/')[-1].split('$')[0].split('.')[0]
        logger.debug(inference_script_name)
        x = importlib.import_module(f"{metadata['modelGUID']}.{inference_script_name}")
        preproc_data, y_val = x.preprocessing(f"{metadata['modelGUID']}/{metadata['testDataset']['fileName']}")
        preproc_data.to_csv(f"{model_artificats_uri}/preprocessed.csv", index=False)
        y_val.to_csv(f"{model_artificats_uri}/y_val.csv", index=False)
        result = "pass"
        description = "Preprocessing completed"
        logger.debug(f"{model_artificats_uri}/y_val.csv, {model_artificats_uri}/preprocessed.csv")
        logger.info("Preprocessing completed sucessfully since preprocessed data and ground truths are created.")
    except Exception as e:
        result = "fail"
        description = "Preprocessing failed"
        logger.exception("Preprocessing failed since preprocessed data and ground truths are not created.")
        uploadUID = metadata['uploadUID']
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""Hey, Preprocessing failed since preprocessed data and ground truths are not created."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)

    # WRITE TO BQ PIPELINE_LOG TABLE

    log_input = {
            "uuid":UUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'preprocessing',
            "stage": 'testing',
            "status": f'{result}',
            "desc":  f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

    bq_utils.insert_to_pipeline_logs(
        log_input
    )
    
    if result=='fail':
        sys.exit(0)

    with open("preprocess_log") as f:
        with open(args.user_logs, "w") as f1:
            for line in f:
                f1.write(line)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # Pipeline input arguments
    parser.add_argument("--actionJobUID", type=str)
    # Pipeline output arguments
    parser.add_argument('--user_logs', type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(args.actionJobUID)

    Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)

    meta_blob = output_bucket.blob(f"{args.actionJobUID}/updatedMetadata.json")
    meta_blob.download_to_filename('metadata.json')

    # Load METADATA file.
    metadata = json.load(open('metadata.json'))

    # Download entire package.
    bucket_name = config.INPUT_BUCKET_NAME
    artifact_folder = metadata['metadataFile'].split('/')[3]
    try:
        downloaded_files = gsutil_utils.download_from_bucket(
            bucket_name, artifact_folder, metadata['modelGUID']
        )
        logger.debug(f"list of files downloaded to {metadata['modelGUID']} folder: {downloaded_files}")
    except Exception as e:
        logger.exception("Model Package could not be downloaded.")
        uploadUID = metadata['uploadUID']
        
        # WRITE TO BQ PIPELINE_LOG TABLE
        log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'preprocessing',
            "stage": 'testing',
            "status": 'fail',
            "desc":  'Model Package could not be downloaded. Please check the path of model package.',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

        bq_utils.insert_to_pipeline_logs(
        log_input)
        
        # CALL TO NOTIFICATIONS API    
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""Hey, Could not download package. Please check the path of model package"""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)

    # Install pip packages from requirements.txt
    if 'requirements.txt' in os.listdir(f"{metadata['modelGUID']}"):
        pip_packages = [line for line in open(f"{metadata['modelGUID']}/requirements.txt")]
        logger.debug(f"Installing the following packages from requirements.txt: {pip_packages}")
        
        os.system(f"pip3 install -r {metadata['modelGUID']}/requirements.txt")
    else:
        logger.debug(f"No requirements.txt available.")

    logger.debug(f"Pipeline inputs: {args}")
    get_processed_data_and_ground_truths(args)
