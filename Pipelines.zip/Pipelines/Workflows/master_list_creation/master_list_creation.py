import argparse
import json
from pathlib import Path
import sys
import config
import pandas as pd
import pandas_gbq as pb
import utils
import bq_utils
from app_logger import CustomLogger
from google.cloud import storage

# Create logger object
logger = CustomLogger(__name__, 'master_list_creation_log')

stage='edge deployment'
action ='Master List Creation'


storage_client = storage.Client()
output_bucket = storage_client.get_bucket(config.PIPELINE_BUCKET_NAME)

# Function to return a dictionary of an object of class SlaveDependency


def unpack(x):
    ret = dict()
    for k, v in x.__dict__.items():
        if k == "dependencies":
            v_list = []
            for v_prime in v:
                v_list.append(unpack(v_prime))
            ret[k] = v_list
        else:
            ret[k] = v
    return ret


def get_param_status(uploaduid, vin):
    '''
    INPUT: modelGUID
    OUTPUT: all_models_list with dependencies

    '''

    df1 = bq_utils.get_param_status_sql1(vin,uploaduid)
    df2 = bq_utils.get_param_status_sql2(vin,uploaduid)
    df3=  bq_utils.get_param_status_sql3(vin,uploaduid)

    df = df1.merge(df2, how='outer', on=['uploadUID', 'vin']).merge(df3, how='outer', on=['uploadUID', 'vin']).drop(columns=['eventTime_x', 'eventTime_y'])

    df.apiStatus = df.apiStatus.apply(lambda x : "" if str(x)=="nan" else x)
    df.isDeployable = df.isDeployable.apply(lambda x : "" if str(x)=="nan" else x)
    df.expectedDeploymentTime = df.expectedDeploymentTime.apply(lambda x : False if str(x)=="NaT" else x)
    
    if len(df):
        df_dict = df.iloc[0].to_dict()
        if str(df_dict['expectedDeploymentTime']) == "2099-12-31 00:00:00+00:00":
            df_dict['expectedDeploymentTime'] = False
        if df_dict['apiStatus']:
            df_dict['isDeployable'] = True
    elif not len(df):
        sql = f"SELECT uploadUID, readiness  FROM {config.MODEL_CATALOG_TABLE} WHERE uploadUID = '{uploaduid}'"
        df = pb.read_gbq(sql, project_id=config.PROJECT_ID)
        df_dict = df.iloc[0].to_dict()
        df_dict["VINID"] = ""
        df_dict["apiStatus"] = ""
        df_dict["isDeployable"] = ""
        df_dict["expectedDeploymentTime"] = ""
    return df_dict


# CREATE A FUNCTION TO GET DEPENDENCIES AND VINs LIST
def get_dependency(uploaduid):
    '''
    INPUT: uploaduid
    OUTPUT: all_models_list with dependencies

    '''

    
    df=bq_utils.select_from_model_catalog(uploaduid)
    
    key = 0
    if key in df.index:
        dependency_list = df["modelDependency"][key]
    else:
        dependency_list = []

    return list(dependency_list)


# CREATE SLAVE DICTIONARY TO GET ATTRIBUTES RELATED TO EACH UID AND VIN.
def get_slave_dict(modelguid, vin):
    

    df1=bq_utils.get_slave_dict_sql1(modelguid,vin)
    df2=bq_utils.get_slave_dict_sql2(modelguid,vin)
    df3=bq_utils.get_slave_dict_sql3(modelguid,vin)

    df = df1.merge(df2, how='outer', on=['uploadUID', 'vin']).merge(df3, how='outer', on=['uploadUID', 'vin'])
    
    df.apiStatus = df.apiStatus.apply(lambda x : "" if str(x)=="nan" else x)
    df.isDeployable = df.isDeployable.apply(lambda x : "" if str(x)=="nan" else x)
    df.expectedDeploymentTime = df.expectedDeploymentTime.apply(lambda x : False if str(x)=="NaT" else x)
    
    slave_dict = dict()
    if len(df):
        df_dict = df.iloc[0].to_dict()
        slave_dict["readiness"] = df_dict['readiness']
        slave_dict["isDeployed"] = df_dict['apiStatus']
        if (df_dict['isDeployable'] is None or df_dict['isDeployable'] == "") and df_dict['apiStatus']:
            slave_dict['isDeployable'] = True
        else:
            slave_dict['isDeployable'] = df_dict['isDeployable']
        if str(df_dict['expectedDeploymentTime']) == "2099-12-31 00:00:00+00:00":
            slave_dict['expectedDeploymentTime'] = False
        else:
            slave_dict['expectedDeploymentTime'] = df_dict['expectedDeploymentTime']
        slave_dict["dependencies"] = df_dict["modelDependency"]
    return slave_dict






# CREATE SLAVE-DEPENDENCY CLASS
class SlaveDependency:
    def __init__(self, upload_id, vin):
        self.model_id = upload_id
        self.description = []
        slave_dict = get_slave_dict(upload_id, vin)
        if slave_dict:
            self.readiness = slave_dict["readiness"]
            self.isDeployable = slave_dict["isDeployable"]
            self.isDeployed = slave_dict["isDeployed"]
            self.scheduledAt = False if pd.isnull(
                slave_dict["expectedDeploymentTime"]) else slave_dict["expectedDeploymentTime"]
            dep_list = slave_dict["dependencies"]
            self.dependencies = []
            if len(dep_list):
                for dep in dep_list:
                    slave = SlaveDependency(dep, vin)
                    slave_dict = slave.__dict__
                    
                    utils.slave_dependency(self,slave_dict,dep,vin)
                    
                    self.dependencies.append(slave)
            self.available = True
        else:
            self.available = False

    def __str__(self):
        return self.model_id


# DECLARE EMPTY MASTER DICTIONARY.
global master_dict
master_dict = {}


# CREATE MASTER DICTIONARY FUNCTION
def get_master_dict_slave_level(upload_id, vin_list):
    master_dict = {}
    master_dict['upload_id'] = upload_id
    master_dict['vins'] = []
    dependencies_list = get_dependency(upload_id)
    for vin in vin_list:
        temp_dict = get_param_status(upload_id, vin)
        if temp_dict:
            param_dict = {
                "vin": vin,
                "dependencies": [],
                "isDeployable": temp_dict["isDeployable"],
                "scheduledAt": temp_dict["expectedDeploymentTime"],
                "isDeployed": temp_dict["apiStatus"],
                "readiness": temp_dict["readiness"]
            }
            for dependency in dependencies_list:
                param_dict['dependencies'].append(unpack(SlaveDependency(dependency, vin)))
            master_dict['modelguid'] = temp_dict["modelGUID"]
            master_dict['vins'].append(param_dict)
    return master_dict


def update_master_dict_master_lavel(master_dict, upload_id):
    model_id = master_dict['modelguid']
    for upload_id_vin in master_dict['vins']:
        vin = upload_id_vin['vin']
        upload_id_vin['description'] = []
        for dep in upload_id_vin['dependencies']:
            if not dep['available']:
                upload_id_vin['description'].append(f"{model_id}: Dependency-{dep['model_id']} not available in {vin}")
                upload_id_vin['description'] = upload_id_vin['description'] + dep['description']
                upload_id_vin['isDeployable'] = False
            elif not dep['isDeployable']:
                upload_id_vin['description'].append(
                    f"{model_id}: Dependency-{dep['model_id']} not deployable in {vin}")
                upload_id_vin['description'] = upload_id_vin['description'] + dep['description']
                upload_id_vin['isDeployable'] = False
            elif dep['scheduledAt']:
                if not upload_id_vin['scheduledAt'] or upload_id_vin['scheduledAt'] < dep['scheduledAt']:
                    upload_id_vin['scheduledAt'] = dep['scheduledAt']
                    upload_id_vin['isDeployable'] = True
                    upload_id_vin['description'].append(
                        f"{model_id} rescheduled at {upload_id_vin['scheduledAt']} (to run at {utils.get_scheduled_time(upload_id_vin['scheduledAt'])}) with dependency-{dep['model_id']} on {vin}")
                    upload_id_vin['description'] = upload_id_vin['description'] + dep['description']
            else:
                upload_id_vin['isDeployable'] = True
    return master_dict

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # Pipeline input arguments
    parser.add_argument("--actionJobUID", type=str)
    parser.add_argument('--uploadUID', type=str)    
    parser.add_argument('--uploadids', type=str)
    # Pipeline output arguments
    parser.add_argument('--user_logs', type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(args.actionJobUID)
    logger.debug(f"Pipeline inputs: {args}")

    try:
        Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        pass
    

    # WRITE TO BQ PIPELINE_LOG TABLE
    log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'NA',
            "stage": stage,
            "status": 'in-progress',
            "desc": 'NA',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }
    bq_utils.insert_to_pipeline_logs(
        log_input
       
    )
    
    # CALL update_master_dict FUNCTION
    pipeline_input_str = args.uploadids
    pipeline_input = json.loads(pipeline_input_str)
    logger.debug(f"Input to Edge Pipeline: {pipeline_input}")
    if not len(pipeline_input):
        logger.error("No Inputs received for Edge Pipeline.")

        log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action":  action,
            "stage": stage,
            "status": 'fail',
            "desc": "No Inputs received for Edge Pipeline." ,
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }
        bq_utils.insert_to_pipeline_logs(
                                log_input
                                )
        sys.exit(0)

    try:
        master_dict = {}
        model_json_list = []
        for upload_id, vin_list in pipeline_input.items():
            logger.info(f"{upload_id}, {vin_list}")
            master_dict = get_master_dict_slave_level(upload_id, vin_list)
            master_dict = update_master_dict_master_lavel(master_dict, upload_id)
            logger.info(master_dict)
            master_dict['prepared_vin_list'] = []
            deployable_vins=[]
            undeployable_vins = []
            rescheduled_vins = []
            for vin_dict in master_dict['vins']:
                if vin_dict['readiness'] and (vin_dict['isDeployable'] in (True, '') or vin_dict['isDeployable'] is None) and not vin_dict["scheduledAt"]:
                    master_dict['prepared_vin_list'].append(vin_dict)
                    deployable_vins.append(vin_dict["vin"])
                    logger.debug(
                        f"""Condition 1: model {master_dict["modelguid"]} is deployable on vin {vin_dict["vin"]}.
                        Reason - {vin_dict["description"]}."""
                    )

                elif (vin_dict['readiness'] and not vin_dict['isDeployable']) or (not vin_dict['readiness']):
                    undeployable_vins.append(vin_dict["vin"])
                    
                    # CALL TO NOTIFICATIONS API
                    uploadUID = master_dict["upload_id"]
                    dl_list = utils.get_dl_list(uploadUID)
                    subject = f"Edge Deployment: Fail: {master_dict['modelguid']}"
                    msg = f"""Hey, model {master_dict["modelguid"]} is not deployable on vin {vin_dict["vin"]}. 
                    Reason - {vin_dict["description"]}."""
                    req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
                    logger.info(req_data)


                    logger.debug(
                        f"""Condition 2: model {master_dict["modelguid"]} is not deployable on vin {vin_dict["vin"]}.
                        Reason - {vin_dict["description"]}."""
                    )
                    
                elif vin_dict['readiness'] and (vin_dict['isDeployable'] in (True, '') or vin_dict['isDeployable'] is None) and vin_dict["scheduledAt"]:
                    rescheduled_vins.append(vin_dict["vin"])
                    
                    # CALL TO NOTIFICATIONS API
                    uploadUID = master_dict["upload_id"]
                    dl_list = utils.get_dl_list(uploadUID)
                    subject = f"Edge Deployment: Fail: {master_dict['modelguid']}"
                    msg = f"""Hey, model {master_dict["modelguid"]} is rescheduled at 
                    {utils.get_scheduled_time(vin_dict["scheduledAt"])} on vin {vin_dict["vin"]}. Reason - 
                    {vin_dict["description"]}."""
                    
                    req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
                    logger.info(req_data)
                    
                    # ADD ENTRY TO EDGE_DEPLOYMENT_HEALTHCHECK TABLE FOR RESCHEDULE MODEL.
                    bq_utils.insert_to_edge_dep_healthcheck(uploadUID, 
                                                         vin_dict["vin"], vin_dict["scheduledAt"],
                                                         vin_dict['isDeployable'])

                    logger.debug(
                        f"""Condition 3: model {master_dict["modelguid"]} is rescheduled at 
                    {utils.get_scheduled_time(vin_dict["scheduledAt"])} on vin {vin_dict["vin"]}. Reason - 
                    {vin_dict["description"]}."""
                    )
            
            if len(deployable_vins)+len(rescheduled_vins)==0:
                log_input = {
                            "uuid": f'{args.uploadUID}',
                            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
                            "action":  action,
                            "stage": stage,
                            "status": 'fail',
                            "desc":  f"{master_dict['modelguid']} is not deployable on any vin." ,
                            "vaijobid": f"{args.actionJobUID}",
                            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
                        }
               
                bq_utils.insert_to_pipeline_logs(
                               log_input
                                )
                # CALL TO NOTIFICATIONS API
                uploadUID = master_dict["upload_id"]
                dl_list = utils.get_dl_list(uploadUID)
                subject = f"Edge Deployment: Fail: {master_dict['modelguid']}"
                msg = f"""Hey, model {master_dict["modelguid"]} is not deployable on any vin."""
                req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
                logger.info(req_data)
                sys.exit(0)
            else:
                log_input = {
                    "uuid": args.uploadUID,
                    "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
                    "action": action,
                    "stage": stage,
                    "status": 'in-process',
                    "desc": f"""{master_dict['modelguid']} is deployable on vins - [{','.join(deployable_vins)}], 
                                    not deployable on vins - [{','.join(undeployable_vins)}], rescheduled on vins -
                                    [{','.join(rescheduled_vins)}].""",
                    "vaijobid": f"{args.actionJobUID}",
                    "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
                }

                bq_utils.insert_to_pipeline_logs(
                                   log_input
                                )


            master_dict['vins'] = master_dict['prepared_vin_list']
            master_dict.pop('prepared_vin_list')
            logger.info(f"Final Master dictionary:{master_dict}")
            if len(master_dict['vins']):
                with open(f"{upload_id}.json", "w") as f:
                    json.dump(master_dict, f, default=str)
                blob = output_bucket.blob(f"{args.actionJobUID}/master_json_files/{upload_id}.json")
                blob.upload_from_filename(f"{upload_id}.json")
                logger.debug(blob.name)
                model_json_list.append(f"{upload_id}.json")
                logger.debug(model_json_list)
            else:
                logger.info(f"{master_dict['modelguid']} is either rescheduled or undeployable.")
                uploadUID = master_dict['upload_id']
                dl_list = utils.get_dl_list(uploadUID)
                subject = f"Edge deployment Failed | {master_dict['modelguid']}"
                msg = f"""Hey, Your model could not be deployed to edge."""
                req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
                logger.info(req_data)

                log_input = {
                    "uuid": args.uploadUID,
                    "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
                    "action": action,
                    "stage": stage,
                    "status": 'fail',
                    "desc": f"{master_dict['modelguid']} is either rescheduled or undeployable.",
                    "vaijobid": f"{args.actionJobUID}",
                    "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
                }
                
                bq_utils.insert_to_pipeline_logs(
                               log_input
                                )
                sys.exit(0)
                

        # CREATE MODEL JSON LIST FILE AND UPLOAD TO BUCKET, NAME GIVEN AS PER ARGS.
        with open("model_json_list.txt", "w") as f:
            for item in model_json_list:
                f.write(item+"\n")
        blob = output_bucket.blob(f"{args.actionJobUID}/master_json_files/model_json_list.txt")
        blob.upload_from_filename("model_json_list.txt")
        logger.debug(blob.name)

        result = "pass"
        logger.info('Individual model json files creation successful since model is deployable.')
    except Exception as e:
        result = "fail"
        logger.exception('Individual model json files creation failed since model is either rescheduled or undeployable.')
        sys.exit(0)

    try:
        with open("master_list_creation_log") as f:
            with open(args.user_logs, "w") as f1:
                for line in f:
                    f1.write(line)
    except Exception as e:
        pass
