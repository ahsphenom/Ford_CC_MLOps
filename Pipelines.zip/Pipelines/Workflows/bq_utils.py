import config
import pandas_gbq as pb
from google.cloud import bigquery

client = bigquery.Client()

def select_from_model_catalog(uploadUID):
    sql = f"""
        SELECT * FROM {config.MODEL_CATALOG_TABLE}
        where uploadUID='{uploadUID}'
        ORDER BY uploadedTime desc
        LIMIT 1
        """

    df = pb.read_gbq(sql, project_id=config.PROJECT_ID)

    return df

def check_model_dependency(dependency_tup):
    sql = f"""
            WITH MAX_uploadedTime_CTE AS
            (SELECT modelGUID, MAX(uploadedTime) AS MAX_uploadedTime 
            FROM {config.MODEL_CATALOG_TABLE} 
            WHERE modelGUID IN {dependency_tup} GROUP BY 1),

            A AS
            (SELECT modelGUID, uploadUID FROM {config.MODEL_CATALOG_TABLE}  
            WHERE CONCAT(modelGUID,"--",uploadedTime) IN
            (SELECT CONCAT(modelGUID,"--",MAX_uploadedTime) AS CONCAT_STRING   
            FROM
            MAX_uploadedTime_CTE)
            GROUP BY 1,2),

            B AS
            (SELECT uploadUID,status FROM {config.CLOUD_DEPLOYMENT_TABLE} 
            WHERE DATE(eventTime) <= "2099-12-31" )

            SELECT A.modelGUID, A.uploadUID, status FROM
            A
            LEFT JOIN 
            B
            ON A.uploadUID = B.uploadUID
            """
    df = pb.read_gbq(sql, project_id=config.PROJECT_ID)

    return df


def insert_to_cloud_deployment(uploadUID,vertex_endpoint,status,vertex_model):
    query = f"""
            INSERT {config.CLOUD_DEPLOYMENT_TABLE} 
            (uploadUID, eventTime, endpointID, status, deploymentID)
            VALUES ('{uploadUID}',CURRENT_TIMESTAMP(),{vertex_endpoint},{status},{vertex_model})

            """
    client.query(query, project=config.PROJECT_ID, location='US')

def insert_to_pipeline_logs(input):
 
    query = f"""
    INSERT {config.PIPELINE_LOGS_TABLE}
    (uploadUID,actionJobUID,action,stage,result,description,eventTime,VAIJobID,workflowItems) 
    VALUES 
    ('{input["uuid"]}','{input["actionjobuid"]}','{input["action"]}','{input["stage"]}','{input["status"]}','{input["desc"]}',CURRENT_TIMESTAMP(),'{input["vaijobid"]}','{input["workflowitems"]}')
    """
    query_job = client.query(query, project=config.PROJECT_ID)
    return query_job


def insert_to_edge_dep_healthcheck(UUID, vin, expectedDeploymentTime, isDeployable):
    bq_client = bigquery.Client()
    query = f"""
    INSERT {config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE}
    (uploadUID,vin,expectedDeploymentTime,eventTime,repetitionNumber,isDeployable) 
    VALUES 
    ('{UUID}','{vin}','{expectedDeploymentTime}',CURRENT_TIMESTAMP(),0,{isDeployable})
    """
    query_job = bq_client.query(query, project=config.PROJECT_ID)
    return query_job


def get_manifest_attn(uploaduid,vin):
    sql = f"""    
        SELECT A.uploadUID, A.modelGUID, modelVersion AS ModelVersion,modelName AS ModelName,uploadedTime,
        modelWeightsFile AS ModelFilePath, metadataFile AS MetaFilePath,vin,driverID
        FROM
        (SELECT uploadUID, modelGUID, modelVersion,modelName,uploadedTime,
        modelWeightsFile ,metadataFile
        FROM {config.MODEL_CATALOG_TABLE}
        WHERE readiness IS true
        GROUP BY 1,2,3,4,5,6,7) A 
        JOIN
        (SELECT uploadUID, vin, ARRAY_AGG(driverId) AS driverId FROM
        {config.VIN_LIST_TABLE}
        group by 1,2) B 
        on A.uploadUID=B.uploadUID
        WHERE A.uploadUID= "{uploaduid}"
        AND vin="{vin}"
        """
    df = pb.read_gbq(sql, project_id=config.PROJECT_ID)

    return df

def insert_edge_deployment_healthcheck_table(UUID,vin):
    query = f"""
            INSERT {config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE} 
            ( uploadUID, vin, expectedDeploymentTime, eventTime, repetitionNumber, isDeployable) 
            VALUES ('{UUID}','{vin}',
            TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 1 DAY),CURRENT_TIMESTAMP(),
            1,'true')
            """
    job = client.query(query, project=config.PROJECT_ID, location='US')

def check_for_model_retry(UUID,vin):
    sql = f"""
            SELECT * from {config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE} 
            WHERE uploadUID='{UUID}' AND vin='{vin}' 
            ORDER BY eventTime DESC LIMIT 1
            """
    df = pb.read_gbq(sql, project_id=config.PROJECT_ID)

    return df

def get_param_status_sql1(vin,uploaduid):
    sql1 = f"""
        SELECT
        Model_Catalog_A.uploadUID,modelGUID,uploadedTime, vin_t.vin,readiness FROM
        (SELECT uploadUID,readiness,modelGUID,uploadedTime FROM {config.MODEL_CATALOG_TABLE} GROUP BY 1,2,3,4) Model_Catalog_A
        LEFT OUTER JOIN 
        (SELECT uploadUID, vin FROM {config.VIN_LIST_TABLE} GROUP BY 1,2 ) vin_t
        ON Model_Catalog_A.uploadUID = vin_t.uploadUID

        WHERE TRIM(Model_Catalog_A.uploadUID) = "{uploaduid}"
        AND vin_t.vin = "{vin}"
        ORDER BY uploadedTime DESC LIMIT 1
        """

    df1 = pb.read_gbq(sql1, project_id=config.PROJECT_ID)

    return df1

def get_param_status_sql2(vin,uploaduid):

    sql2 = f"""
        SELECT uploadUID, vin, apiStatus, eventTime FROM {config.EDGE_DEPLOYMENT_TABLE} 
        WHERE uploadUID = "{uploaduid}"
        AND vin = "{vin}"
        GROUP BY 1,2,3,4
        ORDER BY eventTime DESC LIMIT 1
    """

    df2 = pb.read_gbq(sql2, project_id=config.PROJECT_ID)

    return df2

def get_param_status_sql3(vin,uploaduid):
    sql3 = f"""
        SELECT uploadUID, vin, isDeployable, IFNULL(expectedDeploymentTime,"2099-12-31") as expectedDeploymentTime, eventTime
        FROM {config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE} 
        WHERE uploadUID = "{uploaduid}"
        AND vin = "{vin}"
        GROUP BY 1,2,3,4,5
        ORDER BY eventTime DESC LIMIT 1
        """
    
    df3 = pb.read_gbq(sql3, project_id=config.PROJECT_ID)

    return df3


def get_slave_dict_sql1(modelguid,vin):
    sql1 = f"""
    SELECT A.uploadUID,readiness,modelGUID,uploadedTime, modelDependency,vin FROM
    (SELECT uploadUID,readiness,modelGUID,uploadedTime, modelDependency
    FROM {config.MODEL_CATALOG_TABLE}
    WHERE CONCAT(modelGUID,"-",UploadedTime) = (SELECT CONCAT(modelGUID,"-",latestUploadedTime) FROM 
    (SELECT modelGUID ,MAX( uploadedTime ) latestUploadedTime FROM {config.MODEL_CATALOG_TABLE} WHERE
    modelGUID = "{modelguid}" GROUP BY 1))) A
    LEFT JOIN 
    (SELECT uploadUID, vin FROM {config.VIN_LIST_TABLE} GROUP BY 1,2 ) vin_t
    ON A.uploadUID = vin_t.uploadUID
    WHERE vin = "{vin}"
    """

    df1 = pb.read_gbq(sql1, project_id=config.PROJECT_ID)
    
    return df1

def get_slave_dict_sql2(modelguid,vin):
    sql2 = f"""
    SELECT uploadUID,vin,apiStatus,eventTime FROM {config.EDGE_DEPLOYMENT_TABLE}
    WHERE uploadUID IN 
    (SELECT uploadUID FROM {config.MODEL_CATALOG_TABLE}
    WHERE CONCAT(modelGUID,"-",UploadedTime) = (SELECT CONCAT(modelGUID,"-",latestUploadedTime) FROM 
    (SELECT modelGUID ,MAX( uploadedTime ) latestUploadedTime FROM {config.MODEL_CATALOG_TABLE} WHERE modelGUID = "{modelguid}" GROUP BY 1)))
    AND vin = "{vin}"
    GROUP BY 1,2,3,4
    """
    df2 = pb.read_gbq(sql2, project_id=config.PROJECT_ID)
    
    return df2

def get_slave_dict_sql3(modelguid,vin):
    sql3 = f"""
    SELECT uploadUID,vin,isDeployable, expectedDeploymentTime FROM {config.EDGE_DEPLOYMENT_HEALTHCHECK_TABLE}
    WHERE uploadUID IN 
    (SELECT uploadUID FROM {config.MODEL_CATALOG_TABLE}
    WHERE CONCAT(modelGUID,"-",UploadedTime) = (SELECT CONCAT(modelGUID,"-",latestUploadedTime) FROM 
    (SELECT modelGUID ,MAX( uploadedTime ) latestUploadedTime FROM {config.MODEL_CATALOG_TABLE} WHERE modelGUID = "{modelguid}" GROUP BY 1)))
    AND vin = "{vin}"
    GROUP BY 1,2,3,4
    """
    df3 = pb.read_gbq(sql3, project_id=config.PROJECT_ID)

    return df3
