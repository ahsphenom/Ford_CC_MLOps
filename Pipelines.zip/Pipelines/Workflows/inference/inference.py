import argparse
from distutils.command.upload import upload
import importlib
import json
import os
import sys
from datetime import datetime
from pathlib import Path

import config
import gsutil_utils
import pandas as pd
import utils
import bq_utils
from app_logger import CustomLogger
from google.cloud import storage

# Create logger object
logger = CustomLogger(__name__, 'inference_log')

storage_client = storage.Client()
output_bucket = storage_client.get_bucket(config.PIPELINE_BUCKET_NAME)
input_bucket = storage_client.get_bucket(config.INPUT_BUCKET_NAME)


def inference(args):

    UUID = metadata['uploadUID']
    

    # LOAD MODEL
    try:
        inference_script_name = metadata['inferenceFile'].split('/')[-1].split('$')[0].split('.')[0]
        logger.debug(inference_script_name)
        x = importlib.import_module(f"{metadata['modelGUID']}.{inference_script_name}")
        model = x.load_model(f"model.{framework_format}")
        result = "pass"
        description = "Model file loading Successful!"
        logger.info(f"{'model.'+framework_format} Model file loading Successful!")
    except Exception as e:
        result = "fail"
        description = "Model file loading ERROR!"
        logger.exception(f"{'model.'+framework_format} Model file loading ERROR!")
    
    log_input = {
            "uuid": UUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'load model',
            "stage": 'testing',
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

    bq_utils.insert_to_pipeline_logs(
      log_input
    )
    if result == 'fail':
        uploadUID = metadata['uploadUID']
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""Hey, Could not load model."""
        utils.send_notification(uploadUID, dl_list, subject, msg)
        sys.exit(0)

    # LOAD processed_data and ground_truths
    preproc_data = pd.read_csv(f'preprocessed.csv')
    y_val = pd.read_csv(f'Y_val.csv')

    # PREDICTION
    try:
        y_predict = x.predict(model, preproc_data)
        result = "pass"
        description = "Prediction Successful!"
        logger.info("Prediction Successful!")
    except Exception as e:
        logger.exception("Check whether the no. of features and their names matches that of training data.")
        result = "fail"
        description = "Prediction ERROR!"

    # WRITE TO BQ PIPELINE_LOG TABLE

    log_input = {
            "uuid": UUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'prediction',
            "stage": 'testing',
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }
    
    bq_utils.insert_to_pipeline_logs(log_input)

    if result == 'fail':
        uploadUID = metadata['uploadUID']
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""Hey, Error during making predictions."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)

        sys.exit(0)

    # GENERATE METRICS
    try:
        j_dict = {}
        for metric in metadata['testingThresholdScores']:
            j_dict[metric['metric']] = metric
            j_dict[metric['metric']].pop('metric')
        for metric, properties in j_dict.items():
            logger.debug(properties)
            if properties['fileName']:
                x.get_metrics(y_val, y_predict)
                metrics_dict = json.load(open(properties['fileName']))
                logger.debug(metrics_dict)
            elif not properties['fileName']:
                metrics_dict = x.get_metrics(y_val, y_predict)
                logger.debug(metrics_dict)
        result = "pass"
        description = "Metric scores generate Successful!"
        logger.info(f"Metric scores generate successful with metrics_dict = {metrics_dict}.")
    except Exception as e:
        result = "fail"
        description = "Metric scores generate ERROR!"
        logger.error("No Metric scores were generated.")


    log_input = {
            "uuid": UUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'get metrics',
            "stage": 'testing',
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

    bq_utils.insert_to_pipeline_logs(
        log_input
    )

    if result == 'fail':
        uploadUID = metadata['uploadUID']
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""Hey, Error while generating metrics."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)

    # SCORE COMPARISON
    comparision_result = {}
    for name, value in metrics_dict.items():
        result,description=utils.score_comparison(j_dict,name,value)
        
        comparision_result[name] = result

    # WRITE TO BQ PIPELINE_LOG TABLE
    log_input = {
            "uuid": UUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'score comparison',
            "stage": 'testing',
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }
    bq_utils.insert_to_pipeline_logs(
        log_input
    )
    #ADD FAILURE CHECK FOR SCORE COMPARISON PART. IF FAILED, STOP THE PIPELINE.
    if result=='fail':
        uploadUID = metadata['uploadUID']
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""{description}"""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)
        
    
    # WRITE TO BQ PIPELINE_LOG TABLE

    log_input = {
            "uuid": UUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'NA',
            "stage": 'testing',
            "status": 'completed',
            "desc": 'NA',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

    bq_utils.insert_to_pipeline_logs(
       log_input
    )


    # Model deployment deciding factor
    with open(args.model_accept, 'w') as f:
        f.write(str(comparision_result[name]).lower())

    # Deployment type deciding factor
    cloud_deployment = metadata['workflow']['stagesDeploymentToCloud']
    edge_deployment = metadata['workflow']['stagesDeploymentToEdge']

    with open(args.cloud_deploy, 'w') as f:
        f.write(str(cloud_deployment).lower())

    with open(args.edge_deploy, 'w') as f:
        f.write(str(edge_deployment).lower())

    try:
        with open("inference_log") as f:
            with open(args.user_logs, "w") as f1:
                for line in f:
                    f1.write(line)
    except Exception as e:
        pass


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # Pipeline input arguments
    parser.add_argument("--actionJobUID", type=str)
    # Pipeline output arguments
    parser.add_argument('--user_logs', type=str)
    parser.add_argument('--model_accept', type=str)
    parser.add_argument('--cloud_deploy', type=str)
    parser.add_argument('--edge_deploy', type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(args.actionJobUID)

    try:
        Path(args.model_accept).parent.mkdir(parents=True, exist_ok=True)
        Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        pass

    try:
        meta_blob = output_bucket.blob(f"{args.actionJobUID}/updatedMetadata.json")
        meta_blob.download_to_filename('metadata.json')
    except Exception as e:
        logger.exception("Metadata file did not get imported. Please check the path of file.")

    # Load METADATA file.
    metadata = json.load(open('metadata.json'))
    uploadUID = metadata['uploadUID']

    # Download entire package.
    bucket_name = config.INPUT_BUCKET_NAME
    artifact_folder = metadata['metadataFile'].split('/')[3]
    try:
        downloaded_files = gsutil_utils.download_from_bucket(
            bucket_name, artifact_folder, metadata['modelGUID']    
        )
        logger.debug(f"list of files downloaded to {metadata['modelGUID']} folder: {downloaded_files}")
    except Exception as e:
        logger.exception("Model Package could not be downloaded.Please check the path of model package.")
        
        
        # WRITE TO BQ PIPELINE_LOG TABLE
        log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'inference',
            "stage": 'testing',
            "status": 'fail',
            "desc":  'Model Package could not be downloaded. Please check the path of model package.' ,
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

        bq_utils.insert_to_pipeline_logs(
                        log_input)
        
        # CALL TO NOTIFICATIONS API    
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""Hey, Could not download package. Please check the path of model package."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)

    # downloading preprocessing artificats
    blobs = input_bucket.list_blobs(prefix=f"{metadata['uploadUID']}/")
    for blob in blobs:
        logger.debug(str(blob.name))
        filename = str(blob.name).split('/')[1].lower()
        logger.debug(filename)
        try:
            if 'preprocessed' in filename:
                blob.download_to_filename('preprocessed.csv')
        except Exception as e:
            logger.exception("preprocessed file did not get imported. Please check the path of file.")

        try:
            if 'y_val' in filename:
                blob.download_to_filename('Y_val.csv')
        except Exception as e:
            logger.exception("ground truth file did not get imported. Please check the path of file.")

    # For VAI deployment, Only single model file should be available inside folder.
    framework_format = metadata['frameworkInfo']['format']

    # Fetch Model_file path.
    artifact_bucket = storage_client.get_bucket(config.INPUT_BUCKET_NAME)
    try:
        model_file_rel_path = '/'.join(metadata['modelWeightsFile'].split('$')[0].split('/')[3:])
        logger.debug(model_file_rel_path)
        model_blob = artifact_bucket.blob(model_file_rel_path)
        model_blob.download_to_filename(f"model.{framework_format}")
    except Exception as e:
        logger.exception("Model file did not get imported. Please check the path of file.")
        
        # WRITE TO BQ PIPELINE_LOG TABLE
        log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'inference',
            "stage": 'testing',
            "status": 'fail',
            "desc":  'Model file did not get imported. Please check the path of file.' ,
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

        bq_utils.insert_to_pipeline_logs(
                log_input )
        
        # CALL TO NOTIFICATIONS API    
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""Hey, Model file did not get imported. Please check the path of file."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)

    # Install pip packages from requirements.txt
    if 'requirements.txt' in os.listdir(f"{metadata['modelGUID']}"):
        pip_packages = [line for line in open(f"{metadata['modelGUID']}/requirements.txt")]
        logger.debug(f"Installing the following packages from requirements.txt: {pip_packages}")
        
        os.system(f"pip3 install -r {metadata['modelGUID']}/requirements.txt")
    else:
        logger.debug(f"No requirements.txt available.")

    logger.debug(f"Pipeline inputs: {args}")
    inference(args)
