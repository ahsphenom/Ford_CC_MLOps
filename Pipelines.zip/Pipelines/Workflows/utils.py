import json

import config
import pandas_gbq as pb
import pandas as pd 
import requests
from google.cloud import bigquery


def get_dl_list(uploadUID):
    get_dl_list_query = f"""
    SELECT uploadUID, modelOwnerDistributionList, uploadedTime FROM {config.MODEL_CATALOG_TABLE} WHERE uploadUID IN ("{uploadUID}") ORDER BY uploadedTime DESC
    """

    dl_list_df = pb.read_gbq(get_dl_list_query, project_id=config.PROJECT_ID)

    dl_list_df = dl_list_df.sort_values('uploadedTime').groupby('uploadUID').tail(1).drop(columns=['uploadedTime'])

    return list(dl_list_df.iloc[0]['modelOwnerDistributionList'])


def send_notification(uploadUID, dl_list, subject, msg):
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json"
    }
    data = json.dumps(locals())
    resp = requests.post(config.NOTIF_URL, headers=headers, data=data)
    # TODO: check resp status code and add logic to handle failures

    return data 

def gtval_marg_present(name,gt_val,margin,value):
    gt_value = gt_val
    gt_value_prime = gt_value - margin
    if value < gt_value_prime:
        result = 'fail'
        description = f'Failed: {name} value {value} is not within tolerance value {gt_value_prime}'
    elif value >= gt_value:
        result = 'pass'
        description = f'Passed: {name} value {value} is within tolerance value {gt_value_prime}'
    else:
        result = 'in tolerence limit'
    return result, description

def ltval_marg_present(name,lt_val,margin,value):
    lt_value = lt_val
    lt_value_prime = margin
    if value > lt_value_prime:
        result = 'fail'
        description = f'Failed: {name} value {value} is not within tolerance value {lt_value_prime}'
    elif value <= lt_value:
        result = 'pass'
        description = f'Passed: {name} value {value} is within tolerance value {lt_value_prime}'
    else:
        result = 'in tolerence limit'
    return result, description

def gtval_ltval_present(name,gt_val,lt_val,value):
    gt_value = gt_val
    lt_value = lt_val
    if value >= gt_value and value < lt_value:
        result = 'pass'
        description = f'Passed: {name} value {value} is within tolerance values {gt_value} & {lt_value}'
    else:
        result = 'fail'
        description = f'Failed: {name} value {value} is not within tolerance values {gt_value} & {lt_value}'
    return result, description



def score_comparison(j_dict, name, value):
    if name in j_dict.keys() and 'gtValue' in j_dict[name].keys() and 'margin' in j_dict[name].keys():
        result, description = gtval_marg_present(name,j_dict[name]['gtValue'], j_dict[name]['margin'],value)
    elif name in j_dict.keys() and 'ltValue' in j_dict[name].keys() and 'margin' in j_dict[name].keys():
        result,description = ltval_marg_present(name,j_dict[name]['ltValue'],j_dict[name]['margin'],value)
    elif name in j_dict.keys() and 'gtValue' in j_dict[name].keys() and 'ltValue' in j_dict[name].keys():
        result,description = gtval_ltval_present(name,j_dict[name]['gtValue'],j_dict[name]['ltValue'],value)
    else:
        result = "metric doesn't have threshold values"
        description = "Threshold values are not present in metrics dictionary."

    return result, description

def endpoint_creation(endpoint,logger) :
    if endpoint:
        result = "pass"
        description = "Endpoint creation Successful!"
        logger.debug(endpoint)
        
    else:
        result = "fail"
        description = "Endpoint could not be created!"
        logger.debug(description)

    return result, description

# GET 3-HOUR WINDOW SCHEDULED TIME
def get_scheduled_time(time):
    time_str = time.strftime("%Y-%m-%d %H:%M:%S")
    hours = pd.to_datetime(time_str, format='%Y-%m-%d %H:%M:%S').hour
    date_str = time_str.split(' ')[0]
    window = pd.cut(
        [hours],
        bins=[0,3,6,9,12,15,18,21],
        include_lowest=True,
        labels=[f'{date_str} 03:00:00+0000',f'{date_str} 06:00:00+0000',f'{date_str} 09:00:00+0000',f'{date_str} 12:00:00+0000',f'{date_str} 15:00:00+0000',f'{date_str} 18:00:00+0000',f'{date_str} 21:00:00+0000']
    )
    return window[0]

def slave_dependency(self,slave_dict,dep,vin):

    if not slave_dict['available']:
        self.isDeployable = False
        self.description.append(f"{self.model_id}: Dependency-{dep} not available in {vin}")
        self.description = self.description + slave_dict['description']
    elif not slave_dict['isDeployable']:
        self.isDeployable = False
        self.description.append(f"{self.model_id}: Dependency-{dep} not deployable in {vin}")
        self.description = self.description + slave_dict['description']
    elif slave_dict['scheduledAt'] and self.scheduledAt < slave_dict['scheduledAt']:
        self.scheduledAt = slave_dict['scheduledAt']
        self.description.append(
            f"{self.model_id}: {self.model_id} rescheduled at {self.scheduledAt} (to run at {get_scheduled_time(self.scheduledAt)}) with dependency-{dep} on {vin}")
        self.description = self.description + slave_dict['description']
    else:
        self.isDeployable = True




