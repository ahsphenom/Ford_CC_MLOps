import argparse
import http.client
import json
import mimetypes
import os
import shutil
import uuid
from codecs import encode
from glob import glob
from pathlib import Path
from zipfile import ZipFile
import utils
import sys
from ast import literal_eval as le 

import config
import pandas as pd
import pandas_gbq as pb
import bq_utils
from app_logger import CustomLogger
from google.cloud import storage,bigquery


# Create logger object
logger = CustomLogger(__name__, 'package_creation_log')
stage='edge deployment'

storage_client = storage.Client()
client = bigquery.Client()
output_bucket = storage_client.get_bucket(config.PIPELINE_BUCKET_NAME)


def get_vin_dict():
    vin_dict = {}
    json_list_file_blob = output_bucket.blob(f"{args.actionJobUID}/master_json_files/model_json_list.txt")
    json_list_file_blob.download_to_filename(f"model_json_list.txt")
    with open(f"model_json_list.txt") as f:
        model_json_list = f.read().splitlines()

    blobs = output_bucket.list_blobs(prefix=f"{args.actionJobUID}/master_json_files/")
    for blob in blobs:
        file_name = str(blob.name).split('/')[-1]
        if file_name in model_json_list:
            json_filename = ''.join(blob.name).split('/')[1]
            blob.download_to_filename(json_filename)
            dict_ = json.load(open(json_filename))
            for i in range(len(dict_['vins'])):
                vin_dict.setdefault(dict_['vins'][i]['vin'], []).append(dict_['upload_id'])
    return vin_dict


def get_manifest_attr(uploaduid,vin):
    
    df=bq_utils.get_manifest_attn(uploaduid,vin)

    if len(df):
        df_dict = df.iloc[0].to_dict()
        del df_dict['uploadedTime'],df_dict['vin']
        df_dict['driverID'] = list(set(df_dict['driverID']))
        df_dict['ModelFile'] = df_dict['ModelFilePath'].split('/')[-1].split('$')[0]
        df_dict['MetaFile'] = df_dict['MetaFilePath'].split('/')[-1].split('$')[0]
        df_dict['MetaVersion'] = df_dict['MetaFile'].split('_')[1]
        return df_dict
    else:
        logger.error("No records fetched from Bigquery. Dataframe is empty.")
        return False


def get_master_vin_list(vin_dict):
    master_vin_list = []
    for vin, uids in vin_dict.items():
        model_dict = {
            "vin": vin,
            "resource_name": str(uuid.uuid4()),
            "models": []
        }
        for uid in uids:
            attributes_dict = get_manifest_attr(uid,vin)
            if attributes_dict:
                model_dict['models'].append(attributes_dict)
        master_vin_list.append(model_dict)

    return master_vin_list


def tmc_request(package_name, vin_id, tmc_res_dict):

    content_type='Content-Type: {}'

    conn = http.client.HTTPSConnection(config.TMC_SERVICE_URL)
    data_list = []
    boundary = 'wL36Yn8afVp8Ag7AmP8qZ0SA4n1v9T'
    data_list.append(encode(vin_id))
    data_list.append(encode('--' + boundary))
    data_list.append(encode('Content-Disposition: form-data; name=VIN;'))

    data_list.append(encode(content_type.format('text/plain')))
    data_list.append(encode(''))

    data_list.append(encode(package_name))
    data_list.append(encode('--' + boundary))
    data_list.append(encode('Content-Disposition: form-data; name=resourceName;'))

    data_list.append(encode(content_type.format('text/plain')))
    data_list.append(encode(''))

    data_list.append(encode(package_name))
    data_list.append(encode('--' + boundary))
    data_list.append(encode('Content-Disposition: form-data; name=file; filename={0}'.format('')))

    file_type = mimetypes.guess_type(f'{package_name}.zip')[0] or 'application/octet-stream'
    data_list.append(encode(content_type.format(file_type)))
    data_list.append(encode(''))

    with open(f'{package_name}'+'.zip', 'rb') as f:
        data_list.append(f.read())
    data_list.append(encode('--'+boundary+'--'))
    data_list.append(encode(''))
    body = b'\r\n'.join(data_list)
    payload = body
    headers = {
        'Content-type': 'multipart/form-data; boundary={}'.format(boundary)
    }
    conn.request("POST", "/api/uploadToTMC", payload, headers)
    res = conn.getresponse()
    data = res.read()

    logger.debug(data.decode("utf-8"))

    if res.status == 200:
        tmc_res_dict[package_name] = True
        return data.decode("utf-8")
    else:
        tmc_res_dict[package_name] = False
        return False
    
    
def retry_data_insert(resource_name, tmc_res_dict):
    for resource_dict in master_vin_list:
        if resource_name in resource_dict.values(): 
            logger.debug(resource_name)
            for model in resource_dict['models']:
                UUID = model['uploadUID']
                vin = resource_dict['vin']
                #CHECK IF MODEL ALREADY RETRY OR NOT.
                df=bq_utils.check_for_model_retry(UUID,vin)
                
                if len(df) and df['repetitionNumber'][0]==1:
                    tmc_res_dict['repetitionNumber'][UUID] = 1
                    logger.info(f"Max retries limit reached for {model['modelGUID']} on vin {vin}.")
                else:
                    tmc_res_dict['repetitionNumber'][UUID] = 0
                    logger.info(f"Retrying model {model['modelGUID']} after 24 hours on vin {vin}.")
                    bq_utils.insert_edge_deployment_healthcheck_table(UUID,vin)
                   
    return

    


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--actionJobUID', type=str)
    parser.add_argument('--uploadUID', type=str)
    parser.add_argument('--user_logs', type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(args.actionJobUID)
    logger.debug(f"Pipeline inputs: {args}")

    try:
        Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        pass

    # CREATE VIN_DICT HAVING VIN_ID AS KEY AND MODELGUID AS VALUE.
    try:
        vin_dict = get_vin_dict()
        logger.debug(vin_dict)
        logger.info("Vin dictionary creation successful.")
    except Exception as e:
        logger.exception('Vin dictionary creation failed.')

    # CREATE MASTER VIN LIST.
    try:
        master_vin_list = get_master_vin_list(vin_dict)
        logger.debug(f"Master Vin List:{master_vin_list}")
        result = "pass"
        description = 'Master vinlist creation successful.'
        logger.info(description)
    except Exception as e:
        result = "fail"
        description = 'Master vinlist creation failed.'
        logger.exception(description)
    
    # WRITE TO BQ PIPELINE_LOG TABLE
    log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action":   'Master Vin list creation',
            "stage": stage,
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

    bq_utils.insert_to_pipeline_logs(log_input)
    
    if result=="fail":
        sys.exit(0)

    # MANIFEST FILE CREATION
    try:
        for i in range(len(master_vin_list)):
            manifest_dict = {}
            resource_name = master_vin_list[i]['resource_name']
            os.makedirs(resource_name, exist_ok=True)
            for model in master_vin_list[i]['models']:
                if model['ModelName'] not in manifest_dict.keys():
                    manifest_dict[model['ModelName']] = []
                for driver_id in model['driverID']:
                    model_driver_dict = {}
                    for key in model.keys():
                        if key != 'driverID':
                            model_driver_dict[key] = model[key]
                        else:
                            model_driver_dict[key] = driver_id
                    del model_driver_dict['ModelName'], model_driver_dict['ModelFilePath'], model_driver_dict['MetaFilePath'],model_driver_dict['uploadUID']
                    manifest_dict[model['ModelName']].append(model_driver_dict)
            logger.debug(manifest_dict)
            with open(f"{resource_name}/manifest.txt", 'w') as f:
                json.dump(manifest_dict, f)

        result = "pass"
        description = 'Manifest files creation successful.'
        logger.info("Manifest files creation successful.")
    except Exception as e:
        result = "fail"
        description = 'Manifest files creation failed.'
        logger.exception("Manifest files creation failed.")
        
    # WRITE TO BQ PIPELINE_LOG TABLE
    log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action":   'Manifest files creation',
            "stage": stage,
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
    }

    bq_utils.insert_to_pipeline_logs(log_input)
    
    if result=="fail":
        # CALL TO NOTIFICATIONS API
        uploadUID = args.uploadUID
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Edge Deployment: Fail"
        msg = f"""Hey, Edge deployment has failed. Reason - 
        Manifest files could not be created.Check if json files are available in pipeline bucket and master vin list has been created."""

        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)

    # FOLDER CREATION W.R.T EACH VIN INCLUDING MANIFEST FILES AND ARTIFACTS.
    for vin_index in range(len(master_vin_list)):
        master_vin_list[vin_index]['vin']
        for model_index in master_vin_list[vin_index]['models']:
            vin_name = master_vin_list[vin_index]['vin']
            resource_name = master_vin_list[vin_index]['resource_name']
            # MODEL FILE FETCH
            model_file_path = model_index['ModelFilePath']
            model_bucket_name = model_file_path.split('/')[2]
            model_bucket = storage_client.get_bucket(model_bucket_name)
            model_name = model_file_path.split('$')[0].split('/')[3:]
            model_name = '/'.join(model_name)
            blob = model_bucket.blob(model_name)
            _, file_name = os.path.split(model_name)
            blob.download_to_filename(file_name)
            shutil.copy(file_name, resource_name+'/'+file_name)
            # METADATA FILE FETCH
            meta_file_path = model_index['MetaFilePath']
            meta_name = meta_file_path.split('$')[0].split('/')[3:]
            meta_name = '/'.join(meta_name)
            blob = model_bucket.blob(meta_name)
            _, file_name2 = os.path.split(meta_name)
            blob.download_to_filename(file_name2)
            shutil.copy(file_name2, resource_name+'/'+file_name2)

        logger.info(
            f"Files to be zipped in {resource_name}: {[os.path.join(path, name) for path, subdirs, files in os.walk(resource_name) for name in files]}")

    # ZIPFILE CREATION WITH RESOURCE UID
    try:
        for vin_package in master_vin_list:
            with ZipFile(vin_package["resource_name"]+'.zip', "w") as newzip:
                for f in glob(f"{vin_package['resource_name']}/**"):
                    newzip.write(f)
        result = "pass"
        description = 'Zip package creation successful.'
        logger.info("Zip package creation successful.")
    except Exception as e:
        result = "fail"
        description = 'Zip package creation failed.'
        logger.exception("Zip package creation failed.")
        
    # WRITE TO BQ PIPELINE_LOG TABLE
    log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'Zip package creation',
            "stage": stage,
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
    }

    bq_utils.insert_to_pipeline_logs(log_input)
    
    if result=="fail":
        # CALL TO NOTIFICATIONS API
        uploadUID = args.uploadUID
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Edge Deployment: Fail"
        msg = f"""Hey, Edge deployment has failed. Reason - 
        Zip Packages could not be created.Check in logs if manifest files are created."""

        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)

    # UPLOADING ZIP PACKAGES TO BUCKET AND CALL TO UPLOAD API SERVICE.
    tmc_res_dict = {}
    tmc_res_dict['repetitionNumber'] = {}
    for package_file in glob('*.zip'):
        blob = output_bucket.blob(f"{args.actionJobUID}/zip_packages/{package_file}")
        blob.upload_from_filename(package_file)
        resource_name = str(package_file.split('.')[0])
        try:
            response = tmc_request(resource_name, vin_name, tmc_res_dict)
            response_dict = json.loads(response)
            if response_dict['status'] == "UPLOAD_FAILED":
                retry_data_insert(resource_name, tmc_res_dict)
                logger.info(f"Failed to upload the data for {resource_name} on {vin_name}, so retrying it after 24 hours.")
            logger.debug(f"tmc_response_dict : {tmc_res_dict}")
            logger.info(response)
            result = "pass"
            description = f'Call to upload API for {resource_name} successful.'
            logger.info(f"Call to upload API for {resource_name} successful.")
        except Exception as e:
            result = "fail"
            description = f'Call to upload API for {resource_name} failed.'
            logger.exception(f"Call to upload API for {resource_name} failed.")
            
    # WRITE TO BQ PIPELINE_LOG TABLE
    log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action":  'Call to upload API TMC service',
            "stage": stage,
            "status": f'{result}',
            "desc": f'{description}',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

    bq_utils.insert_to_pipeline_logs(log_input)
    
    if result=="fail":
        # CALL TO NOTIFICATIONS API
        uploadUID = args.uploadUID
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Edge Deployment: Fail"
        msg = f"""Hey, Edge deployment has failed. Reason - 
        Call to upload API TMC service failed. Check in logs for more details."""

        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)
            

    # REINSERT TO BQ
    reinsert_df = pd.DataFrame(columns=["uploadUID", "eventTime", "resourceID", "apiStatus", "deploymentID", "vin", "repetitionNumber"])

    for vin_list in master_vin_list:
        vin = vin_list['vin']
        resource_name = vin_list['resource_name']
        for model in vin_list['models']:
            uploadUID = model['uploadUID']
            data_dict = {
                "uploadUID": uploadUID,
                "eventTime": pd.Timestamp.now(),
                "resourceID": resource_name,
                "apiStatus": tmc_res_dict[resource_name],
                "deploymentID": "",
                "vin": vin,
                "repetitionNumber": tmc_res_dict['repetitionNumber'].get(uploadUID, 0)
            }
            reinsert_df = reinsert_df.append(data_dict, ignore_index=True)
    
    logger.debug(f"Re-insert to edge_deployment table: {reinsert_df}")
    
    try:
        pb.to_gbq(
            reinsert_df, config.EDGE_DEPLOYMENT_TABLE, if_exists='append', table_schema=config.EDGE_DEPLOYMENT_TABLE_SCHEMA
        )
        
        # WRITE TO BQ PIPELINE_LOG TABLE
        log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action":  'Re-insert to edge_deployment table',
            "stage": stage,
            "status":'pass',
            "desc": 'Re-insert to edge_deployment table successful.',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }
        bq_utils.insert_to_pipeline_logs(log_input)
    except Exception as e:
        logger.exception(f"Re-insert to edge_deployment table failed.")
            
        # WRITE TO BQ PIPELINE_LOG TABLE
        log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action":  'Re-insert to edge_deployment table',
            "stage": stage,
            "status": 'fail',
            "desc": 'Re-insert to edge_deployment table failed. Please check the dataframe schema and data.',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }

        bq_utils.insert_to_pipeline_logs(log_input)
        sys.exit(0)
        
    
    # WRITE TO BQ PIPELINE_LOG TABLE
    log_input = {
            "uuid": args.uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action":  'NA',
            "stage": stage,
            "status": 'completed',
            "desc": 'NA',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
        }
    bq_utils.insert_to_pipeline_logs(
        log_input
    )
    
    # CREATING LOGS FILE TO DUMP IN GCS.
    try:
        with open("package_creation_log") as f:
            with open(args.user_logs, "w") as f1:
                for line in f:
                    f1.write(line)
    except Exception as e:
        pass
