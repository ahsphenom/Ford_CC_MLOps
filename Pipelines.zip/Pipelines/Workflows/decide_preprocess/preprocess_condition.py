import argparse
import json
import re
import sys
from pathlib import Path
import bq_utils
import config
import utils
from app_logger import CustomLogger
from google.cloud import storage

# Create logger object
logger = CustomLogger(__name__, 'preprocess_condition_log')

storage_client = storage.Client()
output_bucket = storage_client.get_bucket(config.PIPELINE_BUCKET_NAME)


def preprocess_condition(args):

    is_raw_data = metadata['testDataset']['isRawData']
    is_preproc_and_Y = metadata['testDataset']['isPreprocAndY']
    uploadUID = metadata['uploadUID']

    with open("inference_script.py", 'r') as f:
        preprocess_presence = bool(re.search("def preprocess", f.read()))
        if preprocess_presence and is_raw_data and not is_preproc_and_Y:
            decision = "Run Preprocess"
            logger.info("Run Preprocess component since raw data and preprocess function available .")

        elif (preprocess_presence and not is_raw_data) or (not preprocess_presence and is_raw_data) or (not preprocess_presence and not is_raw_data) and is_preproc_and_Y:
            decision = "Skip Preprocess"
            logger.info("Skip Preprocess component since preprocessed data available.")


        elif not is_raw_data and not is_preproc_and_Y:
            logger.exception("Test data or preprocessed data not available for testing.")

            
            
            # WRITE TO BQ PIPELINE_LOG TABLE

            log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'decide preprocess',
            "stage": 'testing',
            "status": 'fail',
            "desc": 'Test data or preprocessed data not available for testing.',
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
            }

            bq_utils.insert_to_pipeline_logs(
                        log_input)                 
                  
            # CALL TO NOTIFICATIONS API
            dl_list = utils.get_dl_list(uploadUID)
            subject = f"Testing failed | {metadata['modelGUID']}"
            msg = f"""Hey, Test data or preprocessed data not available for testing."""
            req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
            logger.info(req_data)
            #ADD NOTIFICATION AND PIPLEINE LOGS FOR FAIL
            sys.exit(0)
            

    with open(args.result, 'w') as out_file:
        out_file.write(decision)
        

    with open("preprocess_condition_log") as f:
        with open(args.user_logs, "w") as f1:
            for line in f:
                f1.write(line)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # Pipeline input arguments
    parser.add_argument("--actionJobUID", type=str)
    # Pipeline output arguments
    parser.add_argument('--result', type=str)
    parser.add_argument('--user_logs', type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(args.actionJobUID)

    # Creating the directory where the output file will be created
    # (the directory may or may not exist).
    Path(args.result).parent.mkdir(parents=True, exist_ok=True)
    Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)

    # Fetch Metadata file from GCS.
    meta_blob = output_bucket.blob(f"{args.actionJobUID}/updatedMetadata.json")
    meta_blob.download_to_filename('metadata.json')

    # Load METADATA file.
    metadata = json.load(open('metadata.json'))

    # Inference_file path.
    bucket_name = config.INPUT_BUCKET_NAME

    try:
        artifact_bucket = storage_client.get_bucket(bucket_name)
        logger.debug(artifact_bucket)
        inference_file_rel_path = '/'.join(metadata['inferenceFile'].split('$')[0].split('/')[3:])
        logger.debug(inference_file_rel_path)
        inference_blob = artifact_bucket.blob(inference_file_rel_path)
        inference_blob.download_to_filename('inference_script.py')
        logger.debug(f"Inference file downloaded from {metadata['inferenceFile']}")
        logger.debug(f"inference_rel_path: {inference_file_rel_path}")
    except Exception as e:
        logger.exception("Inference Script file did not get imported. Please check the path of file.")
        uploadUID = metadata['uploadUID']
                         
        # WRITE TO BQ PIPELINE_LOG TABLE
        log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{args.actionJobUID.split("-")[-1]}',
            "action": 'decide preprocess',
            "stage": 'testing',
            "status": 'fail',
            "desc": 'Inference Script file did not get imported. Please check the path of file.' ,
            "vaijobid": f"{args.actionJobUID}",
            "workflowitems": f'v{args.actionJobUID.split("-")[0]}'
            }

        bq_utils.insert_to_pipeline_logs(
        log_input )                 
                  
        # CALL TO NOTIFICATIONS API
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {metadata['modelGUID']}"
        msg = f"""Hey, Inference Script file did not get imported. Please check the path of file."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)
    logger.debug(f"Pipeline inputs: {args}")
    preprocess_condition(args)
    
