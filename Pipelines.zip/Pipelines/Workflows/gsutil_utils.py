import os

from google.cloud import storage


def find_occurrences(s, ch):  # to find position of '/' in blob path ,used to create folders in local storage
    return [i for i, letter in enumerate(s) if letter == ch]

def dowload_to_filename(blob,blob_path,folderloc,local_path,startloc):
    
    if(blob.name.replace(blob_path, '').find("/") == -1):
        downloadpath = local_path + '/' + blob.name.replace(blob_path, '')
        blob.download_to_filename(downloadpath)

    else:
        for folder in folderloc:
            if not os.path.exists(local_path + '/' + blob.name.replace(blob_path, '')[startloc:folder]):
                create_folder = local_path + '/' + \
                    blob.name.replace(blob_path, '')[0:startloc] + '/' + \
                    blob.name.replace(blob_path, '')[startloc:folder]
                startloc = folder + 1
                os.makedirs(create_folder)

        downloadpath = local_path + '/' + blob.name.replace(blob_path, '')

        blob.download_to_filename(downloadpath)
    
def download_from_bucket(bucket_name, blob_path, local_path):
    # Create this folder locally
    if not os.path.exists(local_path):
        os.makedirs(local_path)

    storage_client = storage.Client()
    bucket = storage_client.get_bucket(bucket_name)
    blobs = list(bucket.list_blobs(prefix=blob_path))

    startloc = 0
    for blob in blobs:
        startloc = 0
        folderloc = find_occurrences(blob.name.replace(blob_path, ''), '/')
        if(not blob.name.endswith("/")):
            dowload_to_filename(blob,blob_path,folderloc,local_path,startloc)
            
    return [os.path.join(path, name) for path, subdirs, files in os.walk(local_path) for name in files]
