import argparse
from pathlib import Path
import utils
import config
import sys
import pandas_gbq as pb
from app_logger import CustomLogger
from google.cloud import storage
import bq_utils

# Create logger object
logger = CustomLogger(__name__, 'bq_load_log')


storage_client = storage.Client()
bucket = storage_client.get_bucket(config.PIPELINE_BUCKET_NAME)


def bq_load(args):
    """
    Fetches model information from BQ and creates a new updated metadata
json file to be used by downstream components
    """
    # Fetch upload-uid from pipeline parameter
    uploadUID = args.uploadUID
    actionJobUID = args.actionJobUID
    action='testing'
    
    # WRITE TO BQ PIPELINE_LOG TABLE

    log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{actionJobUID.split("-")[-1]}',
            "action": 'NA',
            "stage": action,
            "status": 'in-progress',
            "desc": 'NA',
            "vaijobid": f"{actionJobUID}",
            "workflowitems": f'v{actionJobUID.split("-")[0]}'
        }


    bq_utils.insert_to_pipeline_logs(
       log_input
    )

    # Create a new empty folder for loading outputs of pipeline.
    model_folder = bucket.blob(f'{actionJobUID}/')
    model_folder.upload_from_string('')

    try:
        df=bq_utils.select_from_model_catalog(uploadUID)
        
        df.to_json(
            f"gs://{config.PIPELINE_BUCKET_NAME}/{actionJobUID}/updatedMetadata.json",
            orient='records', lines=True
        )
        logger.debug(df)
        logger.info("Bigquery data fetch successful.")
    except Exception as e:
        logger.exception("Error!! Cannot read metadata from Model Catalog in Bigquery.")
        #ADD NOTIFICATION AND PIPLEINE LOGS FOR FAIL

        log_input = {
            "uuid": uploadUID,
            "actionjobuid": f'pipeline-{actionJobUID.split("-")[-1]}',
            "action": 'bq_load',
            "stage": action,
            "status": 'fail',
            "desc": 'Cannot read metadata from Model Catalog in Bigquery.',
            "vaijobid": f"{actionJobUID}",
            "workflowitems": f'v{actionJobUID.split("-")[0]}'
        }

        bq_utils.insert_to_pipeline_logs(
        log_input
        )
        
        dl_list = utils.get_dl_list(uploadUID)
        subject = f"Testing failed | {df.iloc[0]['modelGUID']}"
        msg = """Hey, Cannot read metadata from Model Catalog in Bigquery."""
        req_data=utils.send_notification(uploadUID, dl_list, subject, msg)
        logger.info(req_data)
        sys.exit(0)
        

    with open("bq_load_log") as f:
        with open(args.user_logs, "w") as f1:
            for line in f:
                f1.write(line)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # Pipeline input arguments
    parser.add_argument("--uploadUID", type=str)
    parser.add_argument("--actionJobUID", type=str)
    # Pipeline output arguments
    parser.add_argument("--user_logs", type=str)

    args = parser.parse_args()
    logger.set_actionJobUID(args.actionJobUID)

    Path(args.user_logs).parent.mkdir(parents=True, exist_ok=True)

    logger.debug(f"Pipeline inputs: {args}")
    
    bq_load(args)
