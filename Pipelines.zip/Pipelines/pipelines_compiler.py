import kfp
from google.cloud import storage
from kfp.v2 import compiler, dsl
import config

TEMPLATE_BUCKET_NAME = "mlopsplatform-dev-mlpipelines-templates"


@dsl.pipeline(name=f"upload", description='Creating the upload component')
def upload_pipeline(
    file_path: str,
    UUID: str,
    modelGUID: str,
    uploadedBy: str,
    time: str,
):

    # Loads the yaml manifest for each component
    check_file = kfp.components.load_component_from_file('Validation/check_file/component.yaml')
    validate = kfp.components.load_component_from_file('Validation/validate_metadata/component.yaml')
    insert = kfp.components.load_component_from_file('Validation/insert/component.yaml')
    update_readiness = kfp.components.load_component_from_file(
        'Validation/update_readiness/component.yaml')
    workflow_trigger = kfp.components.load_component_from_file(
        'Validation/workflow_trigger/component.yaml')

    check_file_task = check_file(UUID, file_path, time, uploadedBy)

    with dsl.Condition(check_file_task.outputs['count'] == '7', name='Metadata-inference-Model-Present'):
        validate_task = validate(
            UUID, check_file_task.outputs['model_metadata'],check_file_task.outputs['targetfilepath'], time, uploadedBy
        ).after(check_file_task)
        insert_task = insert(
            UUID, modelGUID, check_file_task.outputs['model_metadata'],
            check_file_task.outputs['inference_script'], check_file_task.outputs['model_file'], check_file_task.outputs['targetfilepath'], uploadedBy, time
        ).after(validate_task)
        update_readiness_task = update_readiness(
            UUID, validate_task.outputs['expectedfileList'], "", time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['count'] == '5', name='Metadata-Model-Present'):
        validate_task = validate(
            UUID, check_file_task.outputs['model_metadata'],check_file_task.outputs['targetfilepath'], time, uploadedBy
        ).after(check_file_task)
        insert_task = insert(
            UUID, modelGUID, check_file_task.outputs['model_metadata'], "", check_file_task.outputs[
                'model_file'], check_file_task.outputs['targetfilepath'], uploadedBy, time
        ).after(validate_task)
        update_readiness_task = update_readiness(
            UUID, validate_task.outputs['expectedfileList'], "", time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['count'] == '6', name='Inference-Model-Present'):
        insert_task = insert(
            UUID, modelGUID, "", check_file_task.outputs['inference_script'], check_file_task.outputs[
                'model_file'], check_file_task.outputs['targetfilepath'], uploadedBy, time
        )
        update_readiness_task = update_readiness(
            UUID, "", check_file_task.outputs['inference_script'], time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['count'] == '4', name='Model-Present'):
        insert_task = insert(
            UUID, modelGUID, "", "", check_file_task.outputs['model_file'], check_file_task.outputs['targetfilepath'], uploadedBy, time
        )
        update_readiness_task = update_readiness(
            UUID, "", check_file_task.outputs['model_file'], time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition((check_file_task.outputs['model'] == 'True_single'), name='Model-Present'):
        insert_task = insert(
            UUID, modelGUID, "", "", check_file_task.outputs['model_file'], check_file_task.outputs['targetfilepath'], uploadedBy, time
        )
        update_readiness_task = update_readiness(
            UUID, "", check_file_task.outputs['model_file'], time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['count'] == '3', name='Metadata-inference-Present'):
        validate_task = validate(
            UUID, check_file_task.outputs['model_metadata'], check_file_task.outputs['targetfilepath'], time, uploadedBy
        ).after(check_file_task)
        insert_task = insert(
            UUID, modelGUID, check_file_task.outputs['model_metadata'],
            check_file_task.outputs['inference_script'], "", check_file_task.outputs['targetfilepath'], uploadedBy, time
        ).after(validate_task)
        update_readiness_task = update_readiness(
            UUID, validate_task.outputs['expectedfileList'], "", time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['validation'] == "True_single", name='Metadata-Present'):
        validate_task = validate(
            UUID, check_file_task.outputs['model_metadata'],check_file_task.outputs['targetfilepath'], time, uploadedBy
        ).after(check_file_task)
        insert_task = insert(
            UUID, modelGUID, check_file_task.outputs['model_metadata'], "",
            "", check_file_task.outputs['targetfilepath'], uploadedBy, time
        ).after(validate_task)
        update_readiness_task = update_readiness(
            UUID, validate_task.outputs['expectedfileList'], "", time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['count'] == '1', name='Metadata-Present'):
        validate_task = validate(
            UUID, check_file_task.outputs['model_metadata'],check_file_task.outputs['targetfilepath'], time, uploadedBy
        ).after(check_file_task)
        insert_task = insert(
            UUID, modelGUID, check_file_task.outputs['model_metadata'], "",
            "", check_file_task.outputs['targetfilepath'], uploadedBy, time
        ).after(validate_task)
        update_readiness_task = update_readiness(
            UUID, validate_task.outputs['expectedfileList'], "", time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['inference'] == 'True_single', name='Inference-Present'):
        insert_task = insert(
            UUID, modelGUID, "", check_file_task.outputs['inference_script'], "", check_file_task.outputs['targetfilepath'], uploadedBy, time
        )
        update_readiness_task = update_readiness(
            UUID, "", check_file_task.outputs['inference_script'], time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['count'] == '2', name='Inference-Present'):
        insert_task = insert(
            UUID, modelGUID, "", check_file_task.outputs['inference_script'], "", check_file_task.outputs['targetfilepath'], uploadedBy, time
        )
        update_readiness_task = update_readiness(
            UUID, "", check_file_task.outputs['inference_script'], time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)

    with dsl.Condition(check_file_task.outputs['other_file'] == 'True', name='Standard-files-absent'):
        insert_task = insert(UUID, modelGUID, "", "", "", check_file_task.outputs['targetfilepath'], uploadedBy, time)
        update_readiness_task = update_readiness(
            UUID, "", check_file_task.outputs['other'], time
        ).after(insert_task)
        workflow_trigger_task = workflow_trigger(UUID, time).after(update_readiness_task)


@dsl.pipeline(name='testingworkflow', description='Testing_workflow')
def testing_pipeline(
    uploadUID: str,
    actionJobUID: str,
    uploadids: str,
):
    bq_load = kfp.components.load_component_from_file(config.bq_load_path)
    preproc_cond = kfp.components.load_component_from_file(config.preproc_load_path)
    preprocess = kfp.components.load_component_from_file(config.preprocess_path)
    inference = kfp.components.load_component_from_file(config.inference_path)

    bq_load_task = bq_load(uploadUID, actionJobUID)
    preproc_cond_task = preproc_cond(actionJobUID).after(bq_load_task)

    with dsl.Condition(preproc_cond_task.outputs['result'] == config.Run_Preprocess, name=config.Run_Preprocess):
        preprocess_task = preprocess(actionJobUID)
        inference_task = inference(actionJobUID).after(preprocess_task)

    with dsl.Condition(preproc_cond_task.outputs['result'] == config.Skip_Preprocess, name=config.Skip_Preprocess):
        inference_task = inference(actionJobUID)


@dsl.pipeline(name='clouddeploy', description='cloud deployment workflow')
def cloud_deploy_pipeline(
    uploadUID: str,
    actionJobUID: str,
    uploadids: str,
):

    bq_load = kfp.components.load_component_from_file(config.bq_load_path)
    cloud_deploy = kfp.components.load_component_from_file(config.cloud_deploy_path)

    bq_load_task = bq_load(uploadUID, actionJobUID)
    cloud_deploy_task = cloud_deploy(actionJobUID).after(bq_load_task)


@dsl.pipeline(name='edgedeploy', description='edge deployment workflow')
def edge_deploy_pipeline(
    uploadUID: str,
    uploadids: str,
    actionJobUID: str,
):

    master_list = kfp.components.load_component_from_file(
        config.master_list_creation_path)
    package_creation = kfp.components.load_component_from_file(
        config.package_creation_path)

    master_list_task = master_list(actionJobUID, uploadUID, uploadids)
    package_creation_task = package_creation(actionJobUID, uploadUID).after(master_list_task)


@dsl.pipeline(name='cloudedgedeploy', description='cloud and edge deployment workflow')
def cloud_edge_deploy_pipeline(
    uploadUID: str,
    uploadids: str,
    actionJobUID: str,
):

    bq_load = kfp.components.load_component_from_file(config.bq_load_path)
    cloud_deploy = kfp.components.load_component_from_file(config.cloud_deploy_path)
    master_list = kfp.components.load_component_from_file(
        config.master_list_creation_path)
    package_creation = kfp.components.load_component_from_file(
        config.package_creation_path)

    bq_load_task = bq_load(uploadUID, actionJobUID)
    cloud_deploy_task = cloud_deploy(actionJobUID).after(bq_load_task)
    master_list_task = master_list(actionJobUID, uploadUID, uploadids)
    package_creation_task = package_creation(actionJobUID, uploadUID).after(master_list_task)


@dsl.pipeline(name='testedge', description='test, edge workflow')
def test_edge_deploy_pipeline(
    uploadUID: str,
    uploadids: str,
    actionJobUID: str,
):
    bq_load = kfp.components.load_component_from_file(config.bq_load_path)
    preproc_cond = kfp.components.load_component_from_file(config.preproc_load_path)
    preprocess = kfp.components.load_component_from_file(config.preprocess_path)
    inference = kfp.components.load_component_from_file(config.inference_path)
    master_list = kfp.components.load_component_from_file(
        config.master_list_creation_path)
    package_creation = kfp.components.load_component_from_file(
        config.package_creation_path)

    bq_load_task = bq_load(uploadUID, actionJobUID)
    preproc_cond_task = preproc_cond(actionJobUID).after(bq_load_task)

    with dsl.Condition(preproc_cond_task.outputs['result'] == config.Run_Preprocess, name=config.Run_Preprocess):
        preprocess_task = preprocess(actionJobUID)
        inference_task = inference(actionJobUID).after(preprocess_task)

        with dsl.Condition(inference_task.outputs['model_accept'] == "pass", name="deployReady"):
            with dsl.Condition(inference_task.outputs['edge_deploy'] == "true", name="edgeDeploy"):
                master_list_task = master_list(actionJobUID, uploadUID, uploadids).after(inference_task)
                package_creation_task = package_creation(actionJobUID, uploadUID).after(master_list_task)

    with dsl.Condition(preproc_cond_task.outputs['result'] == config.Skip_Preprocess, name=config.Skip_Preprocess):
        inference_task = inference(actionJobUID)

        with dsl.Condition(inference_task.outputs['model_accept'] == "pass", name="deployReady"):
            with dsl.Condition(inference_task.outputs['edge_deploy'] == "true", name="edgeDeploy"):
                master_list_task = master_list(actionJobUID, uploadUID, uploadids).after(inference_task)
                package_creation_task = package_creation(actionJobUID, uploadUID).after(master_list_task)


@dsl.pipeline(name='testcloud', description='test, cloud workflow')
def test_cloud_deploy_pipeline(
    uploadUID: str,
    actionJobUID: str,
    uploadids: str,
):
    bq_load = kfp.components.load_component_from_file(config.bq_load_path)
    preproc_cond = kfp.components.load_component_from_file(config.preproc_load_path)
    preprocess = kfp.components.load_component_from_file(config.preprocess_path)
    inference = kfp.components.load_component_from_file(config.inference_path)
    cloud_deploy = kfp.components.load_component_from_file(config.cloud_deploy_path)

    bq_load_task = bq_load(uploadUID, actionJobUID)
    preproc_cond_task = preproc_cond(actionJobUID).after(bq_load_task)

    with dsl.Condition(preproc_cond_task.outputs['result'] == config.Run_Preprocess, name=config.Run_Preprocess):
        preprocess_task = preprocess(actionJobUID)
        inference_task = inference(actionJobUID).after(preprocess_task)

        with dsl.Condition(inference_task.outputs['model_accept'] == "pass", name="deployReady"):
            with dsl.Condition(inference_task.outputs['cloud_deploy'] == "true", name="cloudDeploy"):
                cloud_deploy_task = cloud_deploy(actionJobUID).after(inference_task)

    with dsl.Condition(preproc_cond_task.outputs['result'] == config.Skip_Preprocess, name=config.Skip_Preprocess):
        inference_task = inference(actionJobUID)

        with dsl.Condition(inference_task.outputs['model_accept'] == "pass", name="deployReady"):
            with dsl.Condition(inference_task.outputs['cloud_deploy'] == "true", name="cloudDeploy"):
                cloud_deploy_task = cloud_deploy(actionJobUID).after(inference_task)


@dsl.pipeline(name='testcloudedge', description='test, cloud and edge workflow')
def test_cloud_edge_pipeline(
    uploadUID: str,
    actionJobUID: str,
    uploadids: str,
):
    bq_load = kfp.components.load_component_from_file(config.bq_load_path)
    preproc_cond = kfp.components.load_component_from_file(config.preproc_load_path)
    preprocess = kfp.components.load_component_from_file(config.preprocess_path)
    inference = kfp.components.load_component_from_file(config.inference_path)
    cloud_deploy = kfp.components.load_component_from_file(config.cloud_deploy_path)
    master_list = kfp.components.load_component_from_file(
        config.master_list_creation_path)
    package_creation = kfp.components.load_component_from_file(
        config.package_creation_path)

    bq_load_task = bq_load(uploadUID, actionJobUID)
    preproc_cond_task = preproc_cond(actionJobUID).after(bq_load_task)

    with dsl.Condition(preproc_cond_task.outputs['result'] == config.Run_Preprocess, name=config.Run_Preprocess):
        preprocess_task = preprocess(actionJobUID)
        inference_task = inference(actionJobUID).after(preprocess_task)

        with dsl.Condition(inference_task.outputs['model_accept'] == "pass", name="deployReady"):
            with dsl.Condition(inference_task.outputs['cloud_deploy'] == "true", name="cloudDeploy"):
                cloud_deploy_task = cloud_deploy(actionJobUID).after(inference_task)
            with dsl.Condition(inference_task.outputs['edge_deploy'] == "true", name="edgeDeploy"):
                master_list_task = master_list(actionJobUID, uploadUID, uploadids).after(inference_task)
                package_creation_task = package_creation(actionJobUID, uploadUID).after(master_list_task)

    with dsl.Condition(preproc_cond_task.outputs['result'] == config.Skip_Preprocess, name=config.Skip_Preprocess):
        inference_task = inference(actionJobUID)

        with dsl.Condition(inference_task.outputs['model_accept'] == "pass", name="deployReady"):
            with dsl.Condition(inference_task.outputs['cloud_deploy'] == "true", name="cloudDeploy"):
                cloud_deploy_task = cloud_deploy(actionJobUID).after(inference_task)
            with dsl.Condition(inference_task.outputs['edge_deploy'] == "true", name="edgeDeploy"):
                master_list_task = master_list(actionJobUID, uploadUID, uploadids).after(inference_task)
                package_creation_task = package_creation(actionJobUID, uploadUID).after(master_list_task)


if __name__ == '__main__':
    storage_client = storage.Client()
    bucket = storage_client.get_bucket(TEMPLATE_BUCKET_NAME)

    template_filenames = [
        'test-workflow.json', 'clouddeploy-workflow.json',
        'edgedeploy-workflow.json', 'clouddeploy-edgedeploy-workflow.json', 'test-clouddeploy-workflow.json',
        'test-edgedeploy-workflow.json', 'test-clouddeploy-edgedeploy-workflow.json',
        'validation-workflow.json'
    ]

    # COMPILE ALL THE PIPELINE SCRIPTS.
    compiler.Compiler().compile(pipeline_func=upload_pipeline, package_path='validation-workflow.json')
    compiler.Compiler().compile(pipeline_func=testing_pipeline, package_path='test-workflow.json')
    compiler.Compiler().compile(pipeline_func=cloud_deploy_pipeline, package_path='clouddeploy-workflow.json')
    compiler.Compiler().compile(pipeline_func=edge_deploy_pipeline, package_path='edgedeploy-workflow.json')
    compiler.Compiler().compile(pipeline_func=cloud_edge_deploy_pipeline, package_path='clouddeploy-edgedeploy-workflow.json')
    compiler.Compiler().compile(pipeline_func=test_cloud_deploy_pipeline, package_path='test-clouddeploy-workflow.json')
    compiler.Compiler().compile(pipeline_func=test_edge_deploy_pipeline, package_path='test-edgedeploy-workflow.json')
    compiler.Compiler().compile(pipeline_func=test_cloud_edge_pipeline, package_path='test-clouddeploy-edgedeploy-workflow.json')

    for template_filename in template_filenames:
        blob = bucket.blob(template_filename)
        blob.upload_from_filename(template_filename)
